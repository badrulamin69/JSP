import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import { join } from 'node:path';
import { readFileSync, writeFileSync } from 'node:fs';

const browserDistFolder = join(import.meta.dirname, '../browser');
const dbPath = join(process.cwd(), 'db.json');

const app = express();
app.use(express.json());
const angularApp = new AngularNodeAppEngine();

/**
 * Basic Mock API for db.json
 */
app.get('/api/:resource', (req, res): void => {
  try {
    const resource = req.params.resource;
    const db = JSON.parse(readFileSync(dbPath, 'utf8'));
    let data = db[resource];

    if (!data) {
      res.status(404).json({ error: 'Resource not found' });
      return;
    }

    // Simple filtering by customerId
    if (req.query['customerId']) {
      data = data.filter((item: any) => item.customerId === req.query['customerId']);
    }

    res.json(data);
    return;
  } catch (error) {
    res.status(500).json({ error: 'Failed to read database' });
    return;
  }
});

app.get('/api/:resource/:id', (req, res): void => {
  try {
    const { resource, id } = req.params;
    const db = JSON.parse(readFileSync(dbPath, 'utf8'));
    const item = db[resource]?.find((i: any) => i.id === id);
    if (!item) {
      res.status(404).json({ error: 'Not found' });
      return;
    }
    res.json(item);
    return;
  } catch (error) {
    res.status(500).json({ error: 'Database error' });
    return;
  }
});

app.post('/api/:resource', (req, res): void => {
  try {
    const resource = req.params.resource;
    const db = JSON.parse(readFileSync(dbPath, 'utf8'));
    const newItem = { ...req.body, id: Math.random().toString(36).substring(7) };
    if (!db[resource]) db[resource] = [];
    db[resource].push(newItem);
    writeFileSync(dbPath, JSON.stringify(db, null, 2));
    res.status(201).json(newItem);
    return;
  } catch (error) {
    res.status(500).json({ error: 'Failed to write to database' });
    return;
  }
});

app.patch('/api/:resource/:id', (req, res): void => {
  try {
    const { resource, id } = req.params;
    const db = JSON.parse(readFileSync(dbPath, 'utf8'));
    const index = db[resource]?.findIndex((i: any) => i.id === id);
    if (index === -1) {
      res.status(404).json({ error: 'Not found' });
      return;
    }
    db[resource][index] = { ...db[resource][index], ...req.body };
    writeFileSync(dbPath, JSON.stringify(db, null, 2));
    res.json(db[resource][index]);
    return;
  } catch (error) {
    res.status(500).json({ error: 'Failed to update database' });
    return;
  }
});

app.put('/api/:resource/:id', (req, res): void => {
  try {
    const { resource, id } = req.params;
    const db = JSON.parse(readFileSync(dbPath, 'utf8'));
    const index = db[resource]?.findIndex((i: any) => i.id === id);
    if (index === -1) {
      res.status(404).json({ error: 'Not found' });
      return;
    }
    db[resource][index] = { ...db[resource][index], ...req.body, id };
    writeFileSync(dbPath, JSON.stringify(db, null, 2));
    res.json(db[resource][index]);
    return;
  } catch (error) {
    res.status(500).json({ error: 'Failed to replace resource' });
    return;
  }
});

app.delete('/api/:resource/:id', (req, res): void => {
  try {
    const { resource, id } = req.params;
    const db = JSON.parse(readFileSync(dbPath, 'utf8'));
    const index = db[resource]?.findIndex((i: any) => i.id === id);
    if (index === -1) {
      res.status(404).json({ error: 'Not found' });
      return;
    }
    db[resource].splice(index, 1);
    writeFileSync(dbPath, JSON.stringify(db, null, 2));
    res.status(204).send();
    return;
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete resource' });
    return;
  }
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 3000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = Number(process.env['PORT'] || 3000);
  app.listen(port, '0.0.0.0', () => {
    console.log(`Node Express server listening on http://0.0.0.0:${port}`);
  });
}

// Error handling middleware
app.use((err: Error & { status?: number }, req: express.Request, res: express.Response, next: express.NextFunction) => {
  console.error('Express error handler block:', err);
  if (res.headersSent) {
    return next(err);
  }
  res.status(err.status || 500).send({
    message: err.message || 'Internal Server Error',
    error: err
  });
});

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);
