import { Component, ChangeDetectionStrategy } from '@angular/core';
import { RouterLink } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [RouterLink, MatIconModule],
  template: `
    <footer class="bg-white border-t border-slate-200 pt-20 pb-10">
      <div class="max-w-7xl mx-auto px-4 sm:px-6">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          <!-- Brand -->
          <div class="space-y-6">
            <div class="flex items-center gap-2">
              <div class="w-8 h-8 bg-gradient-to-tr from-bank-blue to-bank-emerald rounded-lg flex items-center justify-center">
                <mat-icon class="text-white text-base">shield</mat-icon>
              </div>
              <span class="text-xl font-display font-bold tracking-tight text-slate-900">SmartSecure</span>
            </div>
            <p class="text-slate-500 leading-relaxed max-w-xs font-light">
              Swiss-grade security with modern fintech agility. Managed treasury and institutional-grade assets.
            </p>
            <div class="flex flex-col gap-2">
               <span class="text-[10px] text-slate-400 uppercase font-bold tracking-widest">Secure Partners</span>
               <div class="flex items-center gap-4 opacity-40 grayscale group-hover:grayscale-0 transition-all">
                  <span class="font-serif italic text-sm text-slate-900 font-bold tracking-wider">FINMA</span>
                  <span class="font-serif italic text-sm text-slate-900 font-bold tracking-wider">SWIFT</span>
                  <span class="font-serif italic text-sm text-slate-900 font-bold tracking-wider">VISA</span>
               </div>
            </div>
          </div>

          <!-- Services -->
          <div>
            <h4 class="text-xs font-bold text-slate-900 uppercase tracking-widest mb-6">Services</h4>
            <ul class="space-y-4 text-slate-500 text-sm">
              <li><a routerLink="/services" class="hover:text-bank-blue transition-colors">Personal Banking</a></li>
              <li><a routerLink="/services" class="hover:text-bank-blue transition-colors">Business Accounts</a></li>
              <li><a routerLink="/loans" class="hover:text-bank-blue transition-colors">Loan Solutions</a></li>
              <li><a routerLink="/investment" class="hover:text-bank-blue transition-colors">Investments</a></li>
            </ul>
          </div>

          <!-- Support -->
          <div>
            <h4 class="text-xs font-bold text-slate-900 uppercase tracking-widest mb-6">Support</h4>
            <ul class="space-y-4 text-slate-500 text-sm">
              <li><a routerLink="/security" class="hover:text-bank-blue transition-colors">Security Center</a></li>
              <li><a routerLink="/faq" class="hover:text-bank-blue transition-colors">FAQs</a></li>
              <li><a routerLink="/contact" class="hover:text-bank-blue transition-colors">Contact Us</a></li>
              <li><a routerLink="/locations" class="hover:text-bank-blue transition-colors">Find a Branch</a></li>
            </ul>
          </div>

          <!-- Newsletter -->
          <div>
            <h4 class="text-xs font-bold text-slate-900 uppercase tracking-widest mb-6">Stay Secure</h4>
            <form class="flex flex-col gap-3">
              <input type="email" placeholder="Enter your email" class="bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 focus:outline-hidden focus:border-bank-blue transition-colors text-slate-900 text-sm">
              <button class="bg-bank-navy text-white font-bold py-3 rounded-xl hover:bg-slate-800 transition-colors shadow-lg active:scale-[0.98]">Subscribe</button>
            </form>
          </div>
        </div>

        <!-- Bottom -->
        <div class="pt-10 border-t border-slate-100 flex flex-col md:flex-row justify-between items-center gap-6 text-slate-400 text-[10px] font-bold uppercase tracking-widest">
          <p>© 2026 Smart Secure Bank AG.</p>
          <div class="flex gap-8">
            <a routerLink="/terms" class="hover:text-bank-blue transition-colors">Privacy</a>
            <a routerLink="/privacy" class="hover:text-bank-blue transition-colors">Security</a>
            <a routerLink="/cookies" class="hover:text-bank-blue transition-colors">Compliance</a>
          </div>
        </div>
      </div>
    </footer>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class Footer {}
