export enum TransactionStatus {
  DEFAULT = 'DEFAULT'
};