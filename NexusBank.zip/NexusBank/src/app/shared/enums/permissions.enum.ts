export enum Permissions {
  DEFAULT = 'DEFAULT'
};