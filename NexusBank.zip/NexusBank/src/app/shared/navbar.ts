import { Component, ChangeDetectionStrategy, signal, inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser, CommonModule } from '@angular/common';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { SessionService } from '../core/services/session.service';
import { AuthService } from '../core/services/auth.service';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive, MatIconModule],
  template: `
    <nav class="fixed top-0 left-0 w-full z-50 transition-all duration-300" [class.glass]="isScrolled()" [class.h-20]="!isScrolled()" [class.h-16]="isScrolled()">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 h-full flex items-center justify-between">
        <!-- Logo -->
        <a routerLink="/" class="flex items-center gap-2 group">
          <div class="w-8 h-8 bg-gradient-to-tr from-bank-blue to-bank-emerald rounded-lg flex items-center justify-center group-hover:scale-105 transition-transform shadow-sm">
            <mat-icon class="text-white text-base">shield</mat-icon>
          </div>
          <span class="text-xl font-display font-bold tracking-tight text-bank-navy">
             Smart<span class="text-bank-blue">Secure</span>
          </span>
        </a>

        <!-- Desktop Menu -->
        <div class="hidden md:flex items-center gap-8">
          <a routerLink="/services" routerLinkActive="text-bank-blue" class="text-sm font-medium text-slate-600 hover:text-bank-blue transition-colors">Personal</a>
          <a routerLink="/security" routerLinkActive="text-bank-blue" class="text-sm font-medium text-slate-600 hover:text-bank-blue transition-colors">Business</a>
          <a routerLink="/pricing" routerLinkActive="text-bank-blue" class="text-sm font-medium text-slate-600 hover:text-bank-blue transition-colors">Enterprise</a>
          <a routerLink="/about" routerLinkActive="text-bank-blue" class="text-sm font-medium text-slate-600 hover:text-bank-blue transition-colors">Treasury</a>
        </div>

        <!-- Desktop Buttons -->
        <div class="hidden md:flex items-center gap-4">
          <ng-container *ngIf="!session.isAuthenticated(); else authButtons">
            <a routerLink="/login" class="text-sm font-semibold text-slate-700 px-4 py-2 hover:text-bank-blue transition-colors">Log In</a>
            <a routerLink="/register" class="bg-bank-navy text-white text-sm font-semibold px-6 py-2.5 rounded-full hover:bg-slate-800 transition-all shadow-lg active:scale-95">Open Account</a>
          </ng-container>
          <ng-template #authButtons>
            <a [routerLink]="auth.getRedirectUrl(session.userRole() || '')" class="text-sm font-bold text-bank-navy px-4 py-2 hover:text-bank-blue transition-colors flex items-center gap-2">
              <mat-icon class="text-lg">dashboard</mat-icon>
              Dashboard
            </a>
            <button (click)="auth.logout()" class="bg-slate-100 text-slate-700 text-sm font-bold px-6 py-2.5 rounded-full hover:bg-slate-200 transition-all active:scale-95">
              Log Out
            </button>
          </ng-template>
        </div>

        <!-- Mobile Menu Toggle -->
        <button (click)="toggleMobileMenu()" class="md:hidden p-2 text-slate-600 hover:bg-slate-100 rounded-lg">
          <mat-icon>{{ mobileMenuOpen() ? 'close' : 'menu' }}</mat-icon>
        </button>
      </div>

      <!-- Mobile Menu Drawer -->
      @if (mobileMenuOpen()) {
        <div class="md:hidden glass absolute top-full left-0 w-full p-4 flex flex-col gap-4 shadow-xl animate-in slide-in-from-top-4 duration-200">
          <a routerLink="/services" (click)="mobileMenuOpen.set(false)" class="p-3 text-lg font-medium text-slate-700 hover:bg-slate-50 rounded-xl">Services</a>
          <a routerLink="/security" (click)="mobileMenuOpen.set(false)" class="p-3 text-lg font-medium text-slate-700 hover:bg-slate-50 rounded-xl">Security</a>
          <a routerLink="/pricing" (click)="mobileMenuOpen.set(false)" class="p-3 text-lg font-medium text-slate-700 hover:bg-slate-50 rounded-xl">Pricing</a>
          <a routerLink="/about" (click)="mobileMenuOpen.set(false)" class="p-3 text-lg font-medium text-slate-700 hover:bg-slate-50 rounded-xl">About</a>
          <hr class="border-slate-100">
          
          <div *ngIf="!session.isAuthenticated(); else mobileAuth" class="grid grid-cols-2 gap-3">
            <a routerLink="/login" (click)="mobileMenuOpen.set(false)" class="flex justify-center p-3 font-semibold text-slate-700 border border-slate-200 rounded-xl">Login</a>
            <a routerLink="/register" (click)="mobileMenuOpen.set(false)" class="flex justify-center p-3 font-semibold bg-bank-navy text-white rounded-xl">Register</a>
          </div>
          <ng-template #mobileAuth>
            <div class="flex flex-col gap-3">
              <a [routerLink]="auth.getRedirectUrl(session.userRole() || '')" (click)="mobileMenuOpen.set(false)" class="flex items-center justify-center gap-2 p-3 font-bold text-bank-navy bg-bank-blue/10 rounded-xl">
                <mat-icon>dashboard</mat-icon>
                Go to Dashboard
              </a>
              <button (click)="auth.logout(); mobileMenuOpen.set(false)" class="p-3 font-bold text-slate-700 bg-slate-100 rounded-xl">Log Out</button>
            </div>
          </ng-template>
        </div>
      }
    </nav>
  `,
  host: {
    '(window:scroll)': 'onWindowScroll()'
  },
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class Navbar {
  platformId = inject(PLATFORM_ID);
  session = inject(SessionService);
  auth = inject(AuthService);
  
  isScrolled = signal(false);
  mobileMenuOpen = signal(false);

  onWindowScroll() {
    if (isPlatformBrowser(this.platformId)) {
      this.isScrolled.set(window.scrollY > 20);
    }
  }

  toggleMobileMenu() {
    this.mobileMenuOpen.update(v => !v);
  }
}
