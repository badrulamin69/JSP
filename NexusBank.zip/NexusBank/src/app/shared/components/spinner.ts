import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoadingService } from '../../core/services/loading.service';

@Component({
  selector: 'app-spinner',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div *ngIf="loading.isLoading()" class="fixed inset-0 z-[9999] flex items-center justify-center bg-white/50 backdrop-blur-[2px]">
      <div class="flex flex-col items-center gap-3">
        <div class="h-12 w-12 animate-spin rounded-full border-4 border-bank-blue border-t-transparent"></div>
        <p class="text-bank-navy font-bold animate-pulse uppercase tracking-widest text-xs">Processing...</p>
      </div>
    </div>
  `,
  styles: []
})
export class SpinnerComponent {
  loading = inject(LoadingService);
}
