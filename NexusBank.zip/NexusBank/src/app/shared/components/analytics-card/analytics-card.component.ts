import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-analytics-card',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './analytics-card.component.html',
  styleUrl: './analytics-card.component.css'
})
export class AnalyticsCardComponent {}