import { signal } from '@angular/core';

export const TransactionsState = signal<any>(null);