import { signal } from '@angular/core';

export const LoansState = signal<any>(null);