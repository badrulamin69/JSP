import { signal } from '@angular/core';

export const AnalyticsState = signal<any>(null);