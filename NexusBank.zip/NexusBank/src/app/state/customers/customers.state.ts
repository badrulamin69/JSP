import { signal } from '@angular/core';

export const CustomersState = signal<any>(null);