import { signal } from '@angular/core';

export const EmployeesState = signal<any>(null);