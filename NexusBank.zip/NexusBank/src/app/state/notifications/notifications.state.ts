import { signal } from '@angular/core';

export const NotificationsState = signal<any>(null);