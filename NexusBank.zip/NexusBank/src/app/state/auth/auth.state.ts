import { signal } from '@angular/core';

export const AuthState = signal<any>(null);