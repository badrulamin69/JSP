import { Component, ChangeDetectionStrategy, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-kpi-card',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm flex items-center gap-6">
      <div class="w-14 h-14 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center">
        <mat-icon>{{ icon }}</mat-icon>
      </div>
      <div>
        <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{{ title }}</p>
        <div class="flex items-baseline gap-2">
          <p class="text-2xl font-bold font-mono text-slate-900">{{ value }}</p>
          @if (trend) {
            <span 
              class="text-[10px] font-bold px-2 py-0.5 rounded-full"
              [class.bg-emerald-50]="trendType === 'positive'"
              [class.text-emerald-600]="trendType === 'positive'"
              [class.bg-rose-50]="trendType === 'negative'"
              [class.text-rose-600]="trendType === 'negative'"
            >
              {{ trendType === 'positive' ? '▲' : '▼' }} {{ trend }}
            </span>
          }
        </div>
        @if (description) {
          <p class="text-xs text-slate-500 mt-1">{{ description }}</p>
        }
      </div>
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class KpiCardComponent {
  @Input() title: string = '';
  @Input() value: string = '';
  @Input() icon: string = 'info';
  @Input() trend?: string;
  @Input() trendType?: 'positive' | 'negative';
  @Input() description?: string;
}
