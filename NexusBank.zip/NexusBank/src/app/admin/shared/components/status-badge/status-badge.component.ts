import { Component, ChangeDetectionStrategy, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-status-badge',
  standalone: true,
  imports: [CommonModule],
  template: `
    <span 
      class="px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider"
      [class.bg-emerald-50]="status.toLowerCase() === 'active' || status.toLowerCase() === 'verified' || status.toLowerCase() === 'approved'"
      [class.text-emerald-700]="status.toLowerCase() === 'active' || status.toLowerCase() === 'verified' || status.toLowerCase() === 'approved'"
      [class.border-emerald-100]="status.toLowerCase() === 'active' || status.toLowerCase() === 'verified' || status.toLowerCase() === 'approved'"

      [class.bg-amber-50]="status.toLowerCase() === 'pending' || status.toLowerCase() === 'in-progress'"
      [class.text-amber-700]="status.toLowerCase() === 'pending' || status.toLowerCase() === 'in-progress'"
      [class.border-amber-100]="status.toLowerCase() === 'pending' || status.toLowerCase() === 'in-progress'"

      [class.bg-rose-50]="status.toLowerCase() === 'suspended' || status.toLowerCase() === 'rejected' || status.toLowerCase() === 'failed'"
      [class.text-rose-700]="status.toLowerCase() === 'suspended' || status.toLowerCase() === 'rejected' || status.toLowerCase() === 'failed'"
      [class.border-rose-100]="status.toLowerCase() === 'suspended' || status.toLowerCase() === 'rejected' || status.toLowerCase() === 'failed'"

      [class.bg-blue-50]="status.toLowerCase() === 'completed'"
      [class.text-blue-700]="status.toLowerCase() === 'completed'"
      [class.border-blue-100]="status.toLowerCase() === 'completed'"

      [class.bg-slate-50]="status.toLowerCase() === 'inactive' || status.toLowerCase() === 'cancelled'"
      [class.text-slate-700]="status.toLowerCase() === 'inactive' || status.toLowerCase() === 'cancelled'"
      [class.border-slate-100]="status.toLowerCase() === 'inactive' || status.toLowerCase() === 'cancelled'"

      [class.border]="true"
    >
      {{ status }}
    </span>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class StatusBadgeComponent {
  @Input() status: string = '';
}
