import { Component, ChangeDetectionStrategy, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-empty-state',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="flex flex-col items-center justify-center p-10 text-slate-400">
      <mat-icon class="text-5xl mb-4">{{ icon }}</mat-icon>
      <p class="text-lg font-medium">{{ message }}</p>
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class EmptyStateComponent {
  @Input() message: string = 'No data available.';
  @Input() icon: string = 'info';
}
