import { Component, ChangeDetectionStrategy, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-export-toolbar',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="flex gap-3">
      <button (click)="exportPdf.emit()" class="px-4 py-2 rounded-xl bg-slate-50 text-slate-600 text-sm font-medium hover:bg-slate-100 transition-colors flex items-center gap-2">
        <mat-icon class="text-lg">picture_as_pdf</mat-icon> Export PDF
      </button>
      <button (click)="exportExcel.emit()" class="px-4 py-2 rounded-xl bg-slate-50 text-slate-600 text-sm font-medium hover:bg-slate-100 transition-colors flex items-center gap-2">
        <mat-icon class="text-lg">grid_on</mat-icon> Export Excel
      </button>
      <button (click)="print.emit()" class="px-4 py-2 rounded-xl bg-slate-50 text-slate-600 text-sm font-medium hover:bg-slate-100 transition-colors flex items-center gap-2">
        <mat-icon class="text-lg">print</mat-icon> Print
      </button>
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ExportToolbarComponent {
  @Output() exportPdf = new EventEmitter<void>();
  @Output() exportExcel = new EventEmitter<void>();
  @Output() print = new EventEmitter<void>();
}
