import { Component, ChangeDetectionStrategy, Input, ViewChild, ElementRef, AfterViewInit, OnChanges, SimpleChanges, inject, PLATFORM_ID, OnDestroy } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { Chart, ChartData, ChartOptions, ChartType } from 'chart.js/auto';

@Component({
  selector: 'app-chart',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm">
      <canvas #chartCanvas></canvas>
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ChartComponent implements AfterViewInit, OnChanges, OnDestroy {
  @Input() chartType: ChartType = 'bar';
  @Input() chartData: ChartData = { datasets: [] };
  @Input() chartOptions?: ChartOptions;

  @ViewChild('chartCanvas') chartCanvas!: ElementRef<HTMLCanvasElement>;
  chartInstance: Chart | null = null;

  platformId = inject(PLATFORM_ID);

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['chartData'] && !changes['chartData'].firstChange) {
      this.updateChart();
    }
  }

  ngAfterViewInit(): void {
    if (isPlatformBrowser(this.platformId)) {
      this.initializeChart();
    }
  }

  private initializeChart(): void {
    if (this.chartInstance) {
      this.chartInstance.destroy();
    }

    const ctx = this.chartCanvas.nativeElement.getContext('2d');
    if (ctx) {
      this.chartInstance = new Chart(ctx, {
        type: this.chartType,
        data: this.chartData,
        options: this.chartOptions || { responsive: true, maintainAspectRatio: false }
      });
    }
  }

  private updateChart(): void {
    if (this.chartInstance && this.chartData) {
      this.chartInstance.data = this.chartData;
      this.chartInstance.update();
    }
  }

  ngOnDestroy(): void {
    if (this.chartInstance) {
      this.chartInstance.destroy();
    }
  }
}
