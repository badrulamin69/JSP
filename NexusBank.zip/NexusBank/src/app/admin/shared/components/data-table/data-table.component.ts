import { Component, ChangeDetectionStrategy, Input, Output, EventEmitter, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { FormsModule } from '@angular/forms';

interface Column {
  key: string;
  label: string;
  type?: 'text' | 'number' | 'date' | 'currency' | 'status' | 'action';
  sortable?: boolean;
}

@Component({
  selector: 'app-data-table',
  standalone: true,
  imports: [CommonModule, MatIconModule, FormsModule],
  template: `
    <div class="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm overflow-hidden">
      <div class="p-6 flex flex-col md:flex-row items-center justify-between gap-4 border-b border-slate-100">
        <div class="relative w-full md:w-auto">
          <mat-icon class="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">search</mat-icon>
          <input 
            type="text" 
            placeholder="Search..."
            [(ngModel)]="searchTerm"
            (ngModelChange)="onSearch()"
            class="w-full pl-12 pr-4 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all text-sm"
          />
        </div>
        <div class="flex gap-3">
          <button class="px-4 py-2 rounded-xl bg-slate-50 text-slate-600 text-sm font-medium hover:bg-slate-100 transition-colors flex items-center gap-2">
            <mat-icon class="text-lg">filter_list</mat-icon> Filter
          </button>
          <button class="px-4 py-2 rounded-xl bg-slate-50 text-slate-600 text-sm font-medium hover:bg-slate-100 transition-colors flex items-center gap-2">
            <mat-icon class="text-lg">download</mat-icon> Export
          </button>
        </div>
      </div>

      <div class="overflow-x-auto admin-scrollbar">
        <table class="w-full text-left">
          <thead>
            <tr class="bg-slate-50/50">
              @for (col of columns; track col.key) {
                <th class="px-8 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                  <div class="flex items-center gap-1.5 cursor-pointer" (click)="onSort(col.key)" >
                    {{ col.label }}
                    @if (col.sortable) {
                      @if (currentSortKey() === col.key) {
                        <mat-icon class="text-xs">{{ currentSortDirection() === 'asc' ? 'arrow_upward' : 'arrow_downward' }}</mat-icon>
                      } @else {
                        <mat-icon class="text-xs text-slate-300">unfold_more</mat-icon>
                      }
                    }
                  </div>
                </th>
              }
            </tr>
          </thead>
          <tbody class="divide-y divide-slate-100">
            @for (row of paginatedData(); track row['id']) {
              <tr class="hover:bg-slate-50/50 transition-colors">
                @for (col of columns; track col.key) {
                  <td class="px-8 py-6 text-sm text-slate-700">
                    @switch (col.type) {
                      @case ('currency') { {{ row[col.key] | currency:'USD' }} }
                      @case ('date') { {{ row[col.key] | date:'mediumDate' }} }
                      @case ('status') { <span [class]="getStatusClass(row[col.key])" class="px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider">{{ row[col.key] }}</span> }
                      @case ('action') { <ng-content select="[action-buttons]" [attr.data-row-id]="row.id"></ng-content> }
                      @default { {{ row[col.key] }} }
                    }
                  </td>
                }
              </tr>
            }
            @if (paginatedData().length === 0) {
              <tr>
                <td [attr.colspan]="columns.length" class="text-center py-10 text-slate-500">
                  No data available.
                </td>
              </tr>
            }
          </tbody>
        </table>
      </div>

      @if (paginated) {
        <div class="p-6 border-t border-slate-100 flex items-center justify-between">
          <p class="text-sm text-slate-600">Showing {{ (currentPage() - 1) * pageSize + 1 }} - {{ (currentPage() * pageSize) < totalItems ? (currentPage() * pageSize) : totalItems }} of {{ totalItems }} items</p>
          <div class="flex gap-2">
            <button 
              (click)="prevPage()"
              [disabled]="currentPage() === 1"
              class="px-4 py-2 rounded-xl bg-slate-50 text-slate-600 text-sm font-medium hover:bg-slate-100 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >Previous</button>
            <button 
              (click)="nextPage()"
              [disabled]="currentPage() * pageSize >= totalItems"
              class="px-4 py-2 rounded-xl bg-slate-50 text-slate-600 text-sm font-medium hover:bg-slate-100 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >Next</button>
          </div>
        </div>
      }
    </div>
  `,
  styles: [`
    .admin-scrollbar::-webkit-scrollbar {
      height: 8px;
    }
    .admin-scrollbar::-webkit-scrollbar-track {
      background: #f1f5f9; /* slate-100 */
      border-radius: 10px;
    }
    .admin-scrollbar::-webkit-scrollbar-thumb {
      background: #cbd5e1; /* slate-300 */
      border-radius: 10px;
    }
    .admin-scrollbar::-webkit-scrollbar-thumb:hover {
      background: #94a3b8; /* slate-400 */
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DataTableComponent {
  @Input() data: Record<string, any>[] = [];
  @Input() columns: Column[] = [];
  @Input() paginated: boolean = false;
  @Input() pageSize: number = 10;
  @Output() pageChange = new EventEmitter<number>();
  @Output() sortChange = new EventEmitter<{ key: string, direction: 'asc' | 'desc' }>();
  @Output() filterChange = new EventEmitter<Record<string, unknown>>();
  @Output() search = new EventEmitter<string>();

  searchTerm = '';
  currentPage = signal(1);
  currentSortKey = signal<string | null>(null);
  currentSortDirection = signal<'asc' | 'desc'>('asc');

  get totalItems(): number { return this.data.length; }

  get filteredData(): Record<string, any>[] {
    if (!this.searchTerm) {
      return this.data;
    }
    const lowerCaseSearchTerm = this.searchTerm.toLowerCase();
    return this.data.filter(row => 
      Object.values(row).some(value => 
        String(value).toLowerCase().includes(lowerCaseSearchTerm)
      )
    );
  }

  get sortedData(): Record<string, any>[] {
    const data = [...this.filteredData];
    const key = this.currentSortKey();
    const direction = this.currentSortDirection();

    if (!key) return data;

    return data.sort((a, b) => {
      const valA = a[key];
      const valB = b[key];

      if (typeof valA === 'string' && typeof valB === 'string') {
        return direction === 'asc' ? valA.localeCompare(valB) : valB.localeCompare(valA);
      }
      if (typeof valA === 'number' && typeof valB === 'number') {
        return direction === 'asc' ? valA - valB : valB - valA;
      }
      return 0;
    });
  }

  paginatedData = signal<Record<string, any>[]>([]);

  ngOnChanges() {
    this.updatePaginatedData();
  }

  updatePaginatedData() {
    const start = (this.currentPage() - 1) * this.pageSize;
    const end = start + this.pageSize;
    this.paginatedData.set(this.sortedData.slice(start, end));
  }

  onSort(key: string) {
    if (this.currentSortKey() === key) {
      this.currentSortDirection.update(dir => (dir === 'asc' ? 'desc' : 'asc'));
    } else {
      this.currentSortKey.set(key);
      this.currentSortDirection.set('asc');
    }
    this.updatePaginatedData();
    this.sortChange.emit({ key, direction: this.currentSortDirection() });
  }

  onSearch() {
    this.currentPage.set(1);
    this.updatePaginatedData();
    this.search.emit(this.searchTerm);
  }

  prevPage() {
    if (this.currentPage() > 1) {
      this.currentPage.update(page => page - 1);
      this.updatePaginatedData();
      this.pageChange.emit(this.currentPage());
    }
  }

  nextPage() {
    if (this.currentPage() * this.pageSize < this.totalItems) {
      this.currentPage.update(page => page + 1);
      this.updatePaginatedData();
      this.pageChange.emit(this.currentPage());
    }
  }

  getStatusClass(status: string): string {
    switch (status.toLowerCase()) {
      case 'active': return 'bg-emerald-50 text-emerald-700 border border-emerald-100';
      case 'pending': return 'bg-amber-50 text-amber-700 border border-amber-100';
      case 'suspended': return 'bg-rose-50 text-rose-700 border border-rose-100';
      case 'verified': return 'bg-blue-50 text-blue-700 border border-blue-100';
      case 'rejected': return 'bg-red-50 text-red-700 border border-red-100';
      default: return 'bg-slate-50 text-slate-700 border border-slate-100';
    }
  }
}
