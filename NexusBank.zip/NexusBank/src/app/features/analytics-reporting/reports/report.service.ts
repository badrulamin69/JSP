import { Injectable, signal, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { Report } from '../../../core/models/models';
import { ApiService } from '../../../core/services/api.service';
import { Api } from '../../../core/constants/api.constant';

@Injectable({
  providedIn: 'root'
})
export class ReportService {
  private apiService = inject(ApiService);

  private _recentReports = signal<Report[]>([]);
  getRecentReports = this._recentReports.asReadonly();

  getReports(filter?: Record<string, string | number | boolean>): Observable<Report[]> {
    return this.apiService.get<Report[]>(Api.REPORTS, filter);
  }

  getReportById(id: string): Observable<Report> {
    return this.apiService.get<Report>(`${Api.REPORTS}/${id}`);
  }

  generateReport(reportType: string, params: Record<string, unknown>): Observable<Report> {
    return this.apiService.post<Report>(`${Api.REPORTS}/generate`, { reportType, ...params });
  }

  downloadReport(id: string): Observable<Blob> {
    return this.apiService.get<Blob>(`${Api.REPORTS}/${id}/download`);
  }

  deleteReport(id: string): Observable<void> {
    return this.apiService.delete<void>(`${Api.REPORTS}/${id}`);
  }
}
