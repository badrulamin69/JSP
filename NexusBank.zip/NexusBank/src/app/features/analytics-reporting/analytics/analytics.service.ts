import { Injectable, signal } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiService } from '../../../core/services/api.service';

@Injectable({
  providedIn: 'root'
})
export class AnalyticsService {

  constructor(private apiService: ApiService) { }

  private _realtimeTransactionVolume = signal<number>(0);
  getRealtimeTransactionVolume = this._realtimeTransactionVolume.asReadonly();

  getTransactionSummary(period: string): Observable<any> {
    return this.apiService.get<any>(`analytics/transactions-summary?period=${period}`);
  }

  getCustomerDemographics(): Observable<any> {
    return this.apiService.get<any>('analytics/customer-demographics');
  }

  getLoanPortfolioPerformance(): Observable<any> {
    return this.apiService.get<any>('analytics/loan-portfolio');
  }

  getRevenueTrends(): Observable<any> {
    return this.apiService.get<any>('analytics/revenue-trends');
  }
}
