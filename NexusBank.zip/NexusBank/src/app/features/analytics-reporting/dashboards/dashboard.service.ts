import { Injectable, signal } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiService } from '../../../core/services/api.service';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {

  constructor(private apiService: ApiService) { }

  private _dashboardWidgetsData = signal<any>(null);
  getDashboardWidgetsData = this._dashboardWidgetsData.asReadonly();

  getCustomerDashboardSummary(customerId: number): Observable<any> {
    // In a real app, this might use forkJoin to combine multiple service calls
    return this.apiService.get<any>(`dashboards/customer/${customerId}`);
  }

  getAdminDashboardOverview(): Observable<any> {
    return this.apiService.get<any>('dashboards/admin/overview');
  }

  getEmployeeDashboardTasks(employeeId: number): Observable<any> {
    return this.apiService.get<any>(`dashboards/employee/${employeeId}/tasks`);
  }
}
