import { Injectable, signal } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Designation, Employee } from '../../../core/models/model';
import { ApiService } from '../../../core/services/api.service'; // Adjust path

@Injectable({
  providedIn: 'root'
})
export class DesignationService {

  constructor(private apiService: ApiService) { }

  private _allDesignations = signal<Designation[]>([]);
  getAllDesignations = this._allDesignations.asReadonly();

  getDesignations(): Observable<Designation[]> {
    return this.apiService.get<Designation[]>('designations');
  }

  getDesignationById(id: number): Observable<Designation> {
    return this.apiService.get<Designation>(`designations/${id}`);
  }

  createDesignation(designation: Partial<Designation>): Observable<Designation> {
    return this.apiService.post<Designation>('designations', designation);
  }

  updateDesignation(id: number, designation: Partial<Designation>): Observable<Designation> {
    return this.apiService.put<Designation>(`designations/${id}`, designation);
  }

  deleteDesignation(id: number): Observable<void> {
    return this.apiService.delete<void>(`designations/${id}`);
  }
}
