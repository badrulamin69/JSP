import { Injectable, signal, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { Employee } from '../../../core/models/models';
import { ApiService } from '../../../core/services/api.service';
import { Api } from '../../../core/constants/api.constant';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  private apiService = inject(ApiService);

  private _employeeList = signal<Employee[]>([]);
  getEmployeeList = this._employeeList.asReadonly();

  getEmployees(filter?: Record<string, string | number | boolean>): Observable<Employee[]> {
    return this.apiService.get<Employee[]>(Api.EMPLOYEES, filter);
  }

  getEmployeeById(id: string): Observable<Employee> {
    return this.apiService.get<Employee>(`${Api.EMPLOYEES}/${id}`);
  }

  createEmployee(employee: Partial<Employee>): Observable<Employee> {
    return this.apiService.post<Employee>(Api.EMPLOYEES, employee);
  }

  updateEmployee(id: string, employee: Partial<Employee>): Observable<Employee> {
    return this.apiService.patch<Employee>(`${Api.EMPLOYEES}/${id}`, employee);
  }

  updateEmployeeStatus(id: string, status: 'Active' | 'Inactive' | 'Suspended'): Observable<Employee> {
    return this.apiService.patch<Employee>(`${Api.EMPLOYEES}/${id}`, { status });
  }

  searchEmployees(query: string): Observable<Employee[]> {
    return this.apiService.get<Employee[]>(Api.EMPLOYEES, { q: query });
  }
}
