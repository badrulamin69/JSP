import { Injectable, signal, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { Customer } from '../../../core/models/models';
import { ApiService } from '../../../core/services/api.service';
import { Api } from '../../../core/constants/api.constant';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  private apiService = inject(ApiService);

  private _customerList = signal<Customer[]>([]);
  getCustomerList = this._customerList.asReadonly();

  getCustomers(filter?: Record<string, string | number | boolean>): Observable<Customer[]> {
    return this.apiService.get<Customer[]>(Api.CUSTOMERS, filter);
  }

  getCustomerById(id: string): Observable<Customer> {
    return this.apiService.get<Customer>(`${Api.CUSTOMERS}/${id}`);
  }

  createCustomer(customer: Partial<Customer>): Observable<Customer> {
    return this.apiService.post<Customer>(Api.CUSTOMERS, customer);
  }

  updateCustomer(id: string, customer: Partial<Customer>): Observable<Customer> {
    return this.apiService.patch<Customer>(`${Api.CUSTOMERS}/${id}`, customer);
  }

  updateCustomerStatus(id: string, status: 'Active' | 'Inactive' | 'Blocked'): Observable<Customer> {
    return this.apiService.patch<Customer>(`${Api.CUSTOMERS}/${id}`, { status });
  }

  searchCustomers(query: string): Observable<Customer[]> {
    return this.apiService.get<Customer[]>(Api.CUSTOMERS, { q: query });
  }
}
