import { Injectable, signal } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Role, Permission, User } from '../../../core/models/model';
import { ApiService } from '../../../core/services/api.service'; // Adjust path

@Injectable({
  providedIn: 'root'
})
export class RoleService {

  constructor(private apiService: ApiService) { }

  private _allRoles = signal<Role[]>([]);
  getAllRoles = this._allRoles.asReadonly();

  getRoles(): Observable<Role[]> {
    return this.apiService.get<Role[]>('roles');
  }

  getRoleById(id: number): Observable<Role> {
    return this.apiService.get<Role>(`roles/${id}`);
  }

  createRole(role: Partial<Role>): Observable<Role> {
    return this.apiService.post<Role>('roles', role);
  }

  updateRole(id: number, role: Partial<Role>): Observable<Role> {
    return this.apiService.put<Role>(`roles/${id}`, role);
  }

  deleteRole(id: number): Observable<void> {
    return this.apiService.delete<void>(`roles/${id}`);
  }

  assignPermissionsToRole(roleId: number, permissionIds: number[]): Observable<Role> {
    return this.apiService.put<Role>(`roles/${roleId}/permissions`, { permissionIds });
  }
}
