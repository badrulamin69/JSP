import { Injectable, signal, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from '../../../core/models/models';
import { ApiService } from '../../../core/services/api.service';
import { Api } from '../../../core/constants/api.constant';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private apiService = inject(ApiService);

  private _loggedInUser = signal<User | null>(null);
  getLoggedInUser = this._loggedInUser.asReadonly();

  getUserProfile(id: string): Observable<User> {
    return this.apiService.get<User>(`${Api.USERS}/${id}`);
  }

  updateUserProfile(id: string, profile: Partial<User>): Observable<User> {
    return this.apiService.patch<User>(`${Api.USERS}/${id}`, profile);
  }

  changePassword(userId: string, passwordData: Record<string, unknown>): Observable<void> {
    return this.apiService.post<void>(`${Api.USERS}/${userId}/change-password`, passwordData);
  }
}
