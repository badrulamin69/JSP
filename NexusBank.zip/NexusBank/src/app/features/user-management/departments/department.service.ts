import { Injectable, signal } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Department, Employee } from '../../../core/models/model';
import { ApiService } from '../../../core/services/api.service'; // Adjust path

@Injectable({
  providedIn: 'root'
})
export class DepartmentService {

  constructor(private apiService: ApiService) { }

  private _allDepartments = signal<Department[]>([]);
  getAllDepartments = this._allDepartments.asReadonly();

  getDepartments(): Observable<Department[]> {
    return this.apiService.get<Department[]>('departments');
  }

  getDepartmentById(id: number): Observable<Department> {
    return this.apiService.get<Department>(`departments/${id}`);
  }

  createDepartment(department: Partial<Department>): Observable<Department> {
    return this.apiService.post<Department>('departments', department);
  }

  updateDepartment(id: number, department: Partial<Department>): Observable<Department> {
    return this.apiService.put<Department>(`departments/${id}`, department);
  }

  deleteDepartment(id: number): Observable<void> {
    return this.apiService.delete<void>(`departments/${id}`);
  }
}
