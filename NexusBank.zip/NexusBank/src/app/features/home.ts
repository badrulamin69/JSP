import { Component, ChangeDetectionStrategy, AfterViewInit, ElementRef, viewChild, signal, inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { RouterLink } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { animate, stagger } from 'motion';
import { Chart, registerables } from 'chart.js';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [RouterLink, MatIconModule],
  template: `
    <div id="homepage-container" class="pt-24 min-h-screen">
      <!-- Hero Section -->
      <section id="hero-section" class="max-w-7xl mx-auto px-4 sm:px-6 pt-10 pb-20 grid lg:grid-cols-2 gap-16 items-center">
        <div id="hero-text-container" #heroText class="space-y-8">
          <div id="regulated-badge" class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-100 text-emerald-700 text-xs font-bold tracking-wide uppercase">
            <span class="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
            Swiss Regulated Banking
          </div>
          <h1 id="main-headline" class="text-6xl md:text-7xl font-display font-bold leading-[1.1] tracking-tight text-slate-900">
            The Gold Standard for <br> 
            <span class="gradient-text">Global Finance.</span>
          </h1>
          <p id="hero-subtitle" class="text-lg text-slate-600 max-w-lg leading-relaxed font-light">
            Experience Swiss-grade security combined with modern fintech agility. Managed treasury, multi-currency accounts, and institutional-grade lending.
          </p>
          <div id="hero-actions" class="flex flex-col sm:flex-row gap-4">
            <button id="cta-get-started" routerLink="/register" class="px-8 py-4 bg-bank-blue text-white rounded-2xl font-bold shadow-xl shadow-bank-blue/20 hover:bg-blue-700 transition-all active:scale-95 leading-none">
              Get Started Now
            </button>
            <button id="cta-contact-sales" routerLink="/contact" class="px-8 py-4 bg-white border border-slate-200 text-slate-700 rounded-2xl font-bold hover:bg-slate-50 transition-all leading-none focus:outline-hidden">
              Contact Sales
            </button>
          </div>
          
          <div id="hero-stats" class="flex items-center gap-8 mt-4 pt-4 border-t border-slate-200">
            <div id="stat-secured" class="flex flex-col">
              <span class="text-2xl font-bold text-slate-900">$4.2B+</span>
              <span class="text-[10px] text-slate-500 uppercase font-bold tracking-widest">Assets Secured</span>
            </div>
            <div id="stat-countries" class="flex flex-col">
              <span class="text-2xl font-bold text-slate-900">180+</span>
              <span class="text-[10px] text-slate-500 uppercase font-bold tracking-widest">Countries</span>
            </div>
            <div id="stat-latency" class="flex flex-col">
              <span class="text-2xl font-bold text-slate-900">0.0s</span>
              <span class="text-[10px] text-slate-500 uppercase font-bold tracking-widest">Latency</span>
            </div>
          </div>
        </div>

        <!-- Hero Graphic / Dashboard Preview -->
        <div id="hero-graphic-container" #heroGraphic class="relative">
          <div class="absolute -top-12 -right-12 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl opacity-50"></div>
          <div class="absolute -bottom-12 -left-12 w-80 h-80 bg-bank-blue/10 rounded-full blur-3xl opacity-50"></div>
          
          <div id="dashboard-mockup" class="relative bg-white rounded-[2.5rem] p-6 shadow-2xl border border-slate-200 overflow-hidden z-10 transition-transform duration-500 hover:scale-[1.01]">
            <div class="flex items-center justify-between mb-8">
              <div>
                <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Total Balance</p>
                <h3 class="text-3xl font-display font-bold text-slate-900">€1,248,500.00</h3>
              </div>
              <div class="flex gap-2">
                <span class="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-1 rounded-full">+12.4%</span>
              </div>
            </div>
            
            <div id="chart-wrapper" class="h-64 relative">
              <canvas id="hero-chart" #balanceChart></canvas>
            </div>
            
            <div id="mini-widgets" class="grid grid-cols-12 gap-4 mt-8">
              <div id="widget-status" class="col-span-4 p-4 bg-slate-50 rounded-2xl border border-slate-100">
                <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Status</p>
                <div class="space-y-2 mt-3">
                   <div class="h-1.5 bg-slate-200 rounded-full w-full"></div>
                   <div class="h-1.5 bg-slate-200 rounded-full w-3/4"></div>
                </div>
              </div>
              <div id="widget-growth" class="col-span-8 p-4 bg-white rounded-2xl border border-slate-100 shadow-sm">
                <div class="flex justify-between items-center mb-3">
                  <p class="text-xs font-bold text-slate-800">Growth</p>
                  <div class="flex gap-1.5">
                    <div class="w-1.5 h-1.5 rounded-full bg-bank-blue"></div>
                    <div class="w-1.5 h-1.5 rounded-full bg-bank-emerald"></div>
                  </div>
                </div>
                <div class="h-12 flex items-end gap-1.5">
                  <div class="flex-1 bg-slate-100 h-1/2 rounded-t-sm"></div>
                  <div class="flex-1 bg-bank-blue h-full rounded-t-sm"></div>
                  <div class="flex-1 bg-slate-100 h-2/3 rounded-t-sm"></div>
                  <div class="flex-1 bg-bank-emerald h-3/4 rounded-t-sm"></div>
                  <div class="flex-1 bg-slate-100 h-4/5 rounded-t-sm"></div>
                </div>
              </div>
            </div>
          </div>

          <!-- Floating Badge -->
          <div id="verified-badge" class="absolute bottom-10 -right-4 z-20 glass p-4 rounded-2xl premium-shadow flex items-center gap-4 animate-bounce duration-[3s]">
            <div class="w-10 h-10 bg-emerald-100 rounded-full flex items-center justify-center text-emerald-600">
              <mat-icon class="text-xl">verified</mat-icon>
            </div>
            <div>
              <p class="text-sm font-bold text-slate-900">Transaction Verified</p>
              <p class="text-[10px] text-slate-500 uppercase tracking-widest">Encrypted Tier Layer</p>
            </div>
          </div>
        </div>
      </section>

      <!-- Stats Section -->
      <section id="stats-ribbon" class="bg-bank-slate py-20">
        <div class="max-w-7xl mx-auto px-4 sm:px-6">
          <div class="grid grid-cols-2 lg:grid-cols-4 gap-8">
            @for (stat of stats(); track stat.label) {
              <div class="text-center space-y-2">
                <h3 class="text-4xl font-display font-bold text-bank-navy">{{ stat.value }}</h3>
                <p class="text-slate-500 font-medium">{{ stat.label }}</p>
              </div>
            }
          </div>
        </div>
      </section>

      <!-- Features Grid -->
      <section id="features-section" class="py-32">
        <div class="max-w-7xl mx-auto px-4 sm:px-6">
          <div class="text-center max-w-2xl mx-auto mb-20 space-y-4">
            <h2 id="features-title" class="text-4xl md:text-5xl font-display font-bold text-bank-navy tracking-tight">Security in every layer.</h2>
            <p id="features-desc" class="text-slate-500 text-lg font-light">We combine traditional Swiss banking principles with cutting-edge technology to protect your assets.</p>
          </div>

          <div id="features-grid" #featuresGrid class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            @for (feature of features(); track feature.title) {
              <div class="group p-8 rounded-3xl bg-white border border-slate-100 hover:border-bank-blue transition-all hover:premium-shadow active:scale-95 cursor-pointer">
                <div class="w-14 h-14 rounded-2xl bg-slate-50 flex items-center justify-center text-bank-blue mb-6 group-hover:bg-bank-blue group-hover:text-white transition-colors">
                  <mat-icon>{{ feature.icon }}</mat-icon>
                </div>
                <h3 class="text-xl font-bold text-bank-navy mb-3">{{ feature.title }}</h3>
                <p class="text-slate-500 leading-relaxed font-light">{{ feature.description }}</p>
              </div>
            }
          </div>
        </div>
      </section>

      <!-- Portal Hub -->
      <section id="portals-section" class="max-w-7xl mx-auto px-4 sm:px-6 mb-32">
         <div class="text-center mb-16">
            <h2 class="text-3xl font-display font-bold text-slate-900 tracking-tight">Access Your Terminal</h2>
            <p class="text-slate-500 mt-2 font-light">Select your point of entry to the Smart Secure ecosystem.</p>
         </div>
         
         <div id="portals-container" class="grid md:grid-cols-3 gap-8">
            <!-- CUSTOMER PORTAL -->
            <a id="portal-customer" routerLink="/customer" class="flex-1 bg-linear-to-br from-blue-700 to-indigo-900 p-10 rounded-[3rem] shadow-2xl hover:shadow-blue-500/40 hover:translate-y-[-8px] transition-all group relative overflow-hidden text-white">
               <div class="absolute -bottom-12 -right-12 w-48 h-48 bg-white/10 rounded-full blur-3xl group-hover:scale-150 transition-transform duration-1000"></div>
               <div class="relative z-10">
                  <div class="w-16 h-16 bg-white/20 text-white rounded-2xl flex items-center justify-center mb-10 group-hover:rotate-12 transition-transform">
                     <mat-icon class="text-3xl">account_balance</mat-icon>
                  </div>
                  <h3 class="text-2xl font-bold font-display leading-tight">Customer<br>Portal</h3>
                  <p class="text-blue-100/60 mt-3 text-sm font-light">Your personal wealth hub for daily banking needs.</p>
                  <div class="mt-8 flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-blue-300">
                     Enter Portal <mat-icon class="text-sm">arrow_forward</mat-icon>
                  </div>
               </div>
            </a>

            <!-- ADMIN TERMINAL -->
            <a id="portal-admin" routerLink="/admin" class="flex-1 bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm hover:shadow-2xl hover:translate-y-[-8px] transition-all group overflow-hidden relative">
               <div class="absolute -bottom-12 -right-12 w-32 h-32 bg-blue-50 rounded-full blur-2xl group-hover:bg-blue-100 transition-colors"></div>
               <div class="relative z-10">
                  <div class="w-16 h-16 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center mb-10 group-hover:scale-110 transition-transform">
                     <mat-icon class="text-3xl">admin_panel_settings</mat-icon>
                  </div>
                  <h3 class="text-2xl font-bold text-slate-900 leading-tight">Admin<br>Terminal</h3>
                  <p class="text-slate-500 mt-3 text-sm font-light">Institutional control for system wide management.</p>
                  <div class="mt-8 flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-blue-600">
                     Access Core <mat-icon class="text-sm">arrow_forward</mat-icon>
                  </div>
               </div>
            </a>

            <!-- STAFF TERMINAL -->
            <a id="portal-staff" routerLink="/employee" class="flex-1 bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm hover:shadow-2xl hover:translate-y-[-8px] transition-all group overflow-hidden relative">
               <div class="absolute -bottom-12 -right-12 w-32 h-32 bg-emerald-50 rounded-full blur-2xl group-hover:bg-emerald-100 transition-colors"></div>
               <div class="relative z-10">
                  <div class="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center mb-10 group-hover:scale-110 transition-transform">
                     <mat-icon class="text-3xl">badge</mat-icon>
                  </div>
                  <h3 class="text-2xl font-bold text-slate-900 leading-tight">Staff<br>Hq</h3>
                  <p class="text-slate-500 mt-3 text-sm font-light">Operations hub for employee-facing workflows.</p>
                  <div class="mt-8 flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-emerald-600">
                     Join Shift <mat-icon class="text-sm">arrow_forward</mat-icon>
                  </div>
               </div>
            </a>
         </div>
      </section>

      <!-- CTA Section -->
      <section id="cta-bottom" class="max-w-7xl mx-auto px-4 sm:px-6 mb-32">
        <div class="relative bg-bank-navy rounded-[3rem] overflow-hidden p-8 md:p-20 text-center">
          <div class="absolute top-0 right-0 w-96 h-96 bg-bank-blue/20 blur-[120px] -mr-48 -mt-48"></div>
          <div class="absolute bottom-0 left-0 w-96 h-96 bg-emerald-500/10 blur-[120px] -ml-48 -mb-48"></div>
          
          <div class="relative z-10 max-w-3xl mx-auto space-y-8">
            <h2 id="cta-title" class="text-4xl md:text-6xl font-display font-bold text-white tracking-tight">The future of banking is here.</h2>
            <p id="cta-desc" class="text-xl text-slate-400 font-light">Join the thousands of global citizens and enterprises who have already switched to Smart Secure.</p>
            <div id="cta-buttons" class="flex flex-col sm:flex-row justify-center gap-4">
              <button id="cta-bottom-register" routerLink="/register" class="bg-bank-blue text-white px-10 py-5 rounded-2xl font-bold text-lg hover:bg-blue-600 transition-all shadow-xl shadow-bank-blue/20">
                Get Started Today
              </button>
              <button id="cta-bottom-contact" routerLink="/contact" class="px-10 py-5 rounded-2xl font-bold text-lg text-white border border-white/10 hover:bg-white/5 transition-all">
                Speak with an Advisor
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  `,
  styles: [
    `
      canvas {
        width: 100% !important;
        height: 100% !important;
      }
    `
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class Homepage implements AfterViewInit {
  platformId = inject(PLATFORM_ID);
  private static chartRegistered = false;
  heroText = viewChild<ElementRef>('heroText');
  heroGraphic = viewChild<ElementRef>('heroGraphic');
  featuresGrid = viewChild<ElementRef>('featuresGrid');
  balanceChart = viewChild<ElementRef<HTMLCanvasElement>>('balanceChart');

  stats = signal([
    { label: 'Active Users', value: '50k+' },
    { label: 'Asset Under Mgmt', value: '$12B+' },
    { label: 'Countries Covered', value: '140+' },
    { label: 'Security Score', value: '99.9%' },
  ]);

  features = signal([
    {
      icon: 'verified_user',
      title: 'Biometric Security',
      description: 'Access your account with face and fingerprint recognition, powered by advanced Swiss encryption.'
    },
    {
      icon: 'language',
      title: 'Global Transfers',
      description: 'Send and receive money internationally in minutes with zero hidden fees and live exchange rates.'
    },
    {
      icon: 'credit_card',
      title: 'Virtual & Physical Cards',
      description: 'Generate instant virtual cards for online shopping and receive a premium metal card for daily use.'
    },
    {
      icon: 'analytics',
      title: 'Smart Analytics',
      description: 'Get deep insights into your spending habits with AI-powered categorization and wealth tracking.'
    },
    {
      icon: 'account_balance',
      title: 'Enterprise Accounts',
      description: 'Tailored banking solutions for multi-national corporations with multi-role access controls.'
    },
    {
      icon: 'psychology',
      title: 'AI Advisory',
      description: 'Personalized investment suggestions based on global market trends and your risk profile.'
    }
  ]);

  ngAfterViewInit() {
    if (isPlatformBrowser(this.platformId)) {
      this.initAnimations();
      this.initChart();
    }
  }

  private initAnimations() {
    const textEl = this.heroText()?.nativeElement;
    const graphicEl = this.heroGraphic()?.nativeElement;
    const features = this.featuresGrid()?.nativeElement.children;

    if (textEl) {
      animate(textEl, { opacity: [0, 1], y: [40, 0] }, { duration: 1, ease: 'easeOut' });
    }
    if (graphicEl) {
      animate(graphicEl, { opacity: [0, 1], scale: [0.95, 1] }, { duration: 1.2, delay: 0.2, ease: 'easeOut' });
    }
    if (features) {
      animate(Array.from(features), { opacity: [0, 1], y: [30, 0] }, { delay: stagger(0.1), duration: 0.8 });
    }
  }

  private initChart() {
    if (isPlatformBrowser(this.platformId) && !Homepage.chartRegistered) {
      Chart.register(...registerables);
      Homepage.chartRegistered = true;
    }
    const canvas = this.balanceChart()?.nativeElement;
    if (!canvas) return;

    new Chart(canvas, {
      type: 'line',
      data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'],
        datasets: [{
          label: 'Balance',
          data: [3200000, 3500000, 3400000, 3900000, 4200000, 4100000, 4820150],
          borderColor: '#2563EB',
          backgroundColor: (context) => {
            const chart = context.chart;
            const {ctx, chartArea} = chart;
            if (!chartArea) return undefined;
            const gradient = ctx.createLinearGradient(0, chartArea.top, 0, chartArea.bottom);
            gradient.addColorStop(0, 'rgba(37, 99, 235, 0.4)');
            gradient.addColorStop(1, 'rgba(37, 99, 235, 0.0)');
            return gradient;
          },
          borderWidth: 4,
          fill: true,
          tension: 0.4,
          pointRadius: 0,
          pointHoverRadius: 6,
          pointHoverBackgroundColor: '#2563EB',
          pointHoverBorderColor: '#fff',
          pointHoverBorderWidth: 3
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            mode: 'index',
            intersect: false,
            backgroundColor: '#0F172A',
            titleFont: { family: 'Outfit', size: 12 },
            bodyFont: { family: 'Inter', size: 14 },
            padding: 12,
            cornerRadius: 12,
            callbacks: {
              label: (context) => context.parsed.y !== null ? `$${context.parsed.y.toLocaleString()}` : ''
            }
          }
        },
        scales: {
          x: { display: false },
          y: { display: false }
        }
      }
    });
  }
}
