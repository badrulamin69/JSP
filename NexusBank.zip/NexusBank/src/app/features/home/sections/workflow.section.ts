import { Component, ChangeDetectionStrategy, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-workflow-section',
  standalone: true,
  imports: [MatIconModule],
  template: `
    <section id="workflow-section" class="section-padding bg-white relative overflow-hidden">
      <div class="section-container relative z-10">
        <div class="text-center max-w-2xl mx-auto mb-16 space-y-5">
          <span class="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-50 text-emerald-600 text-xs font-bold tracking-wide uppercase">
            <mat-icon class="text-sm">route</mat-icon>
            How It Works
          </span>
          <h2 class="text-4xl md:text-5xl font-display font-bold text-bank-navy tracking-tight">
            Smart banking in<br>
            <span class="gradient-text">three simple steps.</span>
          </h2>
          <p class="text-slate-500 text-lg font-light">From account creation to global transactions — we've streamlined every step.</p>
        </div>

        <div class="grid md:grid-cols-3 gap-8 md:gap-6 relative">
          <!-- Connector line (desktop only) -->
          <div class="hidden md:block absolute top-24 left-[20%] right-[20%] h-0.5 bg-gradient-to-r from-bank-blue via-emerald-400 to-violet-500 opacity-20"></div>

          @for (step of steps(); track step.number; let i = $index) {
            <div class="relative text-center group">
              <!-- Step Number -->
              <div class="w-16 h-16 mx-auto rounded-2xl flex items-center justify-center mb-8 transition-all duration-300 group-hover:scale-110 group-hover:rotate-6 relative z-10"
                   [class]="step.bgClass">
                <span class="text-2xl font-display font-bold" [class]="step.textClass">{{ step.number }}</span>
              </div>

              <!-- Content -->
              <div class="p-6 rounded-3xl border border-slate-100 bg-white card-hover">
                <div class="w-14 h-14 mx-auto rounded-2xl flex items-center justify-center mb-5" [class]="step.iconBg">
                  <mat-icon [class]="step.iconColor" class="text-2xl">{{ step.icon }}</mat-icon>
                </div>
                <h3 class="text-xl font-bold text-bank-navy mb-3">{{ step.title }}</h3>
                <p class="text-slate-500 text-sm font-light leading-relaxed">{{ step.description }}</p>

                <div class="mt-5 flex flex-wrap justify-center gap-2">
                  @for (tag of step.tags; track tag) {
                    <span class="px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider" [class]="step.tagClass">{{ tag }}</span>
                  }
                </div>
              </div>
            </div>
          }
        </div>
      </div>
    </section>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class WorkflowSection {
  steps = signal([
    {
      number: '01', icon: 'person_add', title: 'Create Account',
      description: 'Sign up in under 2 minutes with digital KYC verification. No paperwork, no branch visits required.',
      tags: ['Instant KYC', 'Digital ID', 'Secure'],
      bgClass: 'bg-bank-blue text-white shadow-lg shadow-bank-blue/30',
      textClass: 'text-white',
      iconBg: 'bg-blue-50', iconColor: 'text-bank-blue',
      tagClass: 'bg-blue-50 text-bank-blue',
    },
    {
      number: '02', icon: 'account_balance_wallet', title: 'Fund & Configure',
      description: 'Connect your existing accounts, set up multi-currency wallets, and configure your security preferences.',
      tags: ['Multi-Currency', 'Auto-Config', 'Fast'],
      bgClass: 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/30',
      textClass: 'text-white',
      iconBg: 'bg-emerald-50', iconColor: 'text-emerald-600',
      tagClass: 'bg-emerald-50 text-emerald-600',
    },
    {
      number: '03', icon: 'rocket_launch', title: 'Start Banking',
      description: 'Transfer globally, invest smartly, manage loans, and monitor your wealth — all from one premium dashboard.',
      tags: ['Global', 'Invest', 'Manage'],
      bgClass: 'bg-violet-500 text-white shadow-lg shadow-violet-500/30',
      textClass: 'text-white',
      iconBg: 'bg-violet-50', iconColor: 'text-violet-600',
      tagClass: 'bg-violet-50 text-violet-600',
    },
  ]);
}
