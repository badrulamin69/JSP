import { Component, ChangeDetectionStrategy, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-international-section',
  standalone: true,
  imports: [MatIconModule],
  template: `
    <section id="international-section" class="section-padding relative overflow-hidden bg-bank-navy">
      <div class="absolute inset-0">
        <div class="absolute top-1/4 left-1/4 w-96 h-96 bg-bank-blue/10 rounded-full blur-[120px]"></div>
        <div class="absolute bottom-1/4 right-1/4 w-96 h-96 bg-emerald-500/8 rounded-full blur-[120px]"></div>
      </div>

      <div class="section-container relative z-10">
        <div class="grid lg:grid-cols-2 gap-16 items-center">
          <!-- Left Content -->
          <div class="space-y-8">
            <span class="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/5 border border-white/10 text-bank-blue-light text-xs font-bold tracking-wide uppercase">
              <mat-icon class="text-sm">public</mat-icon>
              Global Banking
            </span>
            <h2 class="text-4xl md:text-5xl font-display font-bold text-white tracking-tight leading-tight">
              Send money<br>
              <span class="gradient-text-premium">anywhere, instantly.</span>
            </h2>
            <p class="text-slate-400 text-lg font-light leading-relaxed max-w-lg">
              Transfer funds to 180+ countries with real-time exchange rates, zero hidden fees, and SWIFT-backed security.
            </p>

            <div class="grid grid-cols-2 gap-4">
              @for (stat of globalStats(); track stat.label) {
                <div class="p-5 rounded-2xl bg-white/5 border border-white/8 hover:bg-white/8 transition-colors">
                  <mat-icon class="text-2xl mb-3" [class]="stat.iconColor">{{ stat.icon }}</mat-icon>
                  <p class="text-2xl font-display font-bold text-white">{{ stat.value }}</p>
                  <p class="text-xs text-slate-400 mt-1">{{ stat.label }}</p>
                </div>
              }
            </div>
          </div>

          <!-- Right: Transfer Card -->
          <div class="space-y-6">
            <!-- Live Exchange Rates -->
            <div class="glass-dark rounded-3xl p-6 md:p-8">
              <div class="flex items-center justify-between mb-6">
                <h3 class="text-sm font-bold text-white">Live Exchange Rates</h3>
                <span class="flex items-center gap-1.5 text-[10px] font-bold text-emerald-400 uppercase tracking-wider">
                  <span class="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse"></span>
                  Live
                </span>
              </div>

              <div class="space-y-3">
                @for (rate of exchangeRates(); track rate.pair) {
                  <div class="flex items-center justify-between p-4 rounded-2xl bg-white/5 hover:bg-white/8 transition-colors group">
                    <div class="flex items-center gap-3">
                      <div class="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-lg">{{ rate.flag }}</div>
                      <div>
                        <p class="text-sm font-bold text-white">{{ rate.pair }}</p>
                        <p class="text-[10px] text-slate-400">{{ rate.name }}</p>
                      </div>
                    </div>
                    <div class="text-right">
                      <p class="text-sm font-bold text-white font-mono">{{ rate.rate }}</p>
                      <p class="text-[10px] font-bold" [class]="rate.change > 0 ? 'text-emerald-400' : 'text-red-400'">
                        {{ rate.change > 0 ? '+' : '' }}{{ rate.change }}%
                      </p>
                    </div>
                  </div>
                }
              </div>
            </div>

            <!-- Quick Transfer Card -->
            <div class="glass-dark rounded-3xl p-6">
              <div class="flex items-center gap-3 mb-5">
                <div class="w-10 h-10 rounded-xl bg-bank-blue/20 flex items-center justify-center">
                  <mat-icon class="text-bank-blue-light text-lg">swap_horiz</mat-icon>
                </div>
                <div>
                  <p class="text-sm font-bold text-white">Quick International Transfer</p>
                  <p class="text-[10px] text-slate-400">Arrives in under 30 seconds</p>
                </div>
              </div>
              <div class="flex items-center justify-between p-4 rounded-2xl bg-white/5">
                <div>
                  <p class="text-[10px] text-slate-400 uppercase tracking-wider font-bold">You Send</p>
                  <p class="text-xl font-display font-bold text-white mt-1">$10,000.00</p>
                </div>
                <mat-icon class="text-slate-500">east</mat-icon>
                <div class="text-right">
                  <p class="text-[10px] text-slate-400 uppercase tracking-wider font-bold">They Receive</p>
                  <p class="text-xl font-display font-bold text-emerald-400 mt-1">€9,200.00</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class InternationalSection {
  globalStats = signal([
    { icon: 'public', value: '180+', label: 'Countries Supported', iconColor: 'text-bank-blue-light' },
    { icon: 'currency_exchange', value: '45+', label: 'Currencies Available', iconColor: 'text-emerald-400' },
    { icon: 'speed', value: '<30s', label: 'Transfer Speed', iconColor: 'text-amber-400' },
    { icon: 'money_off', value: '$0', label: 'Hidden Fees', iconColor: 'text-violet-400' },
  ]);

  exchangeRates = signal([
    { flag: '🇺🇸', pair: 'USD / EUR', name: 'US Dollar to Euro', rate: '0.9200', change: 0.12 },
    { flag: '🇬🇧', pair: 'GBP / USD', name: 'British Pound to Dollar', rate: '1.2800', change: -0.08 },
    { flag: '🇨🇭', pair: 'USD / CHF', name: 'Dollar to Swiss Franc', rate: '0.8800', change: 0.24 },
    { flag: '🇯🇵', pair: 'USD / JPY', name: 'Dollar to Japanese Yen', rate: '149.50', change: -0.15 },
  ]);
}
