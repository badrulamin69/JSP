import { Component, ChangeDetectionStrategy, AfterViewInit, ElementRef, viewChild, signal, inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { RouterLink } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { Chart, registerables } from 'chart.js';

@Component({
  selector: 'app-hero-section',
  standalone: true,
  imports: [RouterLink, MatIconModule],
  template: `
    <section id="hero-section" class="relative overflow-hidden bg-hero-gradient pt-28 pb-20 lg:pt-36 lg:pb-32">
      <!-- Background decorations -->
      <div class="absolute inset-0 bg-mesh pointer-events-none"></div>
      <div class="absolute top-20 left-10 w-72 h-72 bg-bank-blue/5 rounded-full blur-3xl"></div>
      <div class="absolute bottom-10 right-10 w-96 h-96 bg-emerald-500/5 rounded-full blur-3xl"></div>
      <div class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-indigo-500/[0.02] rounded-full blur-3xl"></div>

      <div class="section-container relative z-10">
        <div class="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          <!-- Left: Text Content -->
          <div id="hero-text-container" #heroText class="space-y-8">
            <div id="regulated-badge" class="inline-flex items-center gap-2.5 px-4 py-2 rounded-full glass-emerald text-emerald-700 text-xs font-bold tracking-wide uppercase">
              <span class="relative flex h-2.5 w-2.5">
                <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span class="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
              </span>
              Swiss Regulated · FINMA Licensed
            </div>

            <h1 id="main-headline" class="text-5xl sm:text-6xl md:text-7xl lg:text-[5.5rem] font-display font-bold leading-[1.05] tracking-tight text-bank-navy">
              The Future of
              <br>
              <span class="gradient-text-premium">Global Finance.</span>
            </h1>

            <p id="hero-subtitle" class="text-lg md:text-xl text-slate-500 max-w-lg leading-relaxed font-light">
              Swiss-grade security meets modern fintech agility. Multi-currency accounts, institutional lending, and treasury management — all in one platform.
            </p>

            <div id="hero-actions" class="flex flex-col sm:flex-row gap-4">
              <button id="cta-open-account" routerLink="/register" class="btn-primary text-base">
                Open Free Account
                <mat-icon class="ml-2 text-base align-middle">arrow_forward</mat-icon>
              </button>
              <button id="cta-explore" routerLink="/services" class="btn-secondary text-base group">
                Explore Features
                <mat-icon class="ml-1 text-base align-middle group-hover:translate-x-1 transition-transform">east</mat-icon>
              </button>
            </div>

            <!-- Trust indicators -->
            <div id="hero-trust" class="flex flex-wrap items-center gap-6 pt-6 border-t border-slate-200/60">
              <div class="flex -space-x-3">
                <img src="https://i.pravatar.cc/40?u=h1" alt="User" class="w-9 h-9 rounded-full border-2 border-white shadow-sm">
                <img src="https://i.pravatar.cc/40?u=h2" alt="User" class="w-9 h-9 rounded-full border-2 border-white shadow-sm">
                <img src="https://i.pravatar.cc/40?u=h3" alt="User" class="w-9 h-9 rounded-full border-2 border-white shadow-sm">
                <img src="https://i.pravatar.cc/40?u=h4" alt="User" class="w-9 h-9 rounded-full border-2 border-white shadow-sm">
                <div class="w-9 h-9 rounded-full border-2 border-white bg-bank-blue text-white flex items-center justify-center text-[10px] font-bold shadow-sm">50K+</div>
              </div>
              <div>
                <div class="flex items-center gap-1">
                  @for (i of [1,2,3,4,5]; track i) {
                    <mat-icon class="text-amber-400 text-sm">star</mat-icon>
                  }
                </div>
                <p class="text-xs text-slate-400 font-medium mt-0.5">Trusted by 50,000+ clients worldwide</p>
              </div>
            </div>
          </div>

          <!-- Right: Dashboard Preview -->
          <div id="hero-graphic-container" #heroGraphic class="relative">
            <!-- Background glows -->
            <div class="absolute -top-16 -right-16 w-72 h-72 bg-bank-blue/8 rounded-full blur-3xl animate-float-slow"></div>
            <div class="absolute -bottom-16 -left-16 w-80 h-80 bg-emerald-500/8 rounded-full blur-3xl animate-float-delay"></div>

            <!-- Main Dashboard Card -->
            <div id="dashboard-mockup" class="relative bg-white rounded-[2rem] md:rounded-[2.5rem] p-5 md:p-7 premium-shadow-lg border border-slate-100/80 overflow-hidden z-10 transition-transform duration-700 hover:scale-[1.015]">
              <!-- Dashboard Header -->
              <div class="flex items-center justify-between mb-6">
                <div>
                  <p class="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em]">Total Portfolio</p>
                  <h3 class="text-2xl md:text-3xl font-display font-bold text-bank-navy mt-1">€1,248,500<span class="text-base text-slate-400 font-normal">.00</span></h3>
                </div>
                <div class="flex items-center gap-2">
                  <span class="inline-flex items-center gap-1 text-xs font-bold text-emerald-600 bg-emerald-50 px-3 py-1.5 rounded-full">
                    <mat-icon class="text-xs">trending_up</mat-icon>
                    +12.4%
                  </span>
                </div>
              </div>

              <!-- Chart -->
              <div id="chart-wrapper" class="h-48 md:h-56 relative">
                <canvas id="hero-chart" #balanceChart></canvas>
              </div>

              <!-- Mini Widgets -->
              <div id="mini-widgets" class="grid grid-cols-3 gap-3 mt-6">
                <div class="p-3 bg-slate-50/80 rounded-2xl border border-slate-100">
                  <p class="text-[9px] font-bold text-slate-400 uppercase tracking-[0.15em]">Revenue</p>
                  <p class="text-sm font-bold text-bank-navy mt-1">$2.4M</p>
                  <div class="flex items-center gap-1 mt-2">
                    <div class="flex-1 h-1 bg-bank-blue/20 rounded-full overflow-hidden">
                      <div class="h-full w-4/5 bg-bank-blue rounded-full"></div>
                    </div>
                    <span class="text-[9px] text-slate-400 font-bold">80%</span>
                  </div>
                </div>
                <div class="p-3 bg-slate-50/80 rounded-2xl border border-slate-100">
                  <p class="text-[9px] font-bold text-slate-400 uppercase tracking-[0.15em]">Clients</p>
                  <p class="text-sm font-bold text-bank-navy mt-1">8,241</p>
                  <div class="flex items-center gap-1 mt-2">
                    <div class="flex-1 h-1 bg-emerald-500/20 rounded-full overflow-hidden">
                      <div class="h-full w-3/5 bg-emerald-500 rounded-full"></div>
                    </div>
                    <span class="text-[9px] text-slate-400 font-bold">60%</span>
                  </div>
                </div>
                <div class="p-3 bg-slate-50/80 rounded-2xl border border-slate-100">
                  <p class="text-[9px] font-bold text-slate-400 uppercase tracking-[0.15em]">Growth</p>
                  <p class="text-sm font-bold text-emerald-600 mt-1">+24.8%</p>
                  <div class="h-8 flex items-end gap-1 mt-1">
                    @for (h of barHeights(); track $index) {
                      <div class="flex-1 rounded-t-sm transition-all" [style.height.%]="h" [class]="$index === barHeights().length - 1 ? 'bg-emerald-500' : 'bg-slate-200'"></div>
                    }
                  </div>
                </div>
              </div>
            </div>

            <!-- Floating Transaction Widget -->
            <div id="transaction-widget" class="absolute -left-4 md:-left-8 top-1/3 z-20 glass-card p-4 rounded-2xl animate-float hidden sm:flex items-center gap-3">
              <div class="w-10 h-10 bg-emerald-100 rounded-xl flex items-center justify-center">
                <mat-icon class="text-emerald-600 text-lg">check_circle</mat-icon>
              </div>
              <div>
                <p class="text-xs font-bold text-slate-900">+$12,500.00</p>
                <p class="text-[10px] text-slate-400">Wire Transfer Received</p>
              </div>
            </div>

            <!-- Floating Security Badge -->
            <div id="security-badge" class="absolute -right-2 md:-right-6 bottom-16 z-20 glass-card p-4 rounded-2xl animate-float-delay hidden sm:flex items-center gap-3">
              <div class="w-10 h-10 bg-bank-blue/10 rounded-xl flex items-center justify-center">
                <mat-icon class="text-bank-blue text-lg">verified</mat-icon>
              </div>
              <div>
                <p class="text-xs font-bold text-slate-900">256-bit Encrypted</p>
                <p class="text-[10px] text-slate-400">Swiss Security Layer</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class HeroSection implements AfterViewInit {
  private platformId = inject(PLATFORM_ID);
  private static chartRegistered = false;
  balanceChart = viewChild<ElementRef<HTMLCanvasElement>>('balanceChart');

  barHeights = signal([30, 50, 40, 65, 55, 75, 90]);

  ngAfterViewInit() {
    if (isPlatformBrowser(this.platformId)) {
      this.initChart();
    }
  }

  private initChart() {
    if (!HeroSection.chartRegistered) {
      Chart.register(...registerables);
      HeroSection.chartRegistered = true;
    }
    const canvas = this.balanceChart()?.nativeElement;
    if (!canvas) return;

    new Chart(canvas, {
      type: 'line',
      data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep'],
        datasets: [{
          label: 'Portfolio Value',
          data: [820000, 950000, 880000, 1050000, 980000, 1120000, 1180000, 1100000, 1248500],
          borderColor: '#2563EB',
          backgroundColor: (context) => {
            const chart = context.chart;
            const { ctx, chartArea } = chart;
            if (!chartArea) return undefined;
            const gradient = ctx.createLinearGradient(0, chartArea.top, 0, chartArea.bottom);
            gradient.addColorStop(0, 'rgba(37, 99, 235, 0.25)');
            gradient.addColorStop(0.7, 'rgba(37, 99, 235, 0.05)');
            gradient.addColorStop(1, 'rgba(37, 99, 235, 0.0)');
            return gradient;
          },
          borderWidth: 3,
          fill: true,
          tension: 0.45,
          pointRadius: 0,
          pointHoverRadius: 6,
          pointHoverBackgroundColor: '#2563EB',
          pointHoverBorderColor: '#fff',
          pointHoverBorderWidth: 3
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            mode: 'index',
            intersect: false,
            backgroundColor: '#0A0F1E',
            titleFont: { family: 'Outfit', size: 11 },
            bodyFont: { family: 'Inter', size: 13, weight: 'bold' },
            padding: 14,
            cornerRadius: 12,
            callbacks: {
              label: (context) => context.parsed.y !== null ? ` €${context.parsed.y.toLocaleString()}` : ''
            }
          }
        },
        scales: {
          x: { display: false },
          y: { display: false }
        },
        interaction: {
          mode: 'nearest',
          axis: 'x',
          intersect: false
        }
      }
    });
  }
}
