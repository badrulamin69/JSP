import { Component, ChangeDetectionStrategy, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-testimonials-section',
  standalone: true,
  imports: [MatIconModule],
  template: `
    <section id="testimonials-section" class="section-padding bg-bank-navy relative overflow-hidden">
      <div class="absolute top-1/4 left-0 w-96 h-96 bg-bank-blue/8 rounded-full blur-[120px]"></div>
      <div class="absolute bottom-0 right-1/4 w-80 h-80 bg-emerald-500/6 rounded-full blur-[120px]"></div>
      <div class="section-container relative z-10">
        <div class="text-center max-w-2xl mx-auto mb-16 space-y-5">
          <span class="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/5 border border-white/10 text-bank-blue-light text-xs font-bold tracking-wide uppercase">
            <mat-icon class="text-sm">format_quote</mat-icon> Client Stories
          </span>
          <h2 class="text-4xl md:text-5xl font-display font-bold text-white tracking-tight">
            Loved by<br><span class="gradient-text-premium">50,000+ clients.</span>
          </h2>
        </div>
        <div class="grid md:grid-cols-3 gap-6">
          @for (t of testimonials(); track t.name) {
            <div class="p-8 rounded-3xl bg-white/5 border border-white/8 hover:bg-white/8 transition-all card-hover">
              <div class="flex items-center gap-1 mb-5">
                @for (s of [1,2,3,4,5]; track s) {
                  <mat-icon class="text-amber-400 text-sm">star</mat-icon>
                }
              </div>
              <p class="text-slate-300 font-light leading-relaxed mb-6 text-sm">"{{ t.quote }}"</p>
              <div class="flex items-center gap-3 pt-5 border-t border-white/5">
                <img [src]="t.avatar" [alt]="t.name" class="w-11 h-11 rounded-full border-2 border-white/10">
                <div>
                  <p class="text-sm font-bold text-white">{{ t.name }}</p>
                  <p class="text-[10px] text-slate-400 uppercase tracking-wider">{{ t.role }}</p>
                </div>
              </div>
            </div>
          }
        </div>
      </div>
    </section>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TestimonialsSection {
  testimonials = signal([
    { name: 'Sarah Chen', role: 'CEO · TechFlow Inc', avatar: 'https://i.pravatar.cc/100?u=tc1', quote: 'Smart Secure transformed how we manage treasury across 12 countries. The multi-currency accounts and instant SWIFT transfers saved us $200K in fees annually.' },
    { name: 'Marcus Weber', role: 'Private Client · Zurich', avatar: 'https://i.pravatar.cc/100?u=tc2', quote: 'The level of security and the elegance of the platform is unmatched. Moving from a traditional Swiss bank to Smart Secure was the best financial decision I made.' },
    { name: 'Aisha Patel', role: 'CFO · Global Ventures', avatar: 'https://i.pravatar.cc/100?u=tc3', quote: 'Their AI advisory feature predicted market movements that our traditional advisors missed. Our portfolio grew 24% in the first year. Absolutely exceptional service.' },
  ]);
}
