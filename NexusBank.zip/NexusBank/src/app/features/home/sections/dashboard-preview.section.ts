import { Component, ChangeDetectionStrategy, signal, AfterViewInit, inject, PLATFORM_ID, ElementRef, viewChild } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { Chart, registerables } from 'chart.js';

@Component({
  selector: 'app-dashboard-preview-section',
  standalone: true,
  imports: [MatIconModule],
  template: `
    <section id="dashboard-preview-section" class="section-padding bg-section-alt relative overflow-hidden">
      <div class="absolute inset-0 bg-mesh pointer-events-none"></div>

      <div class="section-container relative z-10">
        <div class="text-center max-w-2xl mx-auto mb-16 space-y-5">
          <span class="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-indigo-50 text-indigo-600 text-xs font-bold tracking-wide uppercase">
            <mat-icon class="text-sm">dashboard</mat-icon>
            Dashboard Preview
          </span>
          <h2 class="text-4xl md:text-5xl font-display font-bold text-bank-navy tracking-tight">
            Command center for<br>
            <span class="gradient-text">every stakeholder.</span>
          </h2>
          <p class="text-slate-500 text-lg font-light">Role-based dashboards tailored for admins, employees, and customers.</p>
        </div>

        <!-- Tab Selector -->
        <div class="flex justify-center mb-12">
          <div class="inline-flex items-center gap-1 p-1.5 bg-slate-100 rounded-2xl">
            @for (tab of tabs(); track tab.id) {
              <button (click)="activeTab.set(tab.id)"
                      class="px-5 py-2.5 rounded-xl text-sm font-bold transition-all"
                      [class]="activeTab() === tab.id ? 'bg-white text-bank-navy shadow-sm' : 'text-slate-500 hover:text-slate-700'">
                {{ tab.label }}
              </button>
            }
          </div>
        </div>

        <!-- Dashboard Content -->
        <div class="bg-white rounded-[2rem] p-6 md:p-8 premium-shadow-lg border border-slate-100">
          @if (activeTab() === 'admin') {
            <div class="grid md:grid-cols-4 gap-4 mb-6">
              @for (kpi of adminKpis(); track kpi.label) {
                <div class="p-5 rounded-2xl border border-slate-100 hover:border-bank-blue/20 transition-colors">
                  <div class="flex items-center justify-between mb-3">
                    <p class="text-[10px] font-bold text-slate-400 uppercase tracking-[0.15em]">{{ kpi.label }}</p>
                    <div class="w-8 h-8 rounded-lg flex items-center justify-center" [class]="kpi.iconBg">
                      <mat-icon [class]="kpi.iconColor" class="text-base">{{ kpi.icon }}</mat-icon>
                    </div>
                  </div>
                  <p class="text-2xl font-display font-bold text-bank-navy">{{ kpi.value }}</p>
                  <div class="flex items-center gap-1 mt-1">
                    <mat-icon class="text-xs" [class]="kpi.trend > 0 ? 'text-emerald-500' : 'text-red-500'">
                      {{ kpi.trend > 0 ? 'trending_up' : 'trending_down' }}
                    </mat-icon>
                    <span class="text-xs font-bold" [class]="kpi.trend > 0 ? 'text-emerald-500' : 'text-red-500'">
                      {{ kpi.trend > 0 ? '+' : '' }}{{ kpi.trend }}%
                    </span>
                    <span class="text-xs text-slate-400">vs last month</span>
                  </div>
                </div>
              }
            </div>

            <div class="grid md:grid-cols-3 gap-6">
              <div class="md:col-span-2 p-5 rounded-2xl border border-slate-100">
                <div class="flex items-center justify-between mb-4">
                  <h4 class="text-sm font-bold text-bank-navy">Revenue Analytics</h4>
                  <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Last 12 months</span>
                </div>
                <div class="h-52">
                  <canvas #revenueChart></canvas>
                </div>
              </div>
              <div class="p-5 rounded-2xl border border-slate-100">
                <h4 class="text-sm font-bold text-bank-navy mb-4">Loan Portfolio</h4>
                <div class="h-44 flex items-center justify-center">
                  <canvas #loanChart></canvas>
                </div>
                <div class="space-y-2 mt-4">
                  @for (item of loanBreakdown(); track item.label) {
                    <div class="flex items-center justify-between">
                      <div class="flex items-center gap-2">
                        <div class="w-2.5 h-2.5 rounded-full" [style.background]="item.color"></div>
                        <span class="text-xs text-slate-600">{{ item.label }}</span>
                      </div>
                      <span class="text-xs font-bold text-bank-navy">{{ item.value }}</span>
                    </div>
                  }
                </div>
              </div>
            </div>
          }

          @if (activeTab() === 'employee') {
            <div class="grid md:grid-cols-3 gap-6">
              <div class="md:col-span-2 space-y-4">
                <h4 class="text-sm font-bold text-bank-navy">Today's Workflow Queue</h4>
                @for (task of employeeTasks(); track task.id) {
                  <div class="flex items-center gap-4 p-4 rounded-2xl border border-slate-100 hover:border-bank-blue/20 transition-colors">
                    <div class="w-10 h-10 rounded-xl flex items-center justify-center text-white text-sm font-bold" [class]="task.urgencyBg">
                      {{ task.initials }}
                    </div>
                    <div class="flex-1 min-w-0">
                      <p class="text-sm font-bold text-bank-navy truncate">{{ task.title }}</p>
                      <p class="text-xs text-slate-400">{{ task.customer }} · {{ task.time }}</p>
                    </div>
                    <span class="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider" [class]="task.statusClass">
                      {{ task.status }}
                    </span>
                  </div>
                }
              </div>
              <div class="space-y-4">
                <div class="p-5 rounded-2xl bg-gradient-to-br from-bank-navy to-slate-800 text-white">
                  <p class="text-[10px] font-bold text-slate-400 uppercase tracking-[0.15em]">Approved Today</p>
                  <p class="text-3xl font-display font-bold mt-2">24</p>
                  <p class="text-xs text-slate-400 mt-1">+8 from yesterday</p>
                </div>
                <div class="p-5 rounded-2xl border border-slate-100">
                  <p class="text-[10px] font-bold text-slate-400 uppercase tracking-[0.15em]">Pending Review</p>
                  <p class="text-3xl font-display font-bold text-bank-navy mt-2">7</p>
                  <div class="mt-3 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                    <div class="h-full w-3/4 bg-amber-400 rounded-full"></div>
                  </div>
                </div>
                <div class="p-5 rounded-2xl border border-slate-100">
                  <p class="text-[10px] font-bold text-slate-400 uppercase tracking-[0.15em]">Compliance Score</p>
                  <p class="text-3xl font-display font-bold text-emerald-600 mt-2">98.2%</p>
                  <p class="text-xs text-slate-400 mt-1">Above threshold</p>
                </div>
              </div>
            </div>
          }

          @if (activeTab() === 'customer') {
            <div class="grid md:grid-cols-3 gap-6">
              <div class="p-5 rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-700 text-white">
                <p class="text-[10px] font-bold text-blue-200 uppercase tracking-[0.15em]">Savings Account</p>
                <p class="text-3xl font-display font-bold mt-2">$45,280<span class="text-base text-blue-200 font-normal">.50</span></p>
                <p class="text-xs text-blue-200 mt-1">+$1,200 this month</p>
                <div class="mt-4 flex gap-2">
                  <button class="flex-1 py-2 rounded-xl bg-white/20 text-xs font-bold hover:bg-white/30 transition-colors">Send</button>
                  <button class="flex-1 py-2 rounded-xl bg-white/20 text-xs font-bold hover:bg-white/30 transition-colors">Request</button>
                </div>
              </div>
              <div class="p-5 rounded-2xl border border-slate-100">
                <p class="text-[10px] font-bold text-slate-400 uppercase tracking-[0.15em]">Checking Account</p>
                <p class="text-3xl font-display font-bold text-bank-navy mt-2">$2,500<span class="text-base text-slate-400 font-normal">.00</span></p>
                <p class="text-xs text-slate-400 mt-1">Daily spending: $85</p>
              </div>
              <div class="p-5 rounded-2xl border border-slate-100">
                <p class="text-[10px] font-bold text-slate-400 uppercase tracking-[0.15em]">Investments</p>
                <p class="text-3xl font-display font-bold text-emerald-600 mt-2">$16,250<span class="text-base text-slate-400 font-normal">.00</span></p>
                <p class="text-xs text-emerald-500 font-bold mt-1">↑ 8.33% growth</p>
              </div>
            </div>

            <div class="mt-6 p-5 rounded-2xl border border-slate-100">
              <h4 class="text-sm font-bold text-bank-navy mb-4">Recent Transactions</h4>
              <div class="space-y-3">
                @for (tx of recentTransactions(); track tx.id) {
                  <div class="flex items-center gap-4 py-2">
                    <div class="w-10 h-10 rounded-xl flex items-center justify-center" [class]="tx.iconBg">
                      <mat-icon [class]="tx.iconColor" class="text-lg">{{ tx.icon }}</mat-icon>
                    </div>
                    <div class="flex-1 min-w-0">
                      <p class="text-sm font-bold text-bank-navy">{{ tx.description }}</p>
                      <p class="text-xs text-slate-400">{{ tx.date }}</p>
                    </div>
                    <p class="text-sm font-bold" [class]="tx.amount > 0 ? 'text-emerald-600' : 'text-bank-navy'">
                      {{ tx.amount > 0 ? '+' : '' }}{{ tx.amountFormatted }}
                    </p>
                  </div>
                }
              </div>
            </div>
          }
        </div>
      </div>
    </section>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DashboardPreviewSection implements AfterViewInit {
  private platformId = inject(PLATFORM_ID);
  revenueChart = viewChild<ElementRef<HTMLCanvasElement>>('revenueChart');
  loanChart = viewChild<ElementRef<HTMLCanvasElement>>('loanChart');

  activeTab = signal('admin');

  tabs = signal([
    { id: 'admin', label: 'Admin Dashboard' },
    { id: 'employee', label: 'Employee Hub' },
    { id: 'customer', label: 'Customer Portal' },
  ]);

  adminKpis = signal([
    { label: 'Total Deposits', value: '$248M', icon: 'account_balance_wallet', iconBg: 'bg-blue-50', iconColor: 'text-bank-blue', trend: 12.4 },
    { label: 'Active Loans', value: '$82M', icon: 'receipt_long', iconBg: 'bg-emerald-50', iconColor: 'text-emerald-600', trend: 8.2 },
    { label: 'New Customers', value: '1,847', icon: 'person_add', iconBg: 'bg-violet-50', iconColor: 'text-violet-600', trend: 24.1 },
    { label: 'Revenue', value: '$4.2M', icon: 'trending_up', iconBg: 'bg-amber-50', iconColor: 'text-amber-600', trend: -2.1 },
  ]);

  loanBreakdown = signal([
    { label: 'Mortgage', value: '45%', color: '#2563EB' },
    { label: 'Personal', value: '25%', color: '#10B981' },
    { label: 'Auto', value: '18%', color: '#8B5CF6' },
    { label: 'Business', value: '12%', color: '#F59E0B' },
  ]);

  employeeTasks = signal([
    { id: 1, initials: 'LA', title: 'Loan Application Review — $250K Mortgage', customer: 'Esther Howard', time: '10 min ago', status: 'Urgent', statusClass: 'bg-red-50 text-red-600', urgencyBg: 'bg-red-500' },
    { id: 2, initials: 'KY', title: 'KYC Verification — Business Account', customer: 'Cody Fisher', time: '25 min ago', status: 'Pending', statusClass: 'bg-amber-50 text-amber-600', urgencyBg: 'bg-amber-500' },
    { id: 3, initials: 'TX', title: 'International Transfer Approval — CHF 85,000', customer: 'Jane Cooper', time: '1 hour ago', status: 'Review', statusClass: 'bg-blue-50 text-blue-600', urgencyBg: 'bg-bank-blue' },
    { id: 4, initials: 'FD', title: 'Fixed Deposit Maturity Processing', customer: 'Michael Ross', time: '2 hours ago', status: 'Done', statusClass: 'bg-emerald-50 text-emerald-600', urgencyBg: 'bg-emerald-500' },
  ]);

  recentTransactions = signal([
    { id: 1, icon: 'arrow_downward', iconBg: 'bg-emerald-50', iconColor: 'text-emerald-600', description: 'Salary Credit', date: 'Today, 09:15 AM', amount: 2500, amountFormatted: '$2,500.00' },
    { id: 2, icon: 'arrow_upward', iconBg: 'bg-slate-100', iconColor: 'text-slate-600', description: 'SWIFT Transfer to Zurich', date: 'Yesterday, 10:00 AM', amount: -1200, amountFormatted: '$1,200.00' },
    { id: 3, icon: 'shopping_bag', iconBg: 'bg-violet-50', iconColor: 'text-violet-600', description: 'Netflix Subscription', date: 'Yesterday, 02:30 PM', amount: -85, amountFormatted: '$85.00' },
    { id: 4, icon: 'arrow_downward', iconBg: 'bg-emerald-50', iconColor: 'text-emerald-600', description: 'Asset Liquidation', date: 'May 11, 11:30 AM', amount: 50000, amountFormatted: '$50,000.00' },
  ]);

  ngAfterViewInit() {
    if (isPlatformBrowser(this.platformId)) {
      setTimeout(() => this.initCharts(), 100);
    }
  }

  private initCharts() {
    this.initRevenueChart();
    this.initLoanChart();
  }

  private initRevenueChart() {
    const canvas = this.revenueChart()?.nativeElement;
    if (!canvas) return;
    new Chart(canvas, {
      type: 'bar',
      data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
        datasets: [{
          label: 'Revenue',
          data: [320, 380, 350, 420, 390, 480, 510, 470, 520, 490, 540, 580],
          backgroundColor: (ctx) => {
            return ctx.dataIndex === 11 ? '#2563EB' : '#E2E8F0';
          },
          borderRadius: 8,
          borderSkipped: false,
          barThickness: 20,
        }]
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false }, tooltip: { backgroundColor: '#0A0F1E', cornerRadius: 10, padding: 10, bodyFont: { family: 'Inter' } } },
        scales: {
          x: { grid: { display: false }, ticks: { font: { family: 'Inter', size: 10 }, color: '#94A3B8' } },
          y: { display: false }
        }
      }
    });
  }

  private initLoanChart() {
    const canvas = this.loanChart()?.nativeElement;
    if (!canvas) return;
    new Chart(canvas, {
      type: 'doughnut',
      data: {
        labels: ['Mortgage', 'Personal', 'Auto', 'Business'],
        datasets: [{
          data: [45, 25, 18, 12],
          backgroundColor: ['#2563EB', '#10B981', '#8B5CF6', '#F59E0B'],
          borderWidth: 0,
          spacing: 4,
        }]
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        cutout: '72%',
        plugins: { legend: { display: false } }
      }
    });
  }
}
