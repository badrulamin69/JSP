import { Component, ChangeDetectionStrategy } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-mobile-app-section',
  standalone: true,
  imports: [MatIconModule],
  template: `
    <section id="mobile-app-section" class="section-padding bg-white relative overflow-hidden">
      <div class="section-container relative z-10">
        <div class="relative bg-gradient-to-br from-bank-navy via-slate-800 to-bank-navy rounded-[2.5rem] p-8 md:p-16 overflow-hidden">
          <div class="absolute top-0 right-0 w-96 h-96 bg-bank-blue/15 rounded-full blur-[120px] -mr-48 -mt-48"></div>
          <div class="absolute bottom-0 left-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-[120px] -ml-48 -mb-48"></div>

          <div class="relative z-10 grid lg:grid-cols-2 gap-12 items-center">
            <div class="space-y-8">
              <span class="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/5 border border-white/10 text-bank-blue-light text-xs font-bold tracking-wide uppercase">
                <mat-icon class="text-sm">smartphone</mat-icon> Mobile Banking
              </span>
              <h2 class="text-4xl md:text-5xl font-display font-bold text-white tracking-tight leading-tight">
                Banking in your<br><span class="gradient-text-premium">pocket.</span>
              </h2>
              <p class="text-slate-400 text-lg font-light leading-relaxed max-w-md">
                Full-featured mobile banking with biometric login, instant notifications, and real-time portfolio tracking.
              </p>
              <div class="space-y-3">
                <div class="flex items-center gap-3 text-slate-300 text-sm">
                  <mat-icon class="text-emerald-400 text-base">check_circle</mat-icon>
                  Biometric authentication & face ID
                </div>
                <div class="flex items-center gap-3 text-slate-300 text-sm">
                  <mat-icon class="text-emerald-400 text-base">check_circle</mat-icon>
                  Instant push notifications for every transaction
                </div>
                <div class="flex items-center gap-3 text-slate-300 text-sm">
                  <mat-icon class="text-emerald-400 text-base">check_circle</mat-icon>
                  One-tap transfers & bill payments
                </div>
                <div class="flex items-center gap-3 text-slate-300 text-sm">
                  <mat-icon class="text-emerald-400 text-base">check_circle</mat-icon>
                  Real-time spending analytics & budgets
                </div>
              </div>
              <div class="flex flex-col sm:flex-row gap-3">
                <button class="flex items-center gap-3 px-6 py-3.5 rounded-2xl bg-white text-bank-navy font-bold text-sm hover:bg-slate-100 transition-all active:scale-95">
                  <mat-icon class="text-2xl">apple</mat-icon>
                  <div class="text-left">
                    <p class="text-[9px] text-slate-500 uppercase tracking-wider leading-none">Download on</p>
                    <p class="text-sm font-bold leading-tight">App Store</p>
                  </div>
                </button>
                <button class="flex items-center gap-3 px-6 py-3.5 rounded-2xl bg-white/10 border border-white/10 text-white font-bold text-sm hover:bg-white/15 transition-all active:scale-95">
                  <mat-icon class="text-2xl">android</mat-icon>
                  <div class="text-left">
                    <p class="text-[9px] text-slate-400 uppercase tracking-wider leading-none">Get it on</p>
                    <p class="text-sm font-bold leading-tight">Google Play</p>
                  </div>
                </button>
              </div>
            </div>

            <!-- Phone Mockup -->
            <div class="flex justify-center">
              <div class="relative w-64 md:w-72">
                <div class="bg-gradient-to-b from-slate-700 to-slate-900 rounded-[2.5rem] p-3 shadow-2xl border border-white/10">
                  <div class="bg-bank-navy rounded-[2rem] overflow-hidden">
                    <!-- Status bar -->
                    <div class="flex items-center justify-between px-6 py-3 text-[10px] text-white/60">
                      <span>9:41</span>
                      <div class="flex items-center gap-1.5">
                        <mat-icon class="text-xs">signal_cellular_4_bar</mat-icon>
                        <mat-icon class="text-xs">wifi</mat-icon>
                        <mat-icon class="text-xs">battery_full</mat-icon>
                      </div>
                    </div>
                    <!-- App content -->
                    <div class="px-5 pb-6 space-y-4">
                      <div class="text-center py-4">
                        <p class="text-[10px] text-slate-400 uppercase tracking-widest">Total Balance</p>
                        <p class="text-2xl font-display font-bold text-white mt-1">$47,780.50</p>
                        <span class="text-[10px] text-emerald-400 font-bold">+2.4% today</span>
                      </div>
                      <div class="grid grid-cols-3 gap-2">
                        <div class="text-center p-2 rounded-xl bg-white/5">
                          <mat-icon class="text-bank-blue-light text-lg">send</mat-icon>
                          <p class="text-[9px] text-slate-400 mt-1">Send</p>
                        </div>
                        <div class="text-center p-2 rounded-xl bg-white/5">
                          <mat-icon class="text-emerald-400 text-lg">call_received</mat-icon>
                          <p class="text-[9px] text-slate-400 mt-1">Request</p>
                        </div>
                        <div class="text-center p-2 rounded-xl bg-white/5">
                          <mat-icon class="text-amber-400 text-lg">qr_code_scanner</mat-icon>
                          <p class="text-[9px] text-slate-400 mt-1">Scan</p>
                        </div>
                      </div>
                      <div class="space-y-2">
                        <p class="text-[10px] text-slate-400 uppercase tracking-widest">Recent</p>
                        <div class="flex items-center gap-3 p-2.5 rounded-xl bg-white/5">
                          <div class="w-8 h-8 rounded-lg bg-emerald-500/20 flex items-center justify-center">
                            <mat-icon class="text-emerald-400 text-sm">arrow_downward</mat-icon>
                          </div>
                          <div class="flex-1">
                            <p class="text-xs text-white font-medium">Salary Credit</p>
                            <p class="text-[9px] text-slate-400">Today</p>
                          </div>
                          <p class="text-xs text-emerald-400 font-bold">+$2,500</p>
                        </div>
                        <div class="flex items-center gap-3 p-2.5 rounded-xl bg-white/5">
                          <div class="w-8 h-8 rounded-lg bg-slate-500/20 flex items-center justify-center">
                            <mat-icon class="text-slate-400 text-sm">arrow_upward</mat-icon>
                          </div>
                          <div class="flex-1">
                            <p class="text-xs text-white font-medium">Transfer to EUR</p>
                            <p class="text-[9px] text-slate-400">Yesterday</p>
                          </div>
                          <p class="text-xs text-white font-bold">-$1,200</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- Floating notification -->
                <div class="absolute -right-6 top-1/4 glass-card p-3 rounded-xl animate-float hidden md:block">
                  <div class="flex items-center gap-2">
                    <div class="w-7 h-7 rounded-lg bg-emerald-100 flex items-center justify-center">
                      <mat-icon class="text-emerald-600 text-sm">notifications</mat-icon>
                    </div>
                    <div>
                      <p class="text-[10px] font-bold text-slate-900">Payment Received</p>
                      <p class="text-[9px] text-slate-400">+$2,500.00</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MobileAppSection {}
