import { Component, ChangeDetectionStrategy, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-loan-investment-section',
  standalone: true,
  imports: [MatIconModule],
  template: `
    <section id="loan-investment-section" class="section-padding bg-white relative overflow-hidden">
      <div class="absolute top-0 left-0 w-[600px] h-[600px] bg-blue-50/40 rounded-full blur-3xl -ml-64 -mt-64"></div>

      <div class="section-container relative z-10">
        <div class="text-center max-w-2xl mx-auto mb-16 space-y-5">
          <span class="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-50 text-amber-600 text-xs font-bold tracking-wide uppercase">
            <mat-icon class="text-sm">trending_up</mat-icon>
            Grow Your Wealth
          </span>
          <h2 class="text-4xl md:text-5xl font-display font-bold text-bank-navy tracking-tight">
            Loans & investments,<br>
            <span class="gradient-text">tailored to you.</span>
          </h2>
          <p class="text-slate-500 text-lg font-light">From personal loans to institutional portfolios — flexible solutions for every ambition.</p>
        </div>

        <div class="grid lg:grid-cols-2 gap-8">
          <!-- Loans Section -->
          <div class="space-y-5">
            <h3 class="text-lg font-bold text-bank-navy flex items-center gap-2">
              <mat-icon class="text-bank-blue">receipt_long</mat-icon>
              Loan Products
            </h3>
            @for (loan of loans(); track loan.title) {
              <div class="p-6 rounded-3xl border border-slate-100 hover:border-bank-blue/20 transition-all card-hover group bg-white">
                <div class="flex items-start gap-5">
                  <div class="w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 transition-all group-hover:scale-110" [class]="loan.iconBg">
                    <mat-icon [class]="loan.iconColor" class="text-2xl">{{ loan.icon }}</mat-icon>
                  </div>
                  <div class="flex-1 min-w-0">
                    <div class="flex items-center justify-between mb-1">
                      <h4 class="text-base font-bold text-bank-navy">{{ loan.title }}</h4>
                      <span class="text-xs font-bold text-bank-blue">{{ loan.rate }}</span>
                    </div>
                    <p class="text-sm text-slate-500 font-light mb-3">{{ loan.description }}</p>
                    <div class="flex flex-wrap gap-2">
                      @for (tag of loan.tags; track tag) {
                        <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-slate-50 text-slate-500 uppercase tracking-wider">{{ tag }}</span>
                      }
                    </div>
                  </div>
                </div>
              </div>
            }
          </div>

          <!-- Investments Section -->
          <div class="space-y-5">
            <h3 class="text-lg font-bold text-bank-navy flex items-center gap-2">
              <mat-icon class="text-emerald-600">insights</mat-icon>
              Investment Options
            </h3>
            @for (inv of investments(); track inv.title) {
              <div class="p-6 rounded-3xl border border-slate-100 hover:border-emerald-500/20 transition-all card-hover group bg-white">
                <div class="flex items-start gap-5">
                  <div class="w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 transition-all group-hover:scale-110" [class]="inv.iconBg">
                    <mat-icon [class]="inv.iconColor" class="text-2xl">{{ inv.icon }}</mat-icon>
                  </div>
                  <div class="flex-1 min-w-0">
                    <div class="flex items-center justify-between mb-1">
                      <h4 class="text-base font-bold text-bank-navy">{{ inv.title }}</h4>
                      <span class="text-xs font-bold" [class]="inv.returnPositive ? 'text-emerald-600' : 'text-bank-blue'">{{ inv.returns }}</span>
                    </div>
                    <p class="text-sm text-slate-500 font-light mb-3">{{ inv.description }}</p>
                    <div class="flex items-center gap-3">
                      <div class="flex-1 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                        <div class="h-full rounded-full transition-all" [style.width]="inv.allocation" [class]="inv.barColor"></div>
                      </div>
                      <span class="text-[10px] font-bold text-slate-400">{{ inv.allocation }}</span>
                    </div>
                  </div>
                </div>
              </div>
            }
          </div>
        </div>
      </div>
    </section>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LoanInvestmentSection {
  loans = signal([
    {
      icon: 'home', title: 'Home Mortgage', rate: 'from 3.5% APR',
      description: 'Competitive rates for your dream home with flexible repayment up to 30 years.',
      tags: ['Up to $2M', '30 Year', 'Fixed Rate'],
      iconBg: 'bg-blue-50', iconColor: 'text-bank-blue',
    },
    {
      icon: 'directions_car', title: 'Auto Loan', rate: 'from 4.2% APR',
      description: 'New or used vehicle financing with instant pre-approval and flexible terms.',
      tags: ['Instant', '7 Year', 'Low Rate'],
      iconBg: 'bg-violet-50', iconColor: 'text-violet-600',
    },
    {
      icon: 'person', title: 'Personal Loan', rate: 'from 6.9% APR',
      description: 'Unsecured personal loans for any purpose — no collateral required.',
      tags: ['Up to $100K', 'No Collateral', '5 Year'],
      iconBg: 'bg-amber-50', iconColor: 'text-amber-600',
    },
    {
      icon: 'business', title: 'Business Credit', rate: 'from 5.5% APR',
      description: 'Fuel your business growth with tailored credit lines and commercial loans.',
      tags: ['Up to $5M', 'Revolving', 'Flexible'],
      iconBg: 'bg-cyan-50', iconColor: 'text-cyan-600',
    },
  ]);

  investments = signal([
    {
      icon: 'pie_chart', title: 'Mutual Funds', returns: '+12.4% YTD',
      description: 'Diversified portfolios managed by global investment professionals.',
      allocation: '45%', barColor: 'bg-bank-blue', returnPositive: true,
      iconBg: 'bg-blue-50', iconColor: 'text-bank-blue',
    },
    {
      icon: 'show_chart', title: 'ETFs & Stocks', returns: '+8.7% YTD',
      description: 'Access global markets with commission-free trading on 5,000+ instruments.',
      allocation: '30%', barColor: 'bg-emerald-500', returnPositive: true,
      iconBg: 'bg-emerald-50', iconColor: 'text-emerald-600',
    },
    {
      icon: 'lock_clock', title: 'Fixed Deposits', returns: '4.5% p.a.',
      description: 'Guaranteed returns with tenures from 3 months to 5 years.',
      allocation: '15%', barColor: 'bg-amber-500', returnPositive: true,
      iconBg: 'bg-amber-50', iconColor: 'text-amber-600',
    },
    {
      icon: 'currency_bitcoin', title: 'Digital Assets', returns: '+24.1% YTD',
      description: 'Institutional-grade custody for Bitcoin, Ethereum, and major cryptocurrencies.',
      allocation: '10%', barColor: 'bg-violet-500', returnPositive: true,
      iconBg: 'bg-violet-50', iconColor: 'text-violet-600',
    },
  ]);
}
