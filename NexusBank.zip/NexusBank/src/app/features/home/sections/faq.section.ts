import { Component, ChangeDetectionStrategy, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-faq-section',
  standalone: true,
  imports: [MatIconModule],
  template: `
    <section id="faq-section" class="section-padding bg-section-alt relative">
      <div class="section-container relative z-10">
        <div class="text-center max-w-2xl mx-auto mb-16 space-y-5">
          <span class="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-50 text-amber-600 text-xs font-bold tracking-wide uppercase">
            <mat-icon class="text-sm">help_outline</mat-icon> FAQ
          </span>
          <h2 class="text-4xl md:text-5xl font-display font-bold text-bank-navy tracking-tight">
            Questions?<br><span class="gradient-text">We've got answers.</span>
          </h2>
        </div>
        <div class="max-w-3xl mx-auto space-y-3">
          @for (faq of faqs(); track faq.q; let i = $index) {
            <div class="rounded-2xl border border-slate-100 bg-white overflow-hidden transition-all"
                 [class.premium-shadow]="openIndex() === i">
              <button (click)="toggle(i)" class="w-full flex items-center justify-between p-6 text-left group">
                <span class="text-base font-bold text-bank-navy pr-4 group-hover:text-bank-blue transition-colors">{{ faq.q }}</span>
                <mat-icon class="text-slate-400 shrink-0 transition-transform duration-300" [class.rotate-180]="openIndex() === i">expand_more</mat-icon>
              </button>
              @if (openIndex() === i) {
                <div class="px-6 pb-6 -mt-2">
                  <p class="text-sm text-slate-500 font-light leading-relaxed">{{ faq.a }}</p>
                </div>
              }
            </div>
          }
        </div>
      </div>
    </section>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FaqSection {
  openIndex = signal<number | null>(0);

  toggle(i: number) {
    this.openIndex.set(this.openIndex() === i ? null : i);
  }

  faqs = signal([
    { q: 'How do I open an account with Smart Secure?', a: 'Opening an account takes under 2 minutes. Simply click "Open Account", complete digital KYC verification with your ID, and your account is ready instantly. No branch visit required.' },
    { q: 'What currencies do you support?', a: 'We support 45+ currencies including USD, EUR, GBP, CHF, JPY, and all major global currencies. You can hold, send, and receive in any supported currency with real-time exchange rates.' },
    { q: 'How secure is my money?', a: 'Your funds are protected by AES-256 encryption, multi-factor biometric authentication, and real-time AI fraud detection. We are FINMA regulated and maintain 99.99% uptime with Swiss-grade security infrastructure.' },
    { q: 'Are there any hidden fees?', a: 'No. We believe in transparent pricing. Personal accounts are free with up to 5 transfers per month. Premium and Enterprise plans include unlimited transfers. All fees are clearly displayed before any transaction.' },
    { q: 'How fast are international transfers?', a: 'Most international transfers arrive in under 30 seconds using our SWIFT-backed instant transfer network. Traditional wire transfers are completed within 1-2 business days.' },
    { q: 'Can I use Smart Secure for my business?', a: 'Absolutely. Our Enterprise plan offers multi-entity management, role-based access, API integration, batch payments, and dedicated account managers — perfect for businesses of any size.' },
  ]);
}
