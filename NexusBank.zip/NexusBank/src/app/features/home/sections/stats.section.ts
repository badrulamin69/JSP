import { Component, ChangeDetectionStrategy, signal, AfterViewInit, inject, PLATFORM_ID, ElementRef, viewChild } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-stats-section',
  standalone: true,
  imports: [MatIconModule],
  template: `
    <section id="stats-section" class="relative bg-bank-navy overflow-hidden">
      <!-- Ambient glow -->
      <div class="absolute top-0 left-1/4 w-96 h-96 bg-bank-blue/10 rounded-full blur-[120px]"></div>
      <div class="absolute bottom-0 right-1/4 w-96 h-96 bg-emerald-500/8 rounded-full blur-[120px]"></div>

      <div class="section-container py-16 md:py-20 relative z-10">
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-6 md:gap-10">
          @for (stat of stats(); track stat.label) {
            <div class="text-center space-y-3 group">
              <div class="w-12 h-12 mx-auto rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center mb-3 group-hover:bg-white/10 transition-colors">
                <mat-icon class="text-bank-blue-light text-xl">{{ stat.icon }}</mat-icon>
              </div>
              <h3 class="text-3xl md:text-4xl lg:text-5xl font-display font-bold text-white tracking-tight">{{ stat.value }}</h3>
              <p class="text-slate-400 text-sm font-medium">{{ stat.label }}</p>
            </div>
          }
        </div>

        <!-- Trust Logos -->
        <div class="mt-16 pt-10 border-t border-white/5">
          <p class="text-center text-[10px] text-slate-500 uppercase tracking-[0.3em] font-bold mb-8">Trusted by industry leaders</p>
          <div class="flex flex-wrap justify-center items-center gap-x-12 gap-y-6 opacity-30">
            @for (brand of brands(); track brand) {
              <span class="text-white font-display font-bold text-lg md:text-xl tracking-wider">{{ brand }}</span>
            }
          </div>
        </div>
      </div>
    </section>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class StatsSection {
  stats = signal([
    { icon: 'groups', value: '50,000+', label: 'Active Clients Worldwide' },
    { icon: 'account_balance_wallet', value: '$12B+', label: 'Assets Under Management' },
    { icon: 'public', value: '180+', label: 'Countries Covered' },
    { icon: 'security', value: '99.99%', label: 'Uptime & Security Score' },
  ]);

  brands = signal(['VISA', 'SWIFT', 'FINMA', 'Mastercard', 'Reuters']);
}
