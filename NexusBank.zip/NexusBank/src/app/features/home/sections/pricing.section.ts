import { Component, ChangeDetectionStrategy, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-pricing-section',
  standalone: true,
  imports: [RouterLink, MatIconModule],
  template: `
    <section id="pricing-section" class="section-padding bg-white relative overflow-hidden">
      <div class="absolute inset-0 bg-mesh pointer-events-none"></div>
      <div class="section-container relative z-10">
        <div class="text-center max-w-2xl mx-auto mb-16 space-y-5">
          <span class="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-violet-50 text-violet-600 text-xs font-bold tracking-wide uppercase">
            <mat-icon class="text-sm">workspace_premium</mat-icon> Pricing Plans
          </span>
          <h2 class="text-4xl md:text-5xl font-display font-bold text-bank-navy tracking-tight">
            Transparent pricing.<br><span class="gradient-text">No hidden fees.</span>
          </h2>
        </div>
        <div class="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          @for (plan of plans(); track plan.name) {
            <div class="relative p-8 rounded-3xl border transition-all card-hover"
                 [class]="plan.featured ? 'bg-gradient-to-br from-bank-navy to-slate-800 border-bank-blue/30 shadow-2xl shadow-bank-blue/10' : 'bg-white border-slate-100'">
              @if (plan.featured) {
                <div class="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-bank-blue text-white text-[10px] font-bold uppercase tracking-wider">Most Popular</div>
              }
              <div class="mb-6">
                <h3 class="text-lg font-bold mb-1" [class]="plan.featured ? 'text-white' : 'text-bank-navy'">{{ plan.name }}</h3>
                <p class="text-xs font-light" [class]="plan.featured ? 'text-slate-400' : 'text-slate-500'">{{ plan.desc }}</p>
              </div>
              <div class="mb-6">
                <span class="text-4xl font-display font-bold" [class]="plan.featured ? 'text-white' : 'text-bank-navy'">{{ plan.price }}</span>
                <span class="text-sm font-light" [class]="plan.featured ? 'text-slate-400' : 'text-slate-500'">/month</span>
              </div>
              <button routerLink="/register" class="w-full py-3.5 rounded-2xl font-bold text-sm transition-all active:scale-95 mb-8"
                      [class]="plan.featured ? 'bg-bank-blue text-white hover:bg-blue-600 shadow-lg shadow-bank-blue/30' : 'bg-slate-50 text-bank-navy hover:bg-slate-100 border border-slate-200'">
                Get Started
              </button>
              <div class="space-y-3">
                @for (f of plan.features; track f) {
                  <div class="flex items-center gap-3">
                    <mat-icon class="text-sm" [class]="plan.featured ? 'text-emerald-400' : 'text-emerald-500'">check_circle</mat-icon>
                    <span class="text-sm" [class]="plan.featured ? 'text-slate-300' : 'text-slate-600'">{{ f }}</span>
                  </div>
                }
              </div>
            </div>
          }
        </div>
      </div>
    </section>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PricingSection {
  plans = signal([
    {
      name: 'Personal', desc: 'For individuals and daily banking', price: 'Free', featured: false,
      features: ['1 Multi-Currency Account', 'Virtual Debit Card', '5 Free Transfers/mo', 'Basic Analytics', 'Mobile App Access', '24/7 Chat Support'],
    },
    {
      name: 'Premium', desc: 'For professionals and families', price: '$19', featured: true,
      features: ['5 Multi-Currency Accounts', 'Metal Card + Virtual Cards', 'Unlimited Free Transfers', 'Advanced AI Analytics', 'Priority Support', 'Investment Access', 'No ATM Fees Worldwide'],
    },
    {
      name: 'Enterprise', desc: 'For businesses and institutions', price: '$99', featured: false,
      features: ['Unlimited Accounts', 'Corporate Card Program', 'API Access & Webhooks', 'Dedicated Account Manager', 'Custom Compliance', 'Multi-Role Access', 'Treasury Management'],
    },
  ]);
}
