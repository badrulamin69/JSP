import { Component, ChangeDetectionStrategy, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-features-section',
  standalone: true,
  imports: [MatIconModule],
  template: `
    <section id="features-section" class="section-padding bg-white relative overflow-hidden">
      <div class="absolute top-0 right-0 w-[500px] h-[500px] bg-indigo-50/50 rounded-full blur-3xl -mr-64 -mt-64"></div>
      <div class="absolute bottom-0 left-0 w-[400px] h-[400px] bg-emerald-50/50 rounded-full blur-3xl -ml-48 -mb-48"></div>

      <div class="section-container relative z-10">
        <div class="text-center max-w-2xl mx-auto mb-16 md:mb-20 space-y-5">
          <span class="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-blue-50 text-bank-blue text-xs font-bold tracking-wide uppercase">
            <mat-icon class="text-sm">auto_awesome</mat-icon>
            Banking Features
          </span>
          <h2 id="features-title" class="text-4xl md:text-5xl lg:text-[3.5rem] font-display font-bold text-bank-navy tracking-tight leading-tight">
            Everything you need.<br>
            <span class="gradient-text">Nothing you don't.</span>
          </h2>
          <p class="text-slate-500 text-lg font-light leading-relaxed max-w-xl mx-auto">
            A complete suite of modern banking tools designed for individuals, businesses, and enterprises.
          </p>
        </div>

        <div id="features-grid" class="grid sm:grid-cols-2 lg:grid-cols-3 gap-5 md:gap-6">
          @for (feature of features(); track feature.title) {
            <div class="group p-7 md:p-8 rounded-3xl bg-white border border-slate-100 hover:border-transparent transition-all duration-500 card-hover cursor-pointer relative overflow-hidden"
                 [class]="feature.featured ? 'lg:col-span-1 bg-gradient-to-br from-bank-navy to-slate-800 border-none' : ''">
              <!-- Hover glow -->
              <div class="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"
                   [style.background]="'radial-gradient(400px circle at var(--mouse-x, 50%) var(--mouse-y, 50%), ' + feature.glowColor + ', transparent 60%)'"></div>

              <div class="relative z-10">
                <div class="w-14 h-14 rounded-2xl flex items-center justify-center mb-6 transition-all duration-300 group-hover:scale-110 group-hover:rotate-3"
                     [class]="feature.featured ? 'bg-white/10 text-white' : feature.iconBg + ' ' + feature.iconColor">
                  <mat-icon class="text-2xl">{{ feature.icon }}</mat-icon>
                </div>
                <h3 class="text-xl font-bold mb-3 tracking-tight"
                    [class]="feature.featured ? 'text-white' : 'text-bank-navy'">{{ feature.title }}</h3>
                <p class="leading-relaxed font-light text-sm"
                   [class]="feature.featured ? 'text-slate-300' : 'text-slate-500'">{{ feature.description }}</p>

                <div class="mt-6 flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider transition-colors"
                     [class]="feature.featured ? 'text-bank-blue-light' : 'text-bank-blue'">
                  Learn more
                  <mat-icon class="text-sm group-hover:translate-x-1 transition-transform">arrow_forward</mat-icon>
                </div>
              </div>
            </div>
          }
        </div>
      </div>
    </section>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FeaturesSection {
  features = signal([
    {
      icon: 'verified_user', title: 'Biometric Security',
      description: 'Access your account with face and fingerprint recognition, powered by Swiss-grade AES-256 encryption.',
      iconBg: 'bg-blue-50', iconColor: 'text-bank-blue', glowColor: 'rgba(37,99,235,0.06)', featured: false,
    },
    {
      icon: 'language', title: 'Global Transfers',
      description: 'Send money to 180+ countries in minutes with zero hidden fees. Real-time exchange rates and SWIFT integration.',
      iconBg: 'bg-emerald-50', iconColor: 'text-emerald-600', glowColor: 'rgba(16,185,129,0.06)', featured: false,
    },
    {
      icon: 'credit_card', title: 'Virtual & Metal Cards',
      description: 'Generate instant virtual cards for online shopping. Premium titanium cards for exclusive daily use.',
      iconBg: 'bg-violet-50', iconColor: 'text-violet-600', glowColor: 'rgba(139,92,246,0.06)', featured: true,
    },
    {
      icon: 'analytics', title: 'Smart Analytics',
      description: 'AI-powered spending insights with automatic categorization, predictive budgets, and wealth growth tracking.',
      iconBg: 'bg-amber-50', iconColor: 'text-amber-600', glowColor: 'rgba(245,158,11,0.06)', featured: false,
    },
    {
      icon: 'account_balance', title: 'Enterprise Accounts',
      description: 'Tailored multi-entity banking with role-based access, batch payments, and treasury management.',
      iconBg: 'bg-cyan-50', iconColor: 'text-cyan-600', glowColor: 'rgba(6,182,212,0.06)', featured: false,
    },
    {
      icon: 'psychology', title: 'AI Advisory',
      description: 'Personalized investment and savings recommendations powered by machine learning and global market analysis.',
      iconBg: 'bg-rose-50', iconColor: 'text-rose-600', glowColor: 'rgba(244,63,94,0.06)', featured: false,
    },
    {
      icon: 'savings', title: 'Fixed Deposits',
      description: 'Earn competitive returns with flexible tenures from 3 months to 5 years. Auto-renewal and early withdrawal options.',
      iconBg: 'bg-green-50', iconColor: 'text-green-600', glowColor: 'rgba(34,197,94,0.06)', featured: false,
    },
    {
      icon: 'trending_up', title: 'Investment Hub',
      description: 'Access mutual funds, ETFs, bonds, and crypto — all from one integrated investment dashboard.',
      iconBg: 'bg-indigo-50', iconColor: 'text-indigo-600', glowColor: 'rgba(99,102,241,0.06)', featured: false,
    },
    {
      icon: 'shield', title: 'Fraud Protection',
      description: 'Real-time transaction monitoring with AI-based anomaly detection. Instant alerts and one-tap card freeze.',
      iconBg: 'bg-orange-50', iconColor: 'text-orange-600', glowColor: 'rgba(249,115,22,0.06)', featured: false,
    },
  ]);
}
