import { Component, ChangeDetectionStrategy, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-branch-atm-section',
  standalone: true,
  imports: [MatIconModule],
  template: `
    <section id="branch-atm-section" class="section-padding bg-white relative overflow-hidden">
      <div class="section-container relative z-10">
        <div class="text-center max-w-2xl mx-auto mb-16 space-y-5">
          <span class="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-cyan-50 text-cyan-600 text-xs font-bold tracking-wide uppercase">
            <mat-icon class="text-sm">location_on</mat-icon> Our Network
          </span>
          <h2 class="text-4xl md:text-5xl font-display font-bold text-bank-navy tracking-tight">
            Global presence,<br><span class="gradient-text">local service.</span>
          </h2>
          <p class="text-slate-500 text-lg font-light">Access our worldwide network of premium branches and smart ATMs.</p>
        </div>
        <div class="grid md:grid-cols-4 gap-4 mb-10">
          @for (s of networkStats(); track s.label) {
            <div class="p-6 rounded-2xl bg-slate-50 border border-slate-100 text-center card-hover">
              <mat-icon class="text-3xl mb-3" [class]="s.iconColor">{{ s.icon }}</mat-icon>
              <p class="text-2xl font-display font-bold text-bank-navy">{{ s.value }}</p>
              <p class="text-xs text-slate-500 mt-1">{{ s.label }}</p>
            </div>
          }
        </div>
        <div class="grid md:grid-cols-3 gap-6">
          @for (branch of branches(); track branch.name) {
            <div class="p-6 rounded-3xl border border-slate-100 hover:border-bank-blue/20 transition-all card-hover group bg-white">
              <div class="flex items-center gap-3 mb-4">
                <div class="w-12 h-12 rounded-2xl flex items-center justify-center" [class]="branch.bg">
                  <span class="text-xl">{{ branch.flag }}</span>
                </div>
                <div>
                  <h4 class="text-base font-bold text-bank-navy">{{ branch.name }}</h4>
                  <p class="text-xs text-slate-400">{{ branch.location }}</p>
                </div>
                <span class="ml-auto px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-emerald-50 text-emerald-600">Online</span>
              </div>
              <div class="space-y-2 text-xs text-slate-500">
                <div class="flex items-center gap-2"><mat-icon class="text-sm text-slate-400">person</mat-icon> {{ branch.manager }}</div>
                <div class="flex items-center gap-2"><mat-icon class="text-sm text-slate-400">phone</mat-icon> {{ branch.phone }}</div>
                <div class="flex items-center gap-2"><mat-icon class="text-sm text-slate-400">schedule</mat-icon> {{ branch.hours }}</div>
              </div>
            </div>
          }
        </div>
      </div>
    </section>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class BranchAtmSection {
  networkStats = signal([
    { icon: 'account_balance', value: '120+', label: 'Premium Branches', iconColor: 'text-bank-blue' },
    { icon: 'atm', value: '2,500+', label: 'Smart ATMs', iconColor: 'text-emerald-600' },
    { icon: 'public', value: '45', label: 'Countries', iconColor: 'text-violet-600' },
    { icon: 'support_agent', value: '24/7', label: 'Support Centers', iconColor: 'text-amber-600' },
  ]);
  branches = signal([
    { flag: '🇨🇭', name: 'Zurich Main', location: 'Bahnhofstrasse 1, Zurich', manager: 'Hans Schmidt', phone: '+41 44 123 4567', hours: 'Mon-Fri 8:00-18:00', bg: 'bg-red-50' },
    { flag: '🇬🇧', name: 'London City', location: 'Bank St, London EC2R', manager: 'Sarah Jones', phone: '+44 20 7123 4567', hours: 'Mon-Fri 9:00-17:00', bg: 'bg-blue-50' },
    { flag: '🇺🇸', name: 'Wall Street', location: '11 Wall St, New York', manager: 'Michael Ross', phone: '+1 212 555 0199', hours: 'Mon-Fri 8:00-17:00', bg: 'bg-indigo-50' },
  ]);
}
