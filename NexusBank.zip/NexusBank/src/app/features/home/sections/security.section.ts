import { Component, ChangeDetectionStrategy, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-security-section-home',
  standalone: true,
  imports: [MatIconModule],
  template: `
    <section id="security-home-section" class="section-padding relative overflow-hidden bg-section-alt">
      <div class="absolute inset-0 bg-mesh pointer-events-none"></div>
      <div class="section-container relative z-10">
        <div class="grid lg:grid-cols-2 gap-16 items-center">
          <div class="relative order-2 lg:order-1">
            <div class="relative bg-gradient-to-br from-bank-navy to-slate-800 rounded-[2.5rem] p-8 md:p-10 overflow-hidden">
              <div class="absolute top-0 right-0 w-64 h-64 bg-bank-blue/20 rounded-full blur-[80px]"></div>
              <div class="absolute bottom-0 left-0 w-48 h-48 bg-emerald-500/15 rounded-full blur-[80px]"></div>
              <div class="relative z-10 text-center">
                <div class="w-24 h-24 mx-auto rounded-3xl bg-gradient-to-br from-bank-blue to-emerald-500 flex items-center justify-center mb-8 shadow-2xl shadow-bank-blue/30 animate-float-slow">
                  <mat-icon class="text-white text-5xl">shield</mat-icon>
                </div>
                <h3 class="text-2xl font-display font-bold text-white mb-3">Enterprise-Grade Protection</h3>
                <p class="text-slate-400 text-sm font-light mb-8 max-w-sm mx-auto">Multi-layered security architecture protecting every transaction.</p>
                <div class="grid grid-cols-3 gap-3">
                  @for (m of securityMetrics(); track m.label) {
                    <div class="p-4 rounded-2xl bg-white/5 border border-white/5">
                      <p class="text-xl font-display font-bold text-white">{{ m.value }}</p>
                      <p class="text-[9px] text-slate-400 uppercase tracking-widest mt-1">{{ m.label }}</p>
                    </div>
                  }
                </div>
              </div>
              <div class="absolute top-6 right-6 px-3 py-1.5 rounded-full bg-emerald-500/20 border border-emerald-500/30 flex items-center gap-1.5">
                <span class="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse"></span>
                <span class="text-[10px] text-emerald-400 font-bold">SECURE</span>
              </div>
            </div>
          </div>
          <div class="space-y-8 order-1 lg:order-2">
            <span class="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-red-50 text-red-600 text-xs font-bold tracking-wide uppercase">
              <mat-icon class="text-sm">security</mat-icon> Bank-Grade Security
            </span>
            <h2 class="text-4xl md:text-5xl font-display font-bold text-bank-navy tracking-tight leading-tight">
              Your security is<br><span class="gradient-text">our obsession.</span>
            </h2>
            <p class="text-slate-500 text-lg font-light leading-relaxed">We employ the same security infrastructure used by the world's most trusted financial institutions.</p>
            <div class="space-y-4">
              @for (f of securityFeatures(); track f.title) {
                <div class="flex items-start gap-4 p-5 rounded-2xl border border-slate-100 hover:border-bank-blue/15 transition-all bg-white card-hover group">
                  <div class="w-11 h-11 rounded-xl flex items-center justify-center shrink-0 group-hover:scale-110 transition-all" [class]="f.iconBg">
                    <mat-icon [class]="f.iconColor" class="text-lg">{{ f.icon }}</mat-icon>
                  </div>
                  <div>
                    <h4 class="text-sm font-bold text-bank-navy mb-1">{{ f.title }}</h4>
                    <p class="text-xs text-slate-500 font-light leading-relaxed">{{ f.desc }}</p>
                  </div>
                </div>
              }
            </div>
            <div class="flex flex-wrap items-center gap-3 pt-4">
              @for (b of badges(); track b) {
                <span class="px-4 py-2 rounded-xl bg-slate-50 border border-slate-100 text-[10px] font-bold text-slate-500 uppercase tracking-wider">{{ b }}</span>
              }
            </div>
          </div>
        </div>
      </div>
    </section>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SecuritySection {
  securityMetrics = signal([
    { value: '256-bit', label: 'Encryption' },
    { value: '99.99%', label: 'Uptime' },
    { value: '24/7', label: 'Monitoring' },
  ]);
  securityFeatures = signal([
    { icon: 'fingerprint', title: 'Biometric Authentication', desc: 'Multi-factor auth with Face ID, fingerprint, and hardware keys.', iconBg: 'bg-blue-50', iconColor: 'text-bank-blue' },
    { icon: 'enhanced_encryption', title: 'End-to-End Encryption', desc: 'AES-256 encryption for all data at rest and in transit.', iconBg: 'bg-emerald-50', iconColor: 'text-emerald-600' },
    { icon: 'policy', title: 'Real-time Fraud Detection', desc: 'AI-powered anomaly detection monitoring millions of transactions.', iconBg: 'bg-amber-50', iconColor: 'text-amber-600' },
    { icon: 'admin_panel_settings', title: 'Role-Based Access Control', desc: 'Granular permissions with audit trails for every action.', iconBg: 'bg-violet-50', iconColor: 'text-violet-600' },
  ]);
  badges = signal(['PCI DSS', 'SOC 2', 'GDPR', 'ISO 27001', 'FINMA']);
}
