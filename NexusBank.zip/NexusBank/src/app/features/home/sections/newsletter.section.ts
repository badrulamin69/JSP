import { Component, ChangeDetectionStrategy } from '@angular/core';
import { RouterLink } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-newsletter-section',
  standalone: true,
  imports: [RouterLink, MatIconModule],
  template: `
    <section id="newsletter-section" class="section-padding bg-section-alt relative overflow-hidden">
      <div class="section-container relative z-10">
        <!-- Newsletter CTA -->
        <div class="max-w-3xl mx-auto text-center mb-20 p-10 md:p-14 rounded-[2.5rem] bg-white border border-slate-100 premium-shadow-lg relative overflow-hidden">
          <div class="absolute top-0 right-0 w-64 h-64 bg-blue-50 rounded-full blur-3xl -mr-32 -mt-32"></div>
          <div class="absolute bottom-0 left-0 w-48 h-48 bg-emerald-50 rounded-full blur-3xl -ml-24 -mb-24"></div>
          <div class="relative z-10">
            <div class="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br from-bank-blue to-emerald-500 flex items-center justify-center mb-6 shadow-lg shadow-bank-blue/20">
              <mat-icon class="text-white text-3xl">mail</mat-icon>
            </div>
            <h2 class="text-3xl md:text-4xl font-display font-bold text-bank-navy tracking-tight mb-3">Stay ahead of the curve.</h2>
            <p class="text-slate-500 font-light mb-8 max-w-md mx-auto">Get weekly insights on global markets, fintech trends, and exclusive banking tips.</p>
            <form class="flex flex-col sm:flex-row gap-3 max-w-lg mx-auto">
              <input type="email" placeholder="Enter your email address"
                     class="flex-1 px-5 py-4 rounded-2xl bg-slate-50 border border-slate-200 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-bank-blue transition-colors">
              <button type="button" class="btn-primary whitespace-nowrap">
                Subscribe
                <mat-icon class="ml-1 text-base align-middle">arrow_forward</mat-icon>
              </button>
            </form>
            <p class="text-[10px] text-slate-400 mt-4">No spam. Unsubscribe anytime. Read our <a routerLink="/privacy" class="underline">Privacy Policy</a>.</p>
          </div>
        </div>

        <!-- Final CTA -->
        <div class="relative bg-bank-navy rounded-[2.5rem] overflow-hidden p-10 md:p-20 text-center">
          <div class="absolute top-0 right-0 w-96 h-96 bg-bank-blue/20 blur-[120px] -mr-48 -mt-48"></div>
          <div class="absolute bottom-0 left-0 w-96 h-96 bg-emerald-500/10 blur-[120px] -ml-48 -mb-48"></div>
          <div class="relative z-10 max-w-3xl mx-auto space-y-8">
            <h2 class="text-4xl md:text-6xl font-display font-bold text-white tracking-tight">The future of banking<br><span class="gradient-text-premium">starts here.</span></h2>
            <p class="text-xl text-slate-400 font-light max-w-xl mx-auto">Join 50,000+ clients who trust Smart Secure for their global banking needs.</p>
            <div class="flex flex-col sm:flex-row justify-center gap-4">
              <button routerLink="/register" class="btn-primary text-lg px-10 py-5">
                Open Free Account
              </button>
              <button routerLink="/contact" class="px-10 py-5 rounded-2xl font-bold text-lg text-white border border-white/10 hover:bg-white/5 transition-all active:scale-95">
                Talk to an Advisor
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class NewsletterSection {}
