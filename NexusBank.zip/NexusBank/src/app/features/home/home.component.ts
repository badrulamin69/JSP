import { Component, ChangeDetectionStrategy } from '@angular/core';
import { HeroSection } from './sections/hero.section';
import { StatsSection } from './sections/stats.section';
import { FeaturesSection } from './sections/features.section';
import { DashboardPreviewSection } from './sections/dashboard-preview.section';
import { WorkflowSection } from './sections/workflow.section';
import { InternationalSection } from './sections/international.section';
import { LoanInvestmentSection } from './sections/loan-investment.section';
import { SecuritySection } from './sections/security.section';
import { BranchAtmSection } from './sections/branch-atm.section';
import { TestimonialsSection } from './sections/testimonials.section';
import { PricingSection } from './sections/pricing.section';
import { FaqSection } from './sections/faq.section';
import { MobileAppSection } from './sections/mobile-app.section';
import { NewsletterSection } from './sections/newsletter.section';

@Component({
  selector: 'app-homepage',
  standalone: true,
  imports: [
    HeroSection,
    StatsSection,
    FeaturesSection,
    DashboardPreviewSection,
    WorkflowSection,
    InternationalSection,
    LoanInvestmentSection,
    SecuritySection,
    BranchAtmSection,
    TestimonialsSection,
    PricingSection,
    FaqSection,
    MobileAppSection,
    NewsletterSection,
  ],
  template: `
    <div id="homepage-container">
      <app-hero-section />
      <app-stats-section />
      <app-features-section />
      <app-dashboard-preview-section />
      <app-workflow-section />
      <app-international-section />
      <app-loan-investment-section />
      <app-security-section-home />
      <app-branch-atm-section />
      <app-testimonials-section />
      <app-pricing-section />
      <app-faq-section />
      <app-mobile-app-section />
      <app-newsletter-section />
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class Homepage {}
