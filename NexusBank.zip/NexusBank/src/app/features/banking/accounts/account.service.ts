import { Injectable, Signal, signal } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Account, Customer, Transaction } from '../../../core/models/model';
import { ApiService } from '../../../core/services/api.service'; // Adjust path

@Injectable({
  providedIn: 'root'
})
export class AccountService {

  constructor(private apiService: ApiService) { }

  // Signals for reactive state (e.g., cached accounts)
  private _customerAccounts = signal<Account[]>([]);
  getCustomerAccounts = this._customerAccounts.asReadonly();

  // Example methods
  getAccounts(customerId?: number): Observable<Account[]> {
    // Implement API call via apiService
    return this.apiService.get<Account[]>(`accounts${customerId ? `?customerId=${customerId}` : ''}`);
  }

  getAccountById(id: number): Observable<Account> {
    return this.apiService.get<Account>(`accounts/${id}`);
  }

  createAccount(account: Partial<Account>): Observable<Account> {
    return this.apiService.post<Account>('accounts', account);
  }

  updateAccount(id: number, account: Partial<Account>): Observable<Account> {
    return this.apiService.put<Account>(`accounts/${id}`, account);
  }

  closeAccount(id: number): Observable<void> {
    return this.apiService.delete<void>(`accounts/${id}`);
  }

  getAccountBalance(id: number): Signal<number | null> {
    // This would typically involve fetching and then updating a signal
    return signal(1000.00); // Placeholder
  }
}
