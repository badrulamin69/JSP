import { Injectable, signal } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Beneficiary, Customer } from '../../../core/models/model';
import { ApiService } from '../../../core/services/api.service'; // Adjust path

@Injectable({
  providedIn: 'root'
})
export class BeneficiaryService {

  constructor(private apiService: ApiService) { }

  private _customerBeneficiaries = signal<Beneficiary[]>([]);
  getCustomerBeneficiaries = this._customerBeneficiaries.asReadonly();

  getBeneficiaries(customerId: number): Observable<Beneficiary[]> {
    return this.apiService.get<Beneficiary[]>(`beneficiaries?customerId=${customerId}`);
  }

  getBeneficiaryById(id: number): Observable<Beneficiary> {
    return this.apiService.get<Beneficiary>(`beneficiaries/${id}`);
  }

  addBeneficiary(beneficiary: Partial<Beneficiary>): Observable<Beneficiary> {
    return this.apiService.post<Beneficiary>('beneficiaries', beneficiary);
  }

  updateBeneficiary(id: number, beneficiary: Partial<Beneficiary>): Observable<Beneficiary> {
    return this.apiService.put<Beneficiary>(`beneficiaries/${id}`, beneficiary);
  }

  deleteBeneficiary(id: number): Observable<void> {
    return this.apiService.delete<void>(`beneficiaries/${id}`);
  }
}
