import { Injectable, signal, computed, Signal } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Currency, ExchangeRate, CurrencyExchange, Customer } from '../../../core/models/model';
import { ApiService } from '../../../core/services/api.service'; // Adjust path

@Injectable({
  providedIn: 'root'
})
export class CurrencyExchangeService {

  constructor(private apiService: ApiService) { }

  private _currentExchangeRates = signal<ExchangeRate[]>([]);
  getCurrentExchangeRates = this._currentExchangeRates.asReadonly();

  getExchangeRates(): Observable<ExchangeRate[]> {
    return this.apiService.get<ExchangeRate[]>('exchange-rates');
  }

  getCurrencies(): Observable<Currency[]> {
    return this.apiService.get<Currency[]>('currencies');
  }

  // Example computed signal for conversion (simplified)
  calculateConversion(fromCurrency: string, toCurrency: string, amount: number): Signal<number | null> {
    const rate = computed(() => {
      const foundRate = this._currentExchangeRates().find(r => r.fromCurrency === fromCurrency && r.toCurrency === toCurrency);
      return foundRate ? foundRate.rate : null;
    });
    return computed(() => rate() ? amount * rate()! : null);
  }

  recordCurrencyExchange(exchange: Partial<CurrencyExchange>): Observable<CurrencyExchange> {
    return this.apiService.post<CurrencyExchange>('currency-exchanges', exchange);
  }
}
