import { Injectable, signal } from '@angular/core';
import { Observable, of } from 'rxjs';
import { FixedDeposit, Account, Customer } from '../../../core/models/model';
import { ApiService } from '../../../core/services/api.service'; // Adjust path

@Injectable({
  providedIn: 'root'
})
export class FixedDepositService {

  constructor(private apiService: ApiService) { }

  private _customerFixedDeposits = signal<FixedDeposit[]>([]);
  getCustomerFixedDeposits = this._customerFixedDeposits.asReadonly();

  getFixedDeposits(customerId?: number): Observable<FixedDeposit[]> {
    return this.apiService.get<FixedDeposit[]>(`fixed-deposits${customerId ? `?customerId=${customerId}` : ''}`);
  }

  getFixedDepositById(id: number): Observable<FixedDeposit> {
    return this.apiService.get<FixedDeposit>(`fixed-deposits/${id}`);
  }

  openFixedDeposit(fd: Partial<FixedDeposit>): Observable<FixedDeposit> {
    return this.apiService.post<FixedDeposit>('fixed-deposits', fd);
  }

  updateFixedDepositStatus(id: number, status: 'Active' | 'Matured' | 'Closed'): Observable<FixedDeposit> {
    return this.apiService.put<FixedDeposit>(`fixed-deposits/${id}`, { status });
  }
}
