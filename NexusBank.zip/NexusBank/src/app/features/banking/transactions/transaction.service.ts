import { Injectable, signal, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { Transaction } from '../../../core/models/models';
import { ApiService } from '../../../core/services/api.service';
import { Api } from '../../../core/constants/api.constant';

@Injectable({
  providedIn: 'root'
})
export class TransactionService {
  private apiService = inject(ApiService);

  // Signal for reactive list of recent transactions
  private _recentTransactions = signal<Transaction[]>([]);
  getRecentTransactions = this._recentTransactions.asReadonly();

  getTransactions(filter?: Record<string, string | number | boolean>): Observable<Transaction[]> {
    return this.apiService.get<Transaction[]>(Api.TRANSACTIONS, filter);
  }

  getTransactionById(id: string): Observable<Transaction> {
    return this.apiService.get<Transaction>(`${Api.TRANSACTIONS}/${id}`);
  }

  initiateTransaction(transaction: Partial<Transaction>): Observable<Transaction> {
    return this.apiService.post<Transaction>(Api.TRANSACTIONS, transaction);
  }

  updateTransactionStatus(id: string, status: 'Pending' | 'Completed' | 'Failed'): Observable<Transaction> {
    return this.apiService.patch<Transaction>(`${Api.TRANSACTIONS}/${id}`, { status });
  }
}
