import { Injectable, signal, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { Loan, LoanPayment } from '../../../core/models/models';
import { ApiService } from '../../../core/services/api.service';
import { Api } from '../../../core/constants/api.constant';

@Injectable({
  providedIn: 'root'
})
export class LoanService {
  private apiService = inject(ApiService);

  private _customerLoans = signal<Loan[]>([]);
  getCustomerLoans = this._customerLoans.asReadonly();

  getLoans(filter?: Record<string, string | number | boolean>): Observable<Loan[]> {
    return this.apiService.get<Loan[]>(Api.LOANS, filter);
  }

  getLoanById(id: string): Observable<Loan> {
    return this.apiService.get<Loan>(`${Api.LOANS}/${id}`);
  }

  applyLoan(loan: Partial<Loan>): Observable<Loan> {
    return this.apiService.post<Loan>(Api.LOANS, loan);
  }

  updateLoanStatus(id: string, status: 'Pending' | 'Approved' | 'Rejected' | 'Closed'): Observable<Loan> {
    return this.apiService.patch<Loan>(`${Api.LOANS}/${id}`, { status });
  }

  processLoanPayment(payment: Partial<LoanPayment>): Observable<LoanPayment> {
    // Assuming payments is a separate endpoint or sub-resource
    // If it's a sub-resource of a loan, we might need the loanId
    return this.apiService.post<LoanPayment>('loanPayments', payment);
  }
}
