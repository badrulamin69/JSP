import { Injectable, signal } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Investment, Customer } from '../../../core/models/model';
import { ApiService } from '../../../core/services/api.service'; // Adjust path

@Injectable({
  providedIn: 'root'
})
export class InvestmentService {

  constructor(private apiService: ApiService) { }

  private _customerInvestments = signal<Investment[]>([]);
  getCustomerInvestments = this._customerInvestments.asReadonly();

  getInvestments(customerId?: number): Observable<Investment[]> {
    return this.apiService.get<Investment[]>(`investments${customerId ? `?customerId=${customerId}` : ''}`);
  }

  getInvestmentById(id: number): Observable<Investment> {
    return this.apiService.get<Investment>(`investments/${id}`);
  }

  createInvestment(investment: Partial<Investment>): Observable<Investment> {
    return this.apiService.post<Investment>('investments', investment);
  }

  updateInvestment(id: number, investment: Partial<Investment>): Observable<Investment> {
    return this.apiService.put<Investment>(`investments/${id}`, investment);
  }
}
