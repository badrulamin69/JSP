import { Injectable, signal, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { ATM } from '../../../core/models/models';
import { ApiService } from '../../../core/services/api.service';
import { Api } from '../../../core/constants/api.constant';

@Injectable({
  providedIn: 'root'
})
export class ATMService {
  private apiService = inject(ApiService);

  private _atmsByBranch = signal<ATM[]>([]);
  getATMsByBranch = this._atmsByBranch.asReadonly();

  getATMs(filter?: Record<string, string | number | boolean>): Observable<ATM[]> {
    return this.apiService.get<ATM[]>(Api.ATMS, filter);
  }

  getATMById(id: string): Observable<ATM> {
    return this.apiService.get<ATM>(`${Api.ATMS}/${id}`);
  }

  createATM(atm: Partial<ATM>): Observable<ATM> {
    return this.apiService.post<ATM>(Api.ATMS, atm);
  }

  updateATM(id: string, atm: Partial<ATM>): Observable<ATM> {
    return this.apiService.patch<ATM>(`${Api.ATMS}/${id}`, atm);
  }

  deleteATM(id: string): Observable<void> {
    return this.apiService.delete<void>(`${Api.ATMS}/${id}`);
  }

  refillATMCash(id: string, amount: number): Observable<ATM> {
    return this.apiService.post<ATM>(`${Api.ATMS}/${id}/refill`, { amount });
  }
}
