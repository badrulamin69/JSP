import { Injectable, signal, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { Branch } from '../../../core/models/models';
import { ApiService } from '../../../core/services/api.service';
import { Api } from '../../../core/constants/api.constant';

@Injectable({
  providedIn: 'root'
})
export class BranchService {
  private apiService = inject(ApiService);

  private _allActiveBranches = signal<Branch[]>([]);
  getAllActiveBranches = this._allActiveBranches.asReadonly();

  getBranches(filter?: Record<string, string | number | boolean>): Observable<Branch[]> {
    return this.apiService.get<Branch[]>(Api.BRANCHES, filter);
  }

  getBranchById(id: string): Observable<Branch> {
    return this.apiService.get<Branch>(`${Api.BRANCHES}/${id}`);
  }

  createBranch(branch: Partial<Branch>): Observable<Branch> {
    return this.apiService.post<Branch>(Api.BRANCHES, branch);
  }

  updateBranch(id: string, branch: Partial<Branch>): Observable<Branch> {
    return this.apiService.patch<Branch>(`${Api.BRANCHES}/${id}`, branch);
  }

  deleteBranch(id: string): Observable<void> {
    return this.apiService.delete<void>(`${Api.BRANCHES}/${id}`);
  }
}
