import { Component, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { BankingCustomerService } from './banking-customer.service';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-customer-transfer',
  standalone: true,
  imports: [CommonModule, MatIconModule, ReactiveFormsModule, RouterModule],
  template: `
    <div class="max-w-3xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-8 duration-700">
      
      <div class="text-center space-y-2">
         <h2 class="text-3xl font-bold text-slate-900 tracking-tight">Express Global Transfer</h2>
         <p class="text-slate-500 font-light text-sm italic">Move funds securely across our Tier-1 banking mesh.</p>
      </div>

      <div class="bg-white rounded-[3rem] border border-slate-100 shadow-sm overflow-hidden min-h-[600px] flex flex-col">
         <!-- Step Progress -->
         <div class="flex border-b border-slate-50">
            <div [class]="'flex-1 p-6 text-center border-r border-slate-50 transition-all ' + (currentStep() === 1 ? 'bg-emerald-50 text-emerald-700' : 'text-slate-400')">
               <span class="text-[10px] font-bold uppercase tracking-widest block mb-1">Step 01</span>
               <p class="text-xs font-bold">Configure Transaction</p>
            </div>
            <div [class]="'flex-1 p-6 text-center transition-all ' + (currentStep() === 2 ? 'bg-emerald-50 text-emerald-700' : 'text-slate-400')">
               <span class="text-[10px] font-bold uppercase tracking-widest block mb-1">Step 02</span>
               <p class="text-xs font-bold">Identity Verification</p>
            </div>
         </div>

         <div class="p-8 lg:p-12 flex-1 flex flex-col justify-center">
            @if (currentStep() === 1) {
               <form [formGroup]="transferForm" class="space-y-8">
                  <!-- From Account -->
                  <div class="space-y-4">
                     <label class="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Source Account</label>
                     <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        @for (acc of customerService.accounts(); track acc.id) {
                           <label class="relative flex items-center gap-4 p-5 border-2 rounded-2xl cursor-pointer transition-all hover:bg-slate-50 group" 
                                  [class.border-emerald-600]="transferForm.get('fromAccount')?.value === acc.id"
                                  [class.border-slate-100]="transferForm.get('fromAccount')?.value !== acc.id">
                              <input type="radio" formControlName="fromAccount" [value]="acc.id" class="hidden">
                              <div [class]="'w-10 h-10 rounded-xl flex items-center justify-center border transition-all ' + (transferForm.get('fromAccount')?.value === acc.id ? 'bg-emerald-600 text-white border-emerald-600' : 'bg-white text-slate-400 border-slate-100 group-hover:bg-slate-900 group-hover:text-white')">
                                 <mat-icon class="text-sm">account_balance_wallet</mat-icon>
                              </div>
                              <div class="flex-1">
                                 <p class="text-[10px] font-bold">{{ acc.type }} Asset</p>
                                 <p class="text-sm font-bold font-mono">{{ acc.balance | currency:'USD' }}</p>
                              </div>
                              @if (transferForm.get('fromAccount')?.value === acc.id) {
                                 <div class="w-5 h-5 bg-emerald-600 rounded-full flex items-center justify-center text-white">
                                    <mat-icon class="text-xs">check</mat-icon>
                                 </div>
                              }
                           </label>
                        }
                     </div>
                  </div>

                  <!-- Beneficiary -->
                  <div class="space-y-4">
                     <label class="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Recipient Beneficiary</label>
                     <select formControlName="toBeneficiary" class="w-full h-14 px-5 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all text-sm font-bold">
                        <option value="" disabled>Select a trusted beneficiary</option>
                        @for (ben of customerService.beneficiaries(); track ben.id) {
                           <option [value]="ben.id">{{ ben.name }} - {{ ben.bank }} ({{ ben.account }})</option>
                        }
                     </select>
                  </div>

                  <!-- Amount -->
                  <div class="space-y-4">
                     <label class="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Amount to Transfer</label>
                     <div class="relative group">
                        <div class="absolute left-6 top-1/2 -translate-y-1/2 text-2xl font-bold text-slate-400 group-focus-within:text-emerald-600 transition-colors">$</div>
                        <input type="number" formControlName="amount" placeholder="0.00" class="w-full h-24 pl-12 pr-6 bg-slate-50 border border-slate-100 rounded-[2rem] outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all text-4xl font-mono font-bold tracking-tighter placeholder:text-slate-200">
                        <div class="absolute right-6 top-1/2 -translate-y-1/2">
                           <span class="px-4 py-2 bg-slate-900 text-white rounded-xl text-[10px] font-bold uppercase tracking-widest">USD</span>
                        </div>
                     </div>
                  </div>

                  <button (click)="nextStep()" [disabled]="transferForm.invalid" class="w-full h-16 bg-slate-900 text-white rounded-3xl font-bold uppercase tracking-widest shadow-2xl hover:bg-slate-800 disabled:opacity-30 disabled:cursor-not-allowed transition-all active:scale-95 flex items-center justify-center gap-3">
                     Authorize Transfer <mat-icon>arrow_forward</mat-icon>
                  </button>
               </form>
            } @else if (currentStep() === 2) {
               <div class="text-center space-y-10 py-6 max-w-sm mx-auto">
                  <div class="w-20 h-20 bg-emerald-50 rounded-full flex items-center justify-center mx-auto border border-emerald-100 animate-pulse">
                     <mat-icon class="text-3xl text-emerald-600">security_update_good</mat-icon>
                  </div>
                  <div>
                    <h4 class="text-xl font-bold text-slate-900">Final Authorization</h4>
                    <p class="text-sm text-slate-500 mt-2 font-light leading-relaxed">For your protection, we've sent a 6-digit mesh-key to your device ending in <span class="text-slate-900 font-bold">**** 8901</span>.</p>
                  </div>

                  <div class="flex justify-center gap-2">
                     @for (i of [1,2,3,4,5,6]; track i) {
                        <input type="text" maxlength="1" class="w-10 h-14 bg-slate-50 border border-slate-200 rounded-xl text-center text-xl font-bold font-mono focus:border-emerald-500 focus:bg-white outline-none transition-all">
                     }
                  </div>

                  <div class="bg-slate-50 rounded-3xl p-6 border border-slate-100 text-left">
                     <div class="flex justify-between items-center font-bold mb-4">
                        <span class="text-[10px] text-slate-400 uppercase tracking-widest">Total Transaction</span>
                        <span class="text-xl font-mono text-slate-900">{{ transferForm.get('amount')?.value | currency:'USD' }}</span>
                     </div>
                     <div class="h-1 w-full bg-slate-200 rounded-full overflow-hidden">
                        <div class="h-full bg-emerald-500 w-full animate-pulse"></div>
                     </div>
                  </div>

                  <div class="flex gap-4">
                     <button (click)="prevStep()" class="flex-1 h-14 bg-white text-slate-600 border border-slate-100 rounded-2xl text-[10px] font-bold uppercase tracking-widest hover:bg-slate-50 transition-all">Go Back</button>
                     <button (click)="confirmTransfer()" class="flex-[2] h-14 bg-emerald-600 text-white rounded-2xl text-[10px] font-bold uppercase tracking-widest shadow-xl shadow-emerald-600/20 hover:bg-emerald-700 transition-all active:scale-95">Complete Transfer</button>
                  </div>
               </div>
            } @else if (currentStep() === 3) {
               <div class="text-center space-y-8 py-10 animate-in zoom-in-95 duration-500">
                  <div class="w-24 h-24 bg-emerald-500 text-white rounded-full flex items-center justify-center mx-auto shadow-2xl shadow-emerald-500/40">
                     <mat-icon class="text-5xl">verified</mat-icon>
                  </div>
                  <div>
                    <h4 class="text-3xl font-bold text-slate-900 tracking-tight">Payment Dispatched</h4>
                    <p class="text-sm text-slate-500 mt-2 font-light">Mesh ID: <span class="text-slate-900 font-mono font-bold uppercase">TX-{{ (100000 + Math.random() * 900000) | number:'1.0-0' }}</span></p>
                  </div>

                  <div class="p-8 bg-slate-900 rounded-[2.5rem] text-white space-y-6 relative overflow-hidden text-left mx-auto max-w-sm">
                     <div class="absolute -top-10 -right-10 w-32 h-32 bg-emerald-500/20 rounded-full blur-2xl"></div>
                     <div class="space-y-4 relative z-10">
                        <div class="flex justify-between items-center border-b border-white/10 pb-4">
                           <span class="text-[10px] text-white/40 font-bold uppercase tracking-widest">Amount</span>
                           <span class="text-xl font-bold font-mono">{{ transferForm.get('amount')?.value | currency:'USD' }}</span>
                        </div>
                        <div class="flex justify-between items-center">
                           <span class="text-[10px] text-white/40 font-bold uppercase tracking-widest">Recipient</span>
                           <span class="text-sm font-bold">{{ recipientName() }}</span>
                        </div>
                     </div>
                  </div>

                  <div class="flex gap-4 max-w-sm mx-auto">
                     <button (click)="resetForm()" class="flex-1 h-14 bg-slate-900 text-white rounded-2xl text-[10px] font-bold uppercase tracking-widest hover:bg-slate-800 transition-all">New Transfer</button>
                     <button [routerLink]="['/customer/dashboard']" class="flex-1 h-14 bg-slate-100 text-slate-600 rounded-2xl text-[10px] font-bold uppercase tracking-widest hover:bg-slate-200 transition-all">Dashboard</button>
                  </div>
               </div>
            }
         </div>
      </div>

      <div class="bg-amber-50 rounded-3xl p-6 border border-amber-100 flex gap-5 items-center">
         <div class="w-10 h-10 bg-amber-100 rounded-xl flex items-center justify-center text-amber-600 shrink-0">
           <mat-icon class="text-xl">lock_clock</mat-icon>
         </div>
         <p class="text-[10px] font-bold text-amber-700 leading-relaxed uppercase tracking-wider">Smart Secure mesh technology ensures your transfers are irreversible once authorized with your biometric key or OTP.</p>
      </div>

    </div>
  `
})
export class CustomerTransfer {
  customerService = inject(BankingCustomerService);
  private fb = inject(FormBuilder);
  Math = Math;

  currentStep = signal(1);
  transferForm = this.fb.group({
    fromAccount: ['', Validators.required],
    toBeneficiary: ['', Validators.required],
    amount: [null as number | null, [Validators.required, Validators.min(1), Validators.max(50000)]],
    description: ['']
  });

  recipientName = computed(() => {
    const benId = this.transferForm.get('toBeneficiary')?.value;
    return this.customerService.beneficiaries().find(b => b.id === benId)?.name || 'Recipient';
  });

  nextStep() {
    if (this.transferForm.valid) {
      this.currentStep.set(2);
    }
  }

  prevStep() {
    this.currentStep.set(1);
  }

  confirmTransfer() {
    const { fromAccount, toBeneficiary, amount, description } = this.transferForm.value;
    if (fromAccount && toBeneficiary && amount) {
      this.customerService.transferMoney(fromAccount, toBeneficiary, Number(amount), description || 'Mesh Transfer')
        .subscribe(() => {
          this.currentStep.set(3);
        });
    }
  }

  resetForm() {
    this.transferForm.reset();
    this.currentStep.set(1);
  }
}
