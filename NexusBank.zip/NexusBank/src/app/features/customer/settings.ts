import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-customer-settings',
  standalone: true,
  imports: [CommonModule, MatIconModule, ReactiveFormsModule],
  template: `
    <div class="max-w-4xl mx-auto space-y-10 animate-in fade-in slide-in-from-bottom-8 duration-700">
      
      <div class="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm flex items-center justify-between">
         <div class="flex items-center gap-6">
            <div class="relative">
               <img src="https://i.pravatar.cc/150?u=jane" class="w-24 h-24 rounded-[2rem] shadow-xl" alt="Jane">
               <button class="absolute -bottom-2 -right-2 p-2 bg-blue-600 text-white rounded-xl shadow-lg">
                  <mat-icon class="text-sm">photo_camera</mat-icon>
               </button>
            </div>
            <div>
               <h2 class="text-3xl font-display font-bold text-slate-900 tracking-tight">Jane Cooper</h2>
               <p class="text-slate-500 font-light mt-1">Global Gold Member • Zurich, CH</p>
            </div>
         </div>
         <div class="hidden sm:flex flex-col items-end">
            <span class="px-3 py-1 bg-emerald-50 text-emerald-600 text-[10px] font-bold rounded-full uppercase tracking-widest border border-emerald-100 mb-2">Verified Profile</span>
            <p class="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Last login: 2 min ago</p>
         </div>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
         
         <!-- Security Settings -->
         <div class="bg-white rounded-[3rem] p-10 border border-slate-100 shadow-sm space-y-8">
            <h3 class="text-xl font-bold text-slate-900 flex items-center gap-3">
               <mat-icon class="text-blue-600">verified_user</mat-icon>
               Security Mesh
            </h3>

            <div class="space-y-6">
               <div class="flex items-center justify-between p-4 bg-slate-50 rounded-2xl">
                  <div>
                     <p class="text-sm font-bold text-slate-900">Two-Factor Auth</p>
                     <p class="text-[10px] text-slate-500 mt-1 uppercase tracking-widest font-bold">Recommended</p>
                  </div>
                  <div class="w-12 h-6 bg-emerald-500 rounded-full relative p-1 cursor-pointer">
                     <div class="w-4 h-4 bg-white rounded-full ml-auto"></div>
                  </div>
               </div>

               <div class="flex items-center justify-between p-4 bg-slate-50 rounded-2xl opacity-50">
                  <div>
                     <p class="text-sm font-bold text-slate-900">Biometric Login</p>
                     <p class="text-[10px] text-slate-500 mt-1 uppercase tracking-widest font-bold">Enabled on FaceID</p>
                  </div>
                  <mat-icon class="text-emerald-500">check_circle</mat-icon>
               </div>
            </div>

            <button class="w-full py-4 bg-slate-900 text-white rounded-2xl text-[10px] font-bold uppercase tracking-widest hover:bg-slate-800 transition-all">Update Access Key</button>
         </div>

         <!-- Contact Info -->
         <div class="bg-white rounded-[3rem] p-10 border border-slate-100 shadow-sm space-y-8">
            <h3 class="text-xl font-bold text-slate-900 flex items-center gap-3">
               <mat-icon class="text-blue-600">alternate_email</mat-icon>
               Contact Hub
            </h3>

            <form [formGroup]="profileForm" class="space-y-4">
               <div>
                  <label for="profileEmail" class="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-2 mb-2 block">Primary Email</label>
                  <input id="profileEmail" type="email" formControlName="email" class="w-full bg-slate-50 border border-slate-100 rounded-xl px-6 py-3 font-medium text-sm outline-hidden focus:border-blue-500">
               </div>
               <div>
                  <label for="profilePhone" class="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-2 mb-2 block">Mobile Link</label>
                  <input id="profilePhone" type="text" formControlName="phone" class="w-full bg-slate-50 border border-slate-100 rounded-xl px-6 py-3 font-medium text-sm outline-hidden focus:border-blue-500">
               </div>
            </form>

            <button (click)="save()" class="w-full py-4 bg-blue-600 text-white rounded-2xl text-[10px] font-bold uppercase tracking-widest hover:bg-blue-700 transition-all shadow-lg shadow-blue-500/20">Sync Profile Data</button>
         </div>
      </div>
    </div>
  `
})
export class CustomerSettings {
  private fb = inject(FormBuilder);
  
  profileForm = this.fb.group({
    email: ['jane.cooper@example.com', [Validators.required, Validators.email]],
    phone: ['+41 44 123 45 67', Validators.required]
  });

  save() {
    alert('Profile synchronization initialized across Swiss servers.');
  }
}
