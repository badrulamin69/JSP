import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-customer-profile',
  standalone: true,
  imports: [CommonModule, MatIconModule, ReactiveFormsModule],
  template: `
    <div class="space-y-10 animate-in fade-in slide-in-from-right-4 duration-500 pb-20">
      
      <!-- Page Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div>
           <h2 class="text-3xl font-bold text-slate-900 tracking-tight">Identity Hub</h2>
           <p class="text-xs text-slate-500 mt-1 uppercase tracking-widest font-bold">Manage your verified personhood and contact protocols</p>
        </div>
        <div class="flex gap-3">
           <button class="px-6 py-3 bg-white text-slate-600 rounded-2xl text-[10px] font-bold uppercase tracking-widest border border-slate-100 shadow-sm hover:bg-slate-50 transition-all">Verify KYB</button>
           <button class="px-6 py-3 bg-slate-900 text-white rounded-2xl text-[10px] font-bold uppercase tracking-widest shadow-lg shadow-slate-900/10 hover:bg-slate-800 transition-all">Download Mesh ID</button>
        </div>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-4 gap-10">
         <div class="lg:col-span-1 space-y-8">
            <div class="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm text-center relative overflow-hidden group">
               <div class="absolute -top-10 -right-10 w-32 h-32 bg-slate-50 rounded-full blur-2xl"></div>
               <div class="relative z-10">
                  <div class="relative inline-block group/avatar">
                     <div class="w-32 h-32 rounded-[2.5rem] bg-slate-100 border-4 border-slate-50 overflow-hidden shadow-2xl transition-transform group-hover/avatar:scale-105 duration-500">
                        <img src="https://i.pravatar.cc/300?u=jane" class="w-full h-full object-cover" alt="Profile">
                     </div>
                     <button class="absolute -bottom-2 -right-2 w-10 h-10 bg-slate-900 text-white rounded-xl shadow-xl flex items-center justify-center hover:bg-emerald-600 transition-all">
                        <mat-icon class="text-sm">photo_camera</mat-icon>
                     </button>
                  </div>
                  <h3 class="mt-8 text-xl font-bold text-slate-900">Jane Cooper</h3>
                  <p class="text-[10px] font-bold text-emerald-600 uppercase tracking-widest mt-1 italic">Verified Hub Master</p>
                  
                  <div class="mt-10 p-6 bg-slate-50 rounded-3xl border border-slate-100 space-y-4">
                     <div class="flex items-center gap-3 text-left">
                        <mat-icon class="text-slate-400 text-sm">alternate_email</mat-icon>
                        <span class="text-[10px] font-bold text-slate-900 font-mono">jane.cooper@mesh.id</span>
                     </div>
                     <div class="flex items-center gap-3 text-left">
                        <mat-icon class="text-slate-400 text-sm">verified_user</mat-icon>
                        <span class="text-[10px] font-bold text-slate-900 font-mono tracking-widest">KYC-LEVEL-04</span>
                     </div>
                  </div>
               </div>
            </div>

            <div class="bg-emerald-900 p-8 rounded-[2.5rem] text-white shadow-xl relative overflow-hidden flex flex-col justify-between min-h-[220px] group cursor-pointer">
               <div class="absolute -right-10 -bottom-10 w-40 h-40 bg-emerald-500/10 rounded-full blur-3xl transform group-hover:scale-150 transition-transform duration-1000"></div>
               <div>
                  <mat-icon class="text-3xl text-emerald-500 mb-4 animate-pulse">stars</mat-icon>
                  <p class="text-sm font-bold leading-tight uppercase tracking-widest italic">Smart Titanium Member</p>
               </div>
               <div>
                  <p class="text-[9px] text-white/40 font-bold uppercase tracking-widest mb-2 font-mono">Member Since 2021</p>
                  <div class="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                     <div class="h-full bg-emerald-500 w-3/4"></div>
                  </div>
               </div>
            </div>
         </div>

         <div class="lg:col-span-3">
            <div class="bg-white p-10 lg:p-14 rounded-[3.5rem] border border-slate-100 shadow-sm relative overflow-hidden group">
               <div class="absolute -right-20 -top-20 w-80 h-80 bg-slate-50 rounded-full blur-3xl group-hover:bg-emerald-50 transition-colors duration-[2s]"></div>
               
               <div class="relative z-10">
                  <div class="flex justify-between items-center mb-12">
                     <h3 class="text-xl font-bold text-slate-900 tracking-tight">Identity Protocols</h3>
                     <button class="px-6 py-2.5 bg-slate-900 text-white rounded-xl text-[10px] font-bold uppercase tracking-widest hover:bg-slate-800 transition-all shadow-xl shadow-slate-900/10">Save Hub State</button>
                  </div>

                  <form [formGroup]="profileForm" class="grid grid-cols-1 md:grid-cols-2 gap-x-10 gap-y-8">
                     <div class="space-y-2">
                        <label class="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">Full Legal Forename</label>
                        <input type="text" formControlName="firstName" class="w-full h-14 px-6 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:border-emerald-500 transition-all font-bold text-sm">
                     </div>
                     <div class="space-y-2">
                        <label class="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">Legal Family Name</label>
                        <input type="text" formControlName="lastName" class="w-full h-14 px-6 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:border-emerald-500 transition-all font-bold text-sm">
                     </div>
                     <div class="space-y-2">
                        <label class="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">Primary Communication Port</label>
                        <input type="email" formControlName="email" class="w-full h-14 px-6 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:border-emerald-500 transition-all font-bold text-sm">
                     </div>
                     <div class="space-y-2">
                        <label class="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">Verified Mobile Hub</label>
                        <input type="text" formControlName="phone" class="w-full h-14 px-6 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:border-emerald-500 transition-all font-bold text-sm">
                     </div>
                     <div class="md:col-span-2 space-y-2">
                        <label class="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">Residential Zone Address</label>
                        <textarea formControlName="address" rows="3" class="w-full p-6 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:border-emerald-500 transition-all font-medium text-sm no-scrollbar"></textarea>
                     </div>
                  </form>

                  <div class="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8 pt-10 border-t border-slate-50">
                     <div class="space-y-4">
                        <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-4">Mailing Hub</p>
                        <div class="flex items-center gap-4">
                           <div class="w-1.5 h-10 bg-slate-100 rounded-full"></div>
                           <p class="text-xs font-bold text-slate-900 leading-relaxed uppercase tracking-widest italic">Same as residential zone gateway</p>
                        </div>
                     </div>
                     <div class="space-y-4">
                        <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-4">Hub Visibility</p>
                        <div class="flex items-center gap-3">
                           <div class="w-12 h-6 bg-emerald-500 rounded-full relative p-1 cursor-pointer">
                              <div class="w-4 h-4 bg-white rounded-full ml-6 transition-all"></div>
                           </div>
                           <span class="text-[9px] font-bold text-slate-900 uppercase tracking-widest">Public Mesh Profile</span>
                        </div>
                     </div>
                     <div class="space-y-4">
                        <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-4">Account Metadata</p>
                        <p class="text-xs text-slate-400 font-mono font-bold tracking-tighter">NODE_ID: SM-8841-SEC-2024</p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>

    </div>
  `
})
export class CustomerProfile {
  private fb = inject(FormBuilder);

  profileForm = this.fb.group({
    firstName: ['Jane', Validators.required],
    lastName: ['Cooper', Validators.required],
    email: ['jane.cooper@mesh.id', [Validators.required, Validators.email]],
    phone: ['+1 (555) 902-2441', Validators.required],
    address: ['457 Mesh Street, Grid Zone 04, New York, NY 10001', Validators.required]
  });
}
