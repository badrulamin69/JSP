import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BankingCustomerService } from './banking-customer.service';

@Component({
  selector: 'app-customer-accounts',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-10 animate-in fade-in slide-in-from-right-4 duration-500">
      
      <!-- Summary Stats -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div class="bg-white p-8 rounded-[2rem] border border-slate-100 shadow-sm flex items-center gap-6">
          <div class="w-14 h-14 bg-emerald-50 rounded-2xl flex items-center justify-center border border-emerald-100">
            <mat-icon class="text-emerald-600">account_balance_wallet</mat-icon>
          </div>
          <div>
            <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Total Assets</p>
            <p class="text-2xl font-bold font-mono text-slate-900">{{ customerService.totalBalance() | currency:'USD' }}</p>
          </div>
        </div>
        <div class="bg-white p-8 rounded-[2rem] border border-slate-100 shadow-sm flex items-center gap-6">
          <div class="w-14 h-14 bg-blue-50 rounded-2xl flex items-center justify-center border border-blue-100">
            <mat-icon class="text-blue-600">payment</mat-icon>
          </div>
          <div>
            <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Active Cards</p>
            <p class="text-2xl font-bold font-mono text-slate-900">{{ activeCardsCount() }}</p>
          </div>
        </div>
        <div class="bg-slate-900 p-8 rounded-[2rem] shadow-xl flex items-center gap-6 relative overflow-hidden group">
          <div class="absolute -right-10 -top-10 w-24 h-24 bg-emerald-500/10 rounded-full blur-2xl group-hover:scale-150 transition-transform duration-700"></div>
          <div class="w-14 h-14 bg-white/10 rounded-2xl flex items-center justify-center border border-white/10">
            <mat-icon class="text-emerald-400">savings</mat-icon>
          </div>
          <div>
            <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Savings Goals</p>
            <p class="text-2xl font-bold font-mono text-white">4 Active</p>
          </div>
        </div>
      </div>

      <!-- Assets Table -->
      <section>
         <div class="flex items-center justify-between mb-8">
            <div>
              <h2 class="text-2xl font-bold text-slate-900 tracking-tight">Financial Portfolio</h2>
              <p class="text-xs text-slate-500 mt-1 uppercase tracking-widest font-bold">Manage your cash and assets</p>
            </div>
            <button class="px-6 py-3 bg-emerald-600 text-white rounded-2xl text-[10px] font-bold uppercase tracking-widest hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-600/20 active:scale-95 flex items-center gap-2">
               <mat-icon class="text-[14px]">add</mat-icon>
               Create New Account
            </button>
         </div>

         <div class="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm overflow-hidden">
            @for (acc of customerService.accounts(); track acc.id) {
               <div class="p-6 lg:p-10 border-b border-slate-50 last:border-0 hover:bg-slate-50/50 transition-all group flex flex-col md:flex-row items-center gap-8">
                  <div class="flex items-center gap-5 w-full md:w-1/3">
                     <div class="w-14 h-14 bg-slate-100 text-slate-600 rounded-2xl flex items-center justify-center group-hover:bg-slate-900 group-hover:text-white transition-all shadow-sm">
                        <mat-icon>{{ acc.type === 'Savings' ? 'savings' : 'account_balance' }}</mat-icon>
                     </div>
                     <div>
                        <h4 class="font-bold text-slate-900">{{ acc.type }} Account</h4>
                        <p class="text-[10px] text-slate-400 font-mono tracking-widest">{{ acc.accountNumber }}</p>
                     </div>
                  </div>

                  <div class="flex-1 w-full md:w-auto px-10 border-l border-r border-slate-50 hidden lg:block">
                     <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">Portfolio Share</p>
                     <div class="flex items-center gap-4">
                        <div class="flex-1 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                           <div class="h-full bg-emerald-500" [style.width]="(acc.balance / customerService.totalBalance() * 100) + '%'"></div>
                        </div>
                        <span class="text-slate-900 text-[10px] font-bold">{{ (acc.balance / customerService.totalBalance() * 100) | number:'1.0-0' }}%</span>
                     </div>
                  </div>

                  <div class="text-center md:text-right w-full md:w-1/4">
                     <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Balance</p>
                     <p class="text-2xl font-bold font-mono text-slate-900 tracking-tight">{{ acc.balance | currency:'USD' }}</p>
                  </div>

                  <div class="flex items-center gap-2 w-full md:w-auto justify-center md:justify-end">
                     <button class="p-3 bg-slate-50 text-slate-500 rounded-xl hover:bg-slate-900 hover:text-white transition-all">
                        <mat-icon class="text-lg">visibility</mat-icon>
                     </button>
                     <button class="p-3 bg-slate-50 text-slate-500 rounded-xl hover:bg-slate-900 hover:text-white transition-all">
                        <mat-icon class="text-lg">history</mat-icon>
                     </button>
                     <button class="px-5 py-3 bg-emerald-600 text-white rounded-xl text-[10px] font-bold uppercase tracking-widest hover:bg-emerald-700 transition-all font-mono">Transfer</button>
                  </div>
               </div>
            }
         </div>
      </section>

      <!-- Cards Section -->
      <section>
         <div class="flex items-center justify-between mb-8">
            <div>
              <h2 class="text-2xl font-bold text-slate-900 tracking-tight">Active Banking Cards</h2>
              <p class="text-xs text-slate-500 mt-1 uppercase tracking-widest font-bold">Secure your physical and virtual cards</p>
            </div>
            <button class="text-emerald-600 text-xs font-bold uppercase tracking-widest hover:underline flex items-center gap-1">
              View All Cards <mat-icon class="text-sm">chevron_right</mat-icon>
            </button>
         </div>

         <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            @for (card of customerService.cards(); track card.id) {
               <div [class]="'relative min-h-[200px] rounded-[2rem] p-8 text-white overflow-hidden shadow-xl group transition-all duration-700 ' + (card.type.includes('Visa') ? 'bg-linear-to-tr from-slate-900 to-slate-800' : 'bg-linear-to-tr from-emerald-900 to-teal-900')">
                  <div class="absolute -top-10 -right-10 w-40 h-40 bg-white/5 rounded-full blur-3xl transition-transform group-hover:scale-150 duration-1000"></div>
                  
                  <div class="relative z-10 flex flex-col h-full justify-between">
                     <div class="flex justify-between items-start mb-10">
                        <div>
                           <p class="text-[10px] font-bold text-white/40 uppercase tracking-widest mb-1">{{ card.type }}</p>
                           <h4 class="text-lg font-bold tracking-tight">Smart Virtual</h4>
                        </div>
                        <mat-icon class="text-3xl text-white/20">contactless</mat-icon>
                     </div>

                     <div>
                        <p class="text-xl font-mono font-bold tracking-widest mb-6">{{ card.number }}</p>
                        <div class="flex justify-between items-end">
                           <div class="flex gap-10">
                              <div>
                                 <p class="text-[8px] font-bold text-white/40 uppercase tracking-widest mb-1">Holder</p>
                                 <p class="text-[10px] font-bold uppercase">J. Cooper</p>
                              </div>
                              <div>
                                 <p class="text-[8px] font-bold text-white/40 uppercase tracking-widest mb-1">Expires</p>
                                 <p class="text-[10px] font-bold font-mono">{{ card.expiry }}</p>
                              </div>
                           </div>
                           <div class="w-12 h-8 bg-white/10 rounded overflow-hidden flex items-center justify-center backdrop-blur-md border border-white/5 grayscale">
                              <mat-icon class="text-white/40 text-[18px]">credit_card</mat-icon>
                           </div>
                        </div>
                     </div>
                  </div>

                  @if (card.status === 'blocked') {
                     <div class="absolute inset-0 bg-slate-900/90 backdrop-blur-md flex items-center justify-center z-20">
                        <div class="text-center">
                           <mat-icon class="text-4xl text-rose-500 mb-2">lock_person</mat-icon>
                           <p class="text-[10px] font-bold uppercase tracking-widest">Card Locked</p>
                        </div>
                     </div>
                  }
                  
                  <button (click)="toggleCard(card.id, card.status)" class="absolute top-4 right-4 p-3 bg-white/10 hover:bg-white/20 rounded-xl transition-all z-30 opacity-0 group-hover:opacity-100">
                     <mat-icon class="text-sm">{{ card.status === 'active' ? 'lock' : 'lock_open' }}</mat-icon>
                  </button>
               </div>
            }

            <div class="min-h-[200px] rounded-[2rem] border-2 border-dashed border-slate-200 p-8 flex flex-col items-center justify-center text-center group cursor-pointer hover:border-emerald-500 hover:bg-emerald-50/20 transition-all">
               <div class="w-14 h-14 bg-slate-50 rounded-2xl flex items-center justify-center mb-4 group-hover:bg-emerald-50 group-hover:scale-110 transition-all border border-slate-100 shadow-sm">
                  <mat-icon class="text-slate-400 group-hover:text-emerald-600">add</mat-icon>
               </div>
               <p class="text-sm font-bold text-slate-700">Instant Virtual Card</p>
               <p class="text-[10px] text-slate-400 uppercase tracking-widest font-bold mt-1">One-time payment safety</p>
            </div>
         </div>
      </section>
    </div>
  `
})
export class CustomerAccounts {
  customerService = inject(BankingCustomerService);

  activeCardsCount = () => this.customerService.cards().filter(c => c.status === 'active').length;

  toggleCard(id: string, status: string) {
    if (confirm(`Are you sure you want to ${status === 'active' ? 'lock' : 'unlock'} this card?`)) {
      this.customerService.toggleCardStatus(id, status).subscribe();
    }
  }
}
