import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-transfer-money',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './transfer-money.component.html',
  styleUrl: './transfer-money.component.css'
})
export class TransferMoneyComponent {}