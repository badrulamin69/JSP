import { Injectable, signal, computed, inject, PLATFORM_ID, effect } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { isPlatformBrowser } from '@angular/common';
import { toSignal } from '@angular/core/rxjs-interop';
import { map, tap, of, switchMap, Observable } from 'rxjs';
import { SessionService } from '../../core/services/session.service';

export interface BankAccount {
  id: string;
  customerId: string;
  type: string;
  balance: number;
  currency: string;
  accountNumber: string;
  status: string;
}

export interface BankCard {
  id: string;
  customerId: string;
  type: string;
  number: string;
  expiry: string;
  status: 'active' | 'blocked' | 'expired';
  limit: number;
  cvv: string;
}

export interface Beneficiary {
  id: string;
  customerId: string;
  name: string;
  account: string;
  bank: string;
  type: 'Domestic' | 'International';
}

export interface Transaction {
  id: string;
  customerId: string;
  type: 'transfer' | 'deposit' | 'withdrawal';
  amount: number;
  status: string;
  date: string;
  description: string;
  category: string;
}

export interface Loan {
  id: string;
  customerId: string;
  amount: number;
  type: string;
  status: string;
  interestRate: number; // matched with component
  duration: number;
  loanNumber: string; // added
  paidAmount: number; // added
  monthlyInstallment: number; // added
  nextPayment: string;
}

export interface LoanApplication {
  id: string;
  customerId: string;
  amount: number;
  type: string;
  status: string;
  date: string;
  tenure?: number; // added tenure
}

export interface FixedDeposit {
  id: string;
  customerId: string;
  amount: number;
  interestRate: number;
  durationMonths: number;
  startDate: string;
  maturityDate: string;
  status: string;
}

export interface Notification {
  id: string;
  customerId: string;
  title: string;
  message: string;
  date: string;
  read: boolean;
  type: 'security' | 'info' | 'success' | 'transfer'; // added transfer
}

export interface Investment {
  id: string;
  customerId: string;
  name: string;
  amount: number;
  currentValue: number;
  returns: number; // matched with component
  type: string;
}

@Injectable({
  providedIn: 'root'
})
export class BankingCustomerService {
  private http = inject(HttpClient);
  private session = inject(SessionService);
  currentCustomerId = computed(() => this.session.session()?.id || '1');

  accounts = signal<BankAccount[]>([]);
  cards = signal<BankCard[]>([]);
  beneficiaries = signal<Beneficiary[]>([]);
  transactions = signal<Transaction[]>([]);
  loans = signal<Loan[]>([]);
  loanApplications = signal<LoanApplication[]>([]);
  fixedDeposits = signal<FixedDeposit[]>([]);
  investments = signal<Investment[]>([]);
  notifications = signal<Notification[]>([]);

  totalBalance = computed(() => this.accounts().reduce((acc, a) => acc + a.balance, 0));
  unreadNotificationsCount = computed(() => this.notifications().filter(n => !n.read).length);

  platformId = inject(PLATFORM_ID);

  constructor() {
    effect(() => {
      if (isPlatformBrowser(this.platformId) && this.currentCustomerId()) {
        this.refreshData();
      }
    });
  }

  refreshData() {
    const cid = this.currentCustomerId();
    
    this.http.get<BankAccount[]>(`/api/accounts?customerId=${cid}`).subscribe(data => this.accounts.set(data));
    this.http.get<BankCard[]>(`/api/cards?customerId=${cid}`).subscribe(data => this.cards.set(data));
    this.http.get<Beneficiary[]>(`/api/beneficiaries?customerId=${cid}`).subscribe(data => this.beneficiaries.set(data));
    this.http.get<Transaction[]>(`/api/transactions?customerId=${cid}`).pipe(
      map(txs => txs.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()))
    ).subscribe(data => this.transactions.set(data));
    
    // Fallback for missing fields in db.json for richer UI
    this.http.get<any[]>(`/api/loans?customerId=${cid}`).pipe(
      map(loans => loans.map(l => ({
        ...l,
        interestRate: l.interestRate || l.interest || 5.5,
        loanNumber: l.loanNumber || `L-902${l.id}`,
        paidAmount: l.paidAmount || (l.amount * 0.35),
        monthlyInstallment: l.monthlyInstallment || (l.amount / l.duration) * 1.12
      })))
    ).subscribe(data => this.loans.set(data));

    this.http.get<LoanApplication[]>(`/api/loanApplications?customerId=${cid}`).subscribe(data => this.loanApplications.set(data));
    this.http.get<FixedDeposit[]>(`/api/fixedDeposits?customerId=${cid}`).subscribe(data => this.fixedDeposits.set(data));
    this.http.get<Investment[]>(`/api/investments?customerId=${cid}`).pipe(
      map(invs => invs.map(i => ({ ...i, returns: i.returns || (i as any).growth || 0 })))
    ).subscribe(data => this.investments.set(data));
    this.http.get<Notification[]>(`/api/notifications?customerId=${cid}`).subscribe(data => this.notifications.set(data));
  }

  applyForLoan(application: Omit<LoanApplication, 'id'>) {
    return this.http.post<LoanApplication>('/api/loanApplications', application).pipe(
      tap(() => this.refreshData())
    );
  }

  // Operations
  transferMoney(fromAccountId: string, toBeneficiaryId: string, amount: number, description: string): Observable<any> {
    const acc = this.accounts().find(a => a.id === fromAccountId);
    if (!acc || acc.balance < amount) return of(null);

    const newTx: Partial<Transaction> = {
      customerId: this.currentCustomerId(),
      type: 'transfer',
      amount: amount,
      status: 'completed',
      date: new Date().toISOString(),
      description: description || 'Bank Transfer',
      category: 'General'
    };

    return this.http.post<Transaction>('/api/transactions', newTx).pipe(
      switchMap(() => {
        const updatedBalance = acc.balance - amount;
        return this.http.patch(`/api/accounts/${fromAccountId}`, { balance: updatedBalance });
      }),
      tap(() => this.refreshData())
    );
  }

  toggleCardStatus(cardId: string, currentStatus: string) {
    const newStatus = currentStatus === 'active' ? 'blocked' : 'active';
    return this.http.patch(`/api/cards/${cardId}`, { status: newStatus }).pipe(
      tap(() => this.refreshData())
    );
  }

  addBeneficiary(beneficiary: Omit<Beneficiary, 'id' | 'customerId'>) {
    const newBen = { ...beneficiary, customerId: this.currentCustomerId() };
    return this.http.post<Beneficiary>('/api/beneficiaries', newBen).pipe(
      tap(() => this.refreshData())
    );
  }

  markNotificationAsRead(notificationId: string) {
    return this.http.patch(`/api/notifications/${notificationId}`, { read: true }).pipe(
      tap(() => this.refreshData())
    );
  }
}
