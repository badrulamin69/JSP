import { Component, inject, computed, AfterViewInit, ElementRef, viewChild, PLATFORM_ID } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BankingCustomerService } from './banking-customer.service';
import { Chart, registerables } from 'chart.js';

@Component({
  selector: 'app-customer-dashboard',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-6 lg:space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-700">
      
      <!-- Top Banner Section -->
      <div class="grid grid-cols-1 xl:grid-cols-3 gap-6 lg:gap-10">
         <div class="xl:col-span-2 bg-slate-900 rounded-[2.5rem] p-8 lg:p-12 text-white relative overflow-hidden group shadow-2xl">
            <div class="absolute top-0 right-0 w-1/3 h-full bg-linear-to-l from-emerald-500/20 to-transparent"></div>
            <div class="absolute -bottom-24 -left-24 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl group-hover:scale-110 transition-transform duration-1000"></div>
            
            <div class="relative z-10">
               <div class="flex items-center gap-3 mb-8">
                  <span class="px-3 py-1 bg-white/10 rounded-full text-[10px] font-bold tracking-widest uppercase text-emerald-400 border border-emerald-500/20">System Online</span>
                  <span class="text-[10px] text-white/40 font-medium uppercase tracking-widest">Last Login: Just now</span>
               </div>
               
               <h2 class="text-3xl lg:text-5xl font-bold tracking-tight mb-4">Hello, Jane Cooper</h2>
               <p class="text-slate-400 text-sm lg:text-base max-w-md font-light leading-relaxed">Your financial health is looking strong today. We've detected a <span class="text-emerald-400 font-bold">2.4% growth</span> in your investments over the last 30 days.</p>
               
               <div class="grid grid-cols-2 md:grid-cols-3 gap-8 mt-12 pt-8 border-t border-white/5">
                  <div>
                    <p class="text-[10px] font-bold text-white/30 uppercase tracking-widest mb-1">Total Assets</p>
                    <p class="text-2xl font-bold font-mono">{{ customerService.totalBalance() | currency:'USD' }}</p>
                  </div>
                  <div>
                    <p class="text-[10px] font-bold text-white/30 uppercase tracking-widest mb-1">Savings Rate</p>
                    <p class="text-2xl font-bold font-mono text-emerald-400">18.5%</p>
                  </div>
                  <div class="hidden md:block">
                    <p class="text-[10px] font-bold text-white/30 uppercase tracking-widest mb-1">Credit Score</p>
                    <p class="text-2xl font-bold font-mono">785 <span class="text-[10px] text-emerald-400">↑</span></p>
                  </div>
               </div>
            </div>
         </div>

         <!-- Quick Action Panel -->
         <div class="bg-white rounded-[2.5rem] p-8 border border-slate-100 shadow-sm flex flex-col">
            <h4 class="text-sm font-bold text-slate-900 mb-6 uppercase tracking-widest">Quick Actions</h4>
            <div class="grid grid-cols-2 gap-4 flex-1">
               <button class="flex flex-col items-center justify-center gap-3 p-4 bg-slate-50 border border-slate-100 rounded-3xl hover:bg-emerald-600 hover:text-white hover:shadow-lg hover:shadow-emerald-600/20 transition-all group">
                  <div class="w-10 h-10 bg-white shadow-sm rounded-xl flex items-center justify-center group-hover:bg-emerald-500/20">
                    <mat-icon class="text-slate-600 group-hover:text-white">send</mat-icon>
                  </div>
                  <span class="text-[10px] font-bold uppercase tracking-widest">Transfer</span>
               </button>
               <button class="flex flex-col items-center justify-center gap-3 p-4 bg-slate-50 border border-slate-100 rounded-3xl hover:bg-slate-900 hover:text-white hover:shadow-lg transition-all group">
                  <div class="w-10 h-10 bg-white shadow-sm rounded-xl flex items-center justify-center group-hover:bg-white/10">
                    <mat-icon class="text-slate-600 group-hover:text-white">receipt_long</mat-icon>
                  </div>
                  <span class="text-[10px] font-bold uppercase tracking-widest">Bill Pay</span>
               </button>
               <button class="flex flex-col items-center justify-center gap-3 p-4 bg-slate-50 border border-slate-100 rounded-3xl hover:bg-slate-900 hover:text-white hover:shadow-lg transition-all group">
                  <div class="w-10 h-10 bg-white shadow-sm rounded-xl flex items-center justify-center group-hover:bg-white/10">
                    <mat-icon class="text-slate-600 group-hover:text-white">qr_code_scanner</mat-icon>
                  </div>
                  <span class="text-[10px] font-bold uppercase tracking-widest">Scan QR</span>
               </button>
               <button class="flex flex-col items-center justify-center gap-3 p-4 bg-slate-50 border border-slate-100 rounded-3xl hover:bg-slate-900 hover:text-white hover:shadow-lg transition-all group">
                  <div class="w-10 h-10 bg-white shadow-sm rounded-xl flex items-center justify-center group-hover:bg-white/10">
                    <mat-icon class="text-slate-600 group-hover:text-white">add_card</mat-icon>
                  </div>
                  <span class="text-[10px] font-bold uppercase tracking-widest">Add Card</span>
               </button>
            </div>
         </div>
      </div>

      <!-- Analysis Section -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-10">
         <div class="bg-white rounded-[2.5rem] p-8 lg:p-10 border border-slate-100 shadow-sm">
            <div class="flex items-center justify-between mb-8">
               <h4 class="text-sm font-bold text-slate-900 uppercase tracking-widest">Spending Analytics</h4>
               <select class="bg-slate-50 border border-slate-100 rounded-lg text-[10px] font-bold px-3 py-1 outline-none">
                  <option>Last 30 Days</option>
                  <option>Last 6 Months</option>
               </select>
            </div>
            <div class="h-64 mt-4">
               <canvas #spendingChart></canvas>
            </div>
         </div>
         
         <div class="bg-white rounded-[2.5rem] p-8 lg:p-10 border border-slate-100 shadow-sm">
            <h4 class="text-sm font-bold text-slate-900 mb-8 uppercase tracking-widest">Active Accounts</h4>
            <div class="space-y-4">
               @for (acc of customerService.accounts(); track acc.id) {
                 <div class="group flex items-center gap-4 p-5 rounded-2xl bg-slate-50 hover:bg-slate-900 hover:text-white border border-slate-100 transition-all duration-300">
                    <div class="w-12 h-12 bg-white rounded-xl flex items-center justify-center shadow-sm group-hover:bg-white/10">
                       <mat-icon [class]="acc.type === 'Savings' ? 'text-blue-600' : 'text-emerald-600'">account_balance_wallet</mat-icon>
                    </div>
                    <div class="flex-1">
                       <p class="text-xs font-bold">{{ acc.type }} Account</p>
                       <p class="text-[10px] text-slate-400 font-mono">{{ acc.accountNumber }}</p>
                    </div>
                    <div class="text-right">
                       <p class="text-sm font-bold font-mono">{{ acc.balance | currency:'USD' }}</p>
                       <span class="text-[8px] font-bold uppercase tracking-widest text-emerald-500">Active</span>
                    </div>
                 </div>
               }
               <button class="w-full py-4 border-2 border-dashed border-slate-200 rounded-2xl text-[10px] font-bold text-slate-400 uppercase tracking-widest hover:border-emerald-500 hover:text-emerald-600 transition-all flex items-center justify-center gap-2">
                 <mat-icon class="text-sm">add_circle_outline</mat-icon>
                 Open New Account
               </button>
            </div>
         </div>
      </div>

      <!-- Transactions and Cards -->
      <div class="grid grid-cols-1 xl:grid-cols-3 gap-6 lg:gap-10">
         <div class="xl:col-span-2 bg-white rounded-[2.5rem] p-8 lg:p-10 border border-slate-100 shadow-sm">
            <div class="flex items-center justify-between mb-8">
               <h4 class="text-sm font-bold text-slate-900 uppercase tracking-widest">Recent Activity</h4>
               <button class="text-[10px] font-bold text-emerald-600 hover:underline">View Statement</button>
            </div>
            <div class="space-y-0.5">
               @for (tx of recentTransactions(); track tx.id) {
                 <div class="flex items-center gap-4 p-4 rounded-xl hover:bg-slate-50 transition-all">
                    <div [class]="'w-10 h-10 rounded-full flex items-center justify-center ' + (tx.type === 'deposit' ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600')">
                       <mat-icon class="text-lg">{{ tx.type === 'deposit' ? 'add' : 'remove' }}</mat-icon>
                    </div>
                    <div class="flex-1">
                       <p class="text-xs font-bold text-slate-900">{{ tx.description }}</p>
                       <p class="text-[10px] text-slate-400 capitalize">{{ tx.category }} • {{ tx.date | date:'shortTime' }}</p>
                    </div>
                    <div class="text-right">
                       <p [class]="'text-sm font-bold font-mono ' + (tx.type === 'deposit' ? 'text-emerald-600' : 'text-slate-900')">
                         {{ tx.type === 'deposit' ? '+' : '-' }}{{ tx.amount | currency:'USD' }}
                       </p>
                       <p class="text-[9px] text-slate-400 font-bold uppercase">{{ tx.status }}</p>
                    </div>
                 </div>
               }
            </div>
         </div>

         <div class="space-y-6">
            <div class="bg-linear-to-tr from-emerald-600 to-teal-500 rounded-[2.5rem] p-8 text-white shadow-xl relative overflow-hidden h-64">
               <div class="relative z-10 flex flex-col justify-between h-full">
                  <div class="flex justify-between items-start">
                    <mat-icon class="text-3xl opacity-50">contactless</mat-icon>
                    <span class="text-[10px] font-bold uppercase tracking-widest border border-white/20 rounded-lg px-2 py-1">Visa Infinite</span>
                  </div>
                  <div>
                    <p class="text-[10px] font-bold opacity-40 uppercase tracking-widest mb-1">Card Number</p>
                    <p class="text-xl font-mono tracking-widest">**** **** **** 4455</p>
                  </div>
                  <div class="flex justify-between items-end">
                    <div>
                      <p class="text-[9px] font-bold opacity-40 uppercase tracking-widest mb-0.5">Card Holder</p>
                      <p class="text-xs font-bold">JANE COOPER</p>
                    </div>
                    <div class="text-right">
                       <p class="text-[9px] font-bold opacity-40 uppercase tracking-widest mb-0.5">Expires</p>
                       <p class="text-xs font-bold">12/28</p>
                    </div>
                  </div>
               </div>
               <div class="absolute -top-20 -right-20 w-60 h-60 bg-white/10 rounded-full blur-3xl"></div>
            </div>

            <div class="bg-white rounded-[2.5rem] p-8 border border-slate-100 shadow-sm">
               <h4 class="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-6">Account Limits</h4>
               <div class="space-y-6">
                  <div>
                    <div class="flex justify-between text-[10px] font-bold mb-2">
                       <span class="text-slate-900">Daily Transfer</span>
                       <span class="text-slate-400">$12,500 / $50,000</span>
                    </div>
                    <div class="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                       <div class="h-full bg-emerald-500 w-1/4 rounded-full"></div>
                    </div>
                  </div>
                  <div>
                    <div class="flex justify-between text-[10px] font-bold mb-2">
                       <span class="text-slate-900">ATM Withdrawal</span>
                       <span class="text-slate-400">$500 / $5,000</span>
                    </div>
                    <div class="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                       <div class="h-full bg-blue-500 w-[10%] rounded-full"></div>
                    </div>
                  </div>
               </div>
            </div>
         </div>
      </div>

    </div>
  `
})
export class CustomerDashboard implements AfterViewInit {
  customerService = inject(BankingCustomerService);
  platformId = inject(PLATFORM_ID);
  
  spendingChart = viewChild<ElementRef>('spendingChart');
  private static chartRegistered = false;

  recentTransactions = computed(() => {
    return this.customerService.transactions().slice(0, 5);
  });

  ngAfterViewInit() {
    if (isPlatformBrowser(this.platformId)) {
      this.initChart();
    }
  }

  private initChart() {
    if (!CustomerDashboard.chartRegistered) {
      Chart.register(...registerables);
      CustomerDashboard.chartRegistered = true;
    }

    const canvas = this.spendingChart()?.nativeElement;
    if (!canvas) return;

    new Chart(canvas, {
      type: 'line',
      data: {
        labels: ['May 01', 'May 03', 'May 05', 'May 07', 'May 09', 'May 11', 'May 12'],
        datasets: [{
          label: 'Spending',
          data: [120, 450, 300, 800, 200, 500, 350],
          borderColor: '#10b981',
          backgroundColor: 'rgba(16, 185, 129, 0.1)',
          fill: true,
          tension: 0.4,
          borderWidth: 3,
          pointRadius: 0,
          pointHoverRadius: 6,
          pointHoverBackgroundColor: '#10b981',
          pointHoverBorderColor: '#fff',
          pointHoverBorderWidth: 3,
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            mode: 'index',
            intersect: false,
            backgroundColor: '#0f172a',
            titleFont: { size: 10 },
            bodyFont: { size: 12, weight: 'bold' },
            padding: 12,
            cornerRadius: 12,
            displayColors: false
          }
        },
        scales: {
          x: {
            grid: { display: false },
            ticks: { font: { size: 9 }, color: '#94a3b8' }
          },
          y: {
            grid: { color: '#f1f5f9' },
            border: { display: false },
            ticks: { font: { size: 9 }, color: '#94a3b8', callback: (value) => '$' + value }
          }
        }
      }
    });
  }
}
