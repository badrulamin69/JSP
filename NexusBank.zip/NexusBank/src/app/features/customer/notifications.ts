import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-customer-notifications',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-10 animate-in fade-in slide-in-from-right-4 duration-500 pb-20">
      
      <!-- Page Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div>
           <h2 class="text-3xl font-bold text-slate-900 tracking-tight">Signal Hub</h2>
           <p class="text-xs text-slate-500 mt-1 uppercase tracking-widest font-bold">Real-time alerts and critical updates from the Smart Mesh network</p>
        </div>
        <div class="flex gap-3">
           <button class="px-6 py-3 bg-white text-slate-600 rounded-2xl text-[10px] font-bold uppercase tracking-widest border border-slate-100 shadow-sm hover:bg-slate-50 transition-all">Clear Hub</button>
           <button class="px-6 py-3 bg-slate-900 text-white rounded-2xl text-[10px] font-bold uppercase tracking-widest shadow-lg shadow-slate-900/10 hover:bg-slate-800 transition-all flex items-center gap-2">
              <mat-icon class="text-lg">settings</mat-icon>
              Signal Prefs
           </button>
        </div>
      </div>

      <div class="max-w-4xl mx-auto space-y-6">
         @for (note of notifications; track note.id) {
            <div [class]="'bg-white p-8 rounded-[2.5rem] border transition-all hover:shadow-md group relative overflow-hidden flex gap-8 ' + (note.unread ? 'border-emerald-500 shadow-sm' : 'border-slate-100 shadow-xs')">
               @if (note.unread) {
                  <div class="absolute left-0 top-0 bottom-0 w-1.5 bg-emerald-500"></div>
               }
               
               <div [class]="'w-16 h-16 rounded-2xl flex items-center justify-center shrink-0 border transition-all ' + (note.type === 'Alert' ? 'bg-rose-50 text-rose-500 border-rose-50' : 'bg-slate-50 text-slate-400 border-slate-50')">
                  <mat-icon>{{ note.type === 'Alert' ? 'warning' : note.type === 'Transfer' ? 'sync_alt' : 'info' }}</mat-icon>
               </div>

               <div class="flex-1 space-y-2">
                  <div class="flex justify-between items-start">
                     <p class="text-[10px] font-bold uppercase tracking-widest text-slate-400 italic">Signal Type: {{ note.type }} Hub</p>
                     <span class="text-[10px] text-slate-400 font-bold uppercase tracking-widest">{{ note.time }}</span>
                  </div>
                  <h4 class="text-lg font-bold text-slate-900 tracking-tight leading-tight">{{ note.title }}</h4>
                  <p class="text-sm text-slate-500 font-light leading-relaxed">{{ note.message }}</p>
                  
                  <div class="pt-6 flex gap-3">
                     <button class="px-5 py-2 bg-slate-900 text-white rounded-xl text-[9px] font-bold uppercase tracking-widest hover:bg-slate-800 transition-all">View Action</button>
                     <button class="px-5 py-2 bg-slate-50 text-slate-500 border border-slate-100 rounded-xl text-[9px] font-bold uppercase tracking-widest hover:bg-white transition-all">Dismiss Signal</button>
                  </div>
               </div>
            </div>
         }

         @if (notifications.length === 0) {
            <div class="py-20 text-center bg-slate-50/50 rounded-[3rem] border-2 border-dashed border-slate-200">
               <mat-icon class="text-6xl text-slate-200 mb-4">notifications_off</mat-icon>
               <p class="text-sm font-bold text-slate-400 uppercase tracking-widest italic">Signal Hub is currently silent</p>
            </div>
         }
      </div>

      <!-- Signal Analytics -->
      <div class="bg-indigo-900 rounded-[3rem] p-10 lg:p-14 text-white relative overflow-hidden group shadow-2xl mt-10">
         <div class="absolute -right-20 -bottom-20 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl transform group-hover:scale-125 transition-transform duration-1000"></div>
         <div class="relative z-10 flex flex-col md:flex-row justify-between gap-10 items-center">
            <div class="flex-1">
               <p class="text-emerald-400 text-[10px] font-bold uppercase tracking-widest mb-4 italic leading-tight">Smart Mesh Health Check</p>
               <h3 class="text-3xl font-bold tracking-tight leading-tight mb-6 uppercase tracking-widest italic">All systems Operational across 12 zones.</h3>
               <p class="text-sm text-white/50 font-light leading-relaxed max-w-lg scroll-m-20 uppercase tracking-widest">You have <span class="text-white font-bold">0 critical security alerts</span> pending. Your mesh node is fully synced with the latest Smart Secure protocol v21.0.4.</p>
            </div>
            <div class="grid grid-cols-2 gap-4">
               <div class="p-6 bg-white/5 rounded-3xl border border-white/10 text-center backdrop-blur-md">
                  <p class="text-2xl font-bold font-mono tracking-tighter">1,241</p>
                  <p class="text-[9px] font-bold text-white/40 uppercase tracking-widest mt-2">Signals Received</p>
               </div>
               <div class="p-6 bg-white/5 rounded-3xl border border-white/10 text-center backdrop-blur-md">
                  <p class="text-2xl font-bold font-mono tracking-tighter">100%</p>
                  <p class="text-[9px] font-bold text-white/40 uppercase tracking-widest mt-2">Uptime Score</p>
               </div>
            </div>
         </div>
      </div>

    </div>
  `
})
export class CustomerNotifications {
  notifications = [
    { id: 1, type: 'Alert', title: 'Suspicious Mesh Entry Attempt', message: 'An unauthorized node attempted to access your Hub Profile from London, UK. Security protocols have blocked this entry.', time: '2 mins ago', unread: true },
    { id: 2, type: 'Transfer', title: 'Inbound Mesh Settlement', message: 'Institutional settlement of $12,400.00 from GLOBAL_TRUST_HUB has been credited to your Primary Asset account.', time: '1 hour ago', unread: true },
    { id: 3, type: 'Info', title: 'Titanium Card Mesh Update', message: 'Your hardware card firmware has been updated to Smart v21.4 for enhanced contactless security in Zone 4.', time: 'Yesterday', unread: false },
    { id: 4, type: 'Info', title: 'Consolidated Statement Ready', message: 'Your monthly mesh settlement ledger for April 2024 is now available in the E-Statements hub.', time: '2 days ago', unread: false }
  ];
}
