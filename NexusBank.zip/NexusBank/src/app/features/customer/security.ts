import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-customer-security',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-10 animate-in fade-in slide-in-from-right-4 duration-500 pb-20">
      
      <!-- Page Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div>
           <h2 class="text-3xl font-bold text-slate-900 tracking-tight">Security Citadel</h2>
           <p class="text-xs text-slate-500 mt-1 uppercase tracking-widest font-bold">Hardening your financial node against global perimeter threats</p>
        </div>
        <button class="px-6 py-3 bg-rose-600 text-white rounded-2xl text-[10px] font-bold uppercase tracking-widest shadow-lg shadow-rose-600/20 hover:bg-rose-700 transition-all flex items-center gap-2">
           <mat-icon class="text-lg">lock_reset</mat-icon>
           Citadel Lockdown
        </button>
      </div>

      <!-- Security Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-10">
         <div class="lg:col-span-2 space-y-10">
            <div class="bg-white p-10 lg:p-14 rounded-[3.5rem] border border-slate-100 shadow-sm space-y-12">
               <div class="flex justify-between items-center">
                  <h3 class="text-xl font-bold text-slate-900">Defense Protocols</h3>
                  <div class="flex items-center gap-2">
                     <div class="w-2 h-2 bg-emerald-500 rounded-full animate-pulse shadow-[0_0_8px_#10b981]"></div>
                     <span class="text-[10px] font-bold text-emerald-600 uppercase tracking-widest">Shields Active</span>
                  </div>
               </div>

               <div class="space-y-8">
                  @for (protocol of protocols; track protocol.id) {
                     <div class="flex items-center justify-between p-6 bg-slate-50 rounded-3xl border border-slate-100 group hover:border-slate-900 transition-all">
                        <div class="flex items-center gap-6">
                           <div class="w-14 h-14 bg-white rounded-2xl flex items-center justify-center text-slate-400 group-hover:bg-slate-900 group-hover:text-white transition-all shadow-sm">
                              <mat-icon>{{ protocol.icon }}</mat-icon>
                           </div>
                           <div>
                              <h4 class="text-sm font-bold text-slate-900">{{ protocol.name }}</h4>
                              <p class="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">{{ protocol.desc }}</p>
                           </div>
                        </div>
                        <div [class]="'w-12 h-6 rounded-full relative p-1 cursor-pointer transition-colors ' + (protocol.active ? 'bg-emerald-500' : 'bg-slate-200')">
                           <div [class]="'w-4 h-4 bg-white rounded-full transition-all ' + (protocol.active ? 'ml-6' : 'ml-0')"></div>
                        </div>
                     </div>
                  }
               </div>
            </div>

            <div class="bg-slate-900 rounded-[3.5rem] p-10 lg:p-14 text-white relative overflow-hidden group shadow-2xl">
               <div class="absolute -right-20 -bottom-20 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl transform group-hover:scale-125 transition-transform duration-1000"></div>
               <div class="relative z-10 flex flex-col md:flex-row justify-between gap-10 items-center">
                  <div class="space-y-6 flex-1">
                     <h3 class="text-3xl font-bold tracking-tight mb-2 uppercase tracking-widest italic">Biometric Key-Hub</h3>
                     <p class="text-sm text-white/50 font-light leading-relaxed uppercase tracking-widest">Enable hardware-level biometric mesh signatures for all transfers over $50,000 to prevent shadow operations.</p>
                     <button class="px-8 py-3 bg-white text-slate-900 rounded-2xl text-[10px] font-bold uppercase tracking-widest hover:scale-105 transition-all shadow-xl shadow-white/10">Register Secure Key</button>
                  </div>
                  <div class="w-40 h-40 bg-white/5 rounded-full border-4 border-white/10 flex items-center justify-center backdrop-blur-md">
                     <mat-icon class="text-6xl text-emerald-500 animate-pulse">fingerprint</mat-icon>
                  </div>
               </div>
            </div>
         </div>

         <div class="space-y-10">
            <h3 class="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4 px-2">Citadel Logs</h3>
            <div class="bg-white rounded-[3rem] border border-slate-100 shadow-sm p-8 space-y-6">
               @for (log of securityLogs; track log.id) {
                  <div class="flex items-start gap-4 p-4 hover:bg-slate-50 rounded-2xl transition-all border border-transparent hover:border-slate-100 group">
                     <div [class]="'w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ' + (log.type === 'Alert' ? 'bg-rose-50 text-rose-500' : 'bg-emerald-50 text-emerald-500')">
                        <mat-icon class="text-sm">{{ log.type === 'Alert' ? 'warning' : 'info' }}</mat-icon>
                     </div>
                     <div>
                        <p class="text-xs font-bold text-slate-900">{{ log.event }}</p>
                        <p class="text-[9px] text-slate-400 font-bold uppercase mt-1 tracking-widest">{{ log.time }} • {{ log.location }}</p>
                     </div>
                  </div>
               }
               <button class="w-full py-3 bg-slate-50 text-slate-400 rounded-xl text-[9px] font-bold uppercase tracking-widest hover:bg-slate-900 hover:text-white transition-all">Full Security Audit</button>
            </div>

            <div class="bg-rose-900/10 p-8 rounded-[3rem] border border-rose-100 relative overflow-hidden group">
               <div class="absolute -right-10 -top-10 w-32 h-32 bg-rose-500/5 rounded-full blur-2xl"></div>
               <div class="relative z-10 flex items-center gap-6">
                  <div class="w-14 h-14 bg-rose-100 text-rose-600 rounded-2xl flex items-center justify-center shrink-0 border border-rose-200">
                     <mat-icon>gpp_maybe</mat-icon>
                  </div>
                  <div>
                     <h4 class="text-xs font-bold text-rose-900 mb-1 leading-tight uppercase tracking-widest">Privacy Zone Check</h4>
                     <p class="text-[9px] text-rose-600/70 font-medium leading-relaxed uppercase tracking-widest">One identity hub element requires immediate verification to maintain Tier-1 status.</p>
                  </div>
               </div>
            </div>
         </div>
      </div>

    </div>
  `
})
export class CustomerSecurity {
  protocols = [
    { id: 1, name: '2FA Auth Hub', desc: 'Secure push verification node', icon: 'phonelink_setup', active: true },
    { id: 2, name: 'Mesh Proxy Protection', desc: 'Hide origin IP from mesh network', icon: 'vpn_lock', active: false },
    { id: 3, name: 'Auto-Lockdown Hub', desc: 'Lock account after 10m idle', icon: 'timer', active: true },
    { id: 4, name: 'Hardware Key Auth', desc: 'Physical FIDO2 mesh key required', icon: 'key', active: false }
  ];

  securityLogs = [
    { id: 1, type: 'Alert', event: 'Unrecognized Node Entry', time: '14:22 PM', location: 'London, UK' },
    { id: 2, type: 'Info', event: 'Mesh Keys Rotated', time: 'Yesterday', location: 'System Hub' },
    { id: 3, type: 'Info', event: 'Titanium Card Auth', time: '3 Days Ago', location: 'Internal Hub' },
    { id: 4, type: 'Alert', event: 'API Mesh Secret Reset', time: 'Last Week', location: 'Admin Zone' }
  ];
}
