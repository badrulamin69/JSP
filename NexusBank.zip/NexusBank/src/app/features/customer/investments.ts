import { Component, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BankingCustomerService } from './banking-customer.service';

@Component({
  selector: 'app-customer-investments',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-10 animate-in fade-in slide-in-from-right-4 duration-500">
      
      <!-- Page Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div>
           <h2 class="text-3xl font-bold text-slate-900 tracking-tight">Investment Hub</h2>
           <p class="text-xs text-slate-500 mt-1 uppercase tracking-widest font-bold">Monitor your equity, crypto and traditional portfolio</p>
        </div>
        <div class="flex gap-3">
           <button class="px-6 py-3 bg-white text-slate-600 rounded-2xl text-[10px] font-bold uppercase tracking-widest border border-slate-100 shadow-sm hover:bg-slate-50 transition-all">Buy Assets</button>
           <button class="px-6 py-3 bg-slate-900 text-white rounded-2xl text-[10px] font-bold uppercase tracking-widest shadow-lg shadow-slate-900/10 hover:bg-slate-800 transition-all">Portfolio Analysis</button>
        </div>
      </div>

      <!-- Market Ticker -->
      <div class="bg-slate-900 rounded-3xl p-6 flex overflow-x-auto gap-10 no-scrollbar items-center border border-white/5 shadow-2xl">
         @for (ticker of tickers; track ticker.name) {
            <div class="flex items-center gap-4 shrink-0 px-4 border-r border-white/5 last:border-0 h-full py-2">
               <div [class]="'w-10 h-10 rounded-xl flex items-center justify-center text-xs font-bold ' + (ticker.up ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400')">
                  {{ ticker.symbol }}
               </div>
               <div>
                  <p class="text-white text-xs font-bold">{{ ticker.price | currency:'USD' }}</p>
                  <p [class]="'text-[9px] font-bold uppercase tracking-widest ' + (ticker.up ? 'text-emerald-500' : 'text-rose-500')">
                     {{ ticker.up ? '▲' : '▼' }} {{ ticker.change }}%
                  </p>
               </div>
            </div>
         }
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-3 gap-10">
         <div class="lg:col-span-2 space-y-8">
            <h3 class="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4">Portfolio Holdings</h3>
            <div class="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm overflow-hidden min-h-[400px]">
               <table class="w-full text-left">
                  <thead>
                     <tr class="bg-slate-50/30">
                        <th class="px-8 py-6 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Asset Category</th>
                        <th class="px-8 py-6 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Growth (1Y)</th>
                        <th class="px-8 py-6 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-right">Value</th>
                        <th class="px-8 py-6 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-center">Trend</th>
                     </tr>
                  </thead>
                  <tbody class="divide-y divide-slate-50">
                     @for (inv of customerService.investments(); track inv.id) {
                        <tr class="hover:bg-slate-50/50 transition-all group cursor-pointer">
                           <td class="px-8 py-7">
                              <div class="flex items-center gap-5">
                                 <div [class]="'w-14 h-14 rounded-2xl flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform ' + (inv.type === 'Stocks' ? 'bg-blue-50 text-blue-600' : 'bg-emerald-50 text-emerald-600')">
                                    <mat-icon>{{ inv.type === 'Stocks' ? 'monitoring' : 'currency_bitcoin' }}</mat-icon>
                                 </div>
                                 <div>
                                    <p class="text-sm font-bold text-slate-900">{{ inv.name }}</p>
                                    <p class="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">{{ inv.type }} HUB</p>
                                 </div>
                              </div>
                           </td>
                           <td class="px-8 py-7">
                              <div class="flex items-center gap-3">
                                 <div class="flex-1 h-1.5 bg-slate-100 rounded-full overflow-hidden w-20">
                                    <div class="h-full bg-emerald-500" [style.width]="inv.returns + '%'"></div>
                                 </div>
                                 <span class="text-emerald-600 text-[10px] font-bold font-mono tracking-tighter">+{{ inv.returns }}%</span>
                              </div>
                           </td>
                           <td class="px-8 py-7 text-right">
                              <p class="text-lg font-bold font-mono text-slate-900 tracking-tighter">{{ inv.amount | currency:'USD' }}</p>
                              <p class="text-[10px] text-emerald-500 font-bold uppercase tracking-widest mt-1 italic">UNREALIZED P/L info</p>
                           </td>
                           <td class="px-8 py-7 text-center">
                              <mat-icon class="text-emerald-500 animate-bounce">trending_up</mat-icon>
                           </td>
                        </tr>
                     }
                  </tbody>
               </table>
            </div>
         </div>

         <div class="space-y-10">
            <h3 class="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4">Investment Metrics</h3>
            <div class="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm relative overflow-hidden group">
               <div class="absolute -right-20 top-0 w-40 h-40 bg-emerald-500/5 rounded-full blur-3xl"></div>
               <div class="space-y-10">
                  <div class="text-center">
                     <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">Total Managed Wealth</p>
                     <p class="text-4xl font-bold font-mono text-slate-900 leading-none tracking-tighter">{{ totalInvestments() | currency:'USD' }}</p>
                  </div>

                  <div class="space-y-6">
                     <div>
                        <div class="flex justify-between text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-2">
                           <span>Technology Portfolio</span>
                           <span class="text-slate-900">45%</span>
                        </div>
                        <div class="h-1.5 bg-slate-50 rounded-full overflow-hidden">
                           <div class="h-full bg-slate-900 w-[45%] rounded-full shadow-[0_0_10px_rgba(0,0,0,0.1)]"></div>
                        </div>
                     </div>
                     <div>
                        <div class="flex justify-between text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-2">
                           <span>Emerald ESG Assets</span>
                           <span class="text-emerald-600">35%</span>
                        </div>
                        <div class="h-1.5 bg-slate-50 rounded-full overflow-hidden">
                           <div class="h-full bg-emerald-500 w-[35%] rounded-full shadow-[0_0_10px_rgba(16,185,129,0.2)]"></div>
                        </div>
                     </div>
                     <div>
                        <div class="flex justify-between text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-2">
                           <span>Liquid Reserves</span>
                           <span class="text-blue-500">20%</span>
                        </div>
                        <div class="h-1.5 bg-slate-50 rounded-full overflow-hidden">
                           <div class="h-full bg-blue-500 w-[20%] rounded-full shadow-[0_0_10px_rgba(59,130,246,0.2)]"></div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>

            <div class="bg-amber-900 p-8 rounded-[2.5rem] text-white shadow-xl flex items-center gap-6 group cursor-pointer hover:scale-[1.02] transition-all">
               <div class="w-14 h-14 bg-white/10 rounded-2xl flex items-center justify-center text-amber-400 shrink-0 border border-white/5">
                  <mat-icon class="text-2xl">diamond</mat-icon>
               </div>
               <div>
                  <p class="text-[10px] font-bold text-amber-500/80 uppercase tracking-widest mb-1 italic">Premium Advisory</p>
                  <p class="text-xs font-bold leading-relaxed">Upgrade to <span class="text-amber-400">SMART ELITE</span> for high-yield private equity access.</p>
               </div>
            </div>
         </div>
      </div>

    </div>
  `
})
export class CustomerInvestments {
  customerService = inject(BankingCustomerService);

  totalInvestments = computed(() => {
    return this.customerService.investments().reduce((sum, inv) => sum + inv.amount, 0);
  });

  tickers = [
    { name: 'S&P 500', symbol: 'SPX', price: 5240.22, change: 1.2, up: true },
    { name: 'Bitcoin', symbol: 'BTC', price: 68422.40, change: 3.4, up: true },
    { name: 'Ethereum', symbol: 'ETH', price: 3840.12, change: 0.8, up: false },
    { name: 'NVIDIA Corp', symbol: 'NVDA', price: 924.40, change: 5.2, up: true },
    { name: 'Safe Gold', symbol: 'XAU', price: 2340.50, change: 0.2, up: false }
  ];
}
