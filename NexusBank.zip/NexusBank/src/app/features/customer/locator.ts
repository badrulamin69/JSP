import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-customer-locator',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-10 animate-in fade-in slide-in-from-right-4 duration-500">
      
      <!-- Page Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div>
           <h2 class="text-3xl font-bold text-slate-900 tracking-tight">ATM & Branch Hub</h2>
           <p class="text-xs text-slate-500 mt-1 uppercase tracking-widest font-bold">Find nearest physical access points in the global network</p>
        </div>
        <div class="flex bg-white p-1 rounded-2xl border border-slate-100 shadow-sm">
           <button class="px-6 py-2.5 bg-slate-900 text-white rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all">List View</button>
           <button class="px-6 py-2.5 text-slate-400 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all hover:bg-slate-50">Map View</button>
        </div>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-3 gap-10">
         <div class="lg:col-span-1 space-y-6">
            <h3 class="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4 px-2">Nearest to You</h3>
            <div class="space-y-4 max-h-[600px] overflow-y-auto pr-4 no-scrollbar">
               @for (loc of locations; track loc.id) {
                  <div class="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm hover:border-emerald-500 transition-all group flex gap-5 cursor-pointer">
                     <div [class]="'w-12 h-12 rounded-2xl flex items-center justify-center border shrink-0 transition-all ' + (loc.type === 'ATM' ? 'bg-blue-50 text-blue-600 border-blue-50 group-hover:bg-blue-600 group-hover:text-white' : 'bg-emerald-50 text-emerald-600 border-emerald-50 group-hover:bg-emerald-600 group-hover:text-white')">
                        <mat-icon>{{ loc.type === 'ATM' ? 'atm' : 'account_balance' }}</mat-icon>
                     </div>
                     <div class="flex-1">
                        <p class="text-[9px] font-bold uppercase tracking-widest mb-1" [class]="loc.type === 'ATM' ? 'text-blue-500' : 'text-emerald-500'">{{ loc.type }} HUB</p>
                        <h4 class="text-sm font-bold text-slate-900">{{ loc.name }}</h4>
                        <p class="text-[10px] text-slate-400 mt-1 leading-relaxed font-medium">{{ loc.address }}</p>
                        <div class="mt-4 flex items-center justify-between">
                           <span class="text-[9px] font-bold text-slate-400 uppercase tracking-widest italic">{{ loc.distance }} KM away</span>
                           <span class="px-2 py-0.5 bg-slate-50 text-emerald-600 rounded text-[8px] font-bold uppercase border border-slate-100">Open Now</span>
                        </div>
                     </div>
                  </div>
               }
            </div>
         </div>

         <div class="lg:col-span-2 relative min-h-[600px] rounded-[3rem] overflow-hidden bg-slate-100 shadow-inner border border-slate-200 group">
            <!-- Simulated Map -->
            <div class="absolute inset-0 bg-slate-100 flex items-center justify-center overflow-hidden grayscale contrast-75 brightness-95 opacity-80 group-hover:grayscale-0 transition-all duration-1000">
               <img src="https://images.unsplash.com/photo-1548345666-a57164883378?auto=format&fit=crop&q=80&w=2000" class="w-full h-full object-cover blur-xs opacity-40" alt="SIM Map">
            </div>
            
            <div class="absolute inset-0 flex items-center justify-center p-8 text-center bg-white/20 backdrop-blur-xs">
               <div class="bg-white p-12 rounded-[3.5rem] shadow-2xl border border-white/40 max-w-sm space-y-6 relative overflow-hidden group/modal">
                  <div class="absolute -right-10 -top-10 w-32 h-32 bg-emerald-50 rounded-full blur-2xl"></div>
                  <div class="w-20 h-20 bg-slate-900 text-white rounded-3xl flex items-center justify-center mx-auto mb-4 animate-bounce">
                     <mat-icon class="text-3xl">location_on</mat-icon>
                  </div>
                  <h4 class="text-xl font-bold text-slate-900 tracking-tight">Activate Geo-Location Hub</h4>
                  <p class="text-xs text-slate-500 leading-relaxed font-light uppercase tracking-wider">Please authorize Smart Secure to access your precise hardware location for verified mesh-point routing.</p>
                  <button class="w-full py-4 bg-emerald-600 text-white rounded-2xl text-[10px] font-bold uppercase tracking-widest shadow-xl shadow-emerald-600/20 hover:bg-emerald-700 transition-all">Authorize Access</button>
               </div>
            </div>

            <!-- Floating Controls -->
            <div class="absolute top-8 left-8 right-8 flex justify-between pointer-events-none">
               <div class="bg-white/80 backdrop-blur-md p-4 rounded-3xl border border-white/20 shadow-xl pointer-events-auto flex items-center gap-4">
                  <mat-icon class="text-slate-400">my_location</mat-icon>
                  <p class="text-[10px] font-bold uppercase tracking-widest text-slate-900">Current Mesh Zone: Downtown Hub 04</p>
               </div>
               <div class="flex flex-col gap-2 pointer-events-auto">
                  <button class="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-xl hover:bg-slate-900 hover:text-white transition-all"><mat-icon>add</mat-icon></button>
                  <button class="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-xl hover:bg-slate-900 hover:text-white transition-all"><mat-icon>remove</mat-icon></button>
               </div>
            </div>
         </div>
      </div>

    </div>
  `
})
export class CustomerLocator {
  locations = [
    { id: 1, type: 'Branch', name: 'Downtown Hub Prime', address: '457 Mesh St, New York, NY 10001', distance: 0.8 },
    { id: 2, type: 'ATM', name: 'Metro Plaza ATM Node', address: '900 Grid Ave, New York, NY 10012', distance: 1.2 },
    { id: 3, type: 'Branch', name: 'Eastside Secure Hub', address: '12 Node Circle, New York, NY 10022', distance: 2.1 },
    { id: 4, type: 'ATM', name: 'Grand Central Point 7', address: 'Terminal 4, Grand Central, NY', distance: 3.4 },
    { id: 5, type: 'ATM', name: 'Skyline Mall Mesh', address: 'Level 2, Skyline Mall, NY', distance: 4.8 }
  ];
}
