import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-customer-support',
  standalone: true,
  imports: [CommonModule, MatIconModule, ReactiveFormsModule],
  template: `
    <div class="space-y-10 animate-in fade-in slide-in-from-right-4 duration-500 pb-20">
      
      <!-- Page Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div>
           <h2 class="text-3xl font-bold text-slate-900 tracking-tight">Concierge & Support</h2>
           <p class="text-xs text-slate-500 mt-1 uppercase tracking-widest font-bold">Priority assistance for your digital banking ecosystem</p>
        </div>
        <button class="px-6 py-3 bg-emerald-600 text-white rounded-2xl text-[10px] font-bold uppercase tracking-widest shadow-lg shadow-emerald-600/20 hover:bg-emerald-700 transition-all flex items-center gap-2">
           <mat-icon class="text-lg">support_agent</mat-icon>
           Live Mesh Chat
        </button>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-3 gap-10">
         <div class="lg:col-span-2 space-y-8">
            <h3 class="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4 px-2">Support Threads</h3>
            
            <div class="grid gap-6">
               @for (ticket of tickets; track ticket.id) {
                  <div class="bg-white p-8 rounded-[3rem] border border-slate-100 shadow-sm hover:shadow-md transition-all group cursor-pointer relative overflow-hidden">
                     <div class="absolute -right-6 top-1/2 -translate-y-1/2 w-20 h-20 bg-slate-50 rounded-full group-hover:scale-150 transition-transform duration-700"></div>
                     
                     <div class="flex flex-col md:flex-row justify-between gap-6 relative z-10">
                        <div class="flex items-center gap-6">
                           <div [class]="'w-14 h-14 rounded-2xl flex items-center justify-center border transition-all ' + (ticket.status === 'Open' ? 'bg-amber-50 text-amber-600 border-amber-50 group-hover:bg-amber-600 group-hover:text-white' : 'bg-slate-50 text-slate-400 border-slate-50')">
                              <mat-icon>{{ ticket.category === 'Security' ? 'security' : 'help_outline' }}</mat-icon>
                           </div>
                           <div>
                              <p class="text-[9px] font-bold text-slate-400 uppercase tracking-widest mb-1 italic">Ticket #{{ ticket.id }}</p>
                              <h4 class="text-lg font-bold text-slate-900 leading-tight">{{ ticket.subject }}</h4>
                           </div>
                        </div>
                        <div class="flex items-center gap-4 text-right">
                           <div class="hidden md:block">
                              <p class="text-[9px] font-bold text-slate-400 uppercase tracking-widest mb-1 italic">Last Hub Activity</p>
                              <p class="text-xs font-bold text-slate-600 uppercase">{{ ticket.lastActivity }}</p>
                           </div>
                           <span [class]="'px-3 py-1 rounded-lg text-[10px] font-bold uppercase border ' + (ticket.status === 'Open' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-slate-50 text-slate-400 border-slate-100')">{{ ticket.status }}</span>
                        </div>
                     </div>

                     <div class="mt-8 pt-8 border-t border-slate-50 flex justify-between items-center relative z-10">
                        <div class="flex -space-x-4">
                           <img src="https://i.pravatar.cc/150?u=1" class="w-10 h-10 rounded-xl border-2 border-white grayscale hover:grayscale-0 transition-all cursor-pointer" alt="U1">
                           <img [src]="'https://i.pravatar.cc/150?u=' + ticket.id" class="w-10 h-10 rounded-xl border-2 border-white" alt="Agent">
                        </div>
                        <div class="flex gap-2">
                           <button class="px-5 py-2.5 bg-slate-900 text-white rounded-xl text-[10px] font-bold uppercase tracking-widest hover:bg-slate-800 transition-all shadow-lg shadow-slate-900/10">Enter Thread</button>
                        </div>
                     </div>
                  </div>
               }
            </div>

            <div class="bg-indigo-900 rounded-[3rem] p-10 lg:p-14 text-white relative overflow-hidden group shadow-2xl">
               <div class="absolute -right-20 -bottom-20 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl transform group-hover:scale-125 transition-transform duration-1000"></div>
               <div class="relative z-10 space-y-6">
                  <h3 class="text-2xl font-bold tracking-tight mb-4 uppercase tracking-widest italic">Personal Mesh Manager</h3>
                  <p class="text-sm text-white/60 font-light leading-relaxed max-w-lg uppercase tracking-widest">Upgrade to <span class="text-white font-bold">SMART PRIME</span> to get a dedicated relationship officer available 24/7/365 across all global zones.</p>
                  <button class="px-8 py-3 bg-white text-slate-900 rounded-2xl text-[10px] font-bold uppercase tracking-widest hover:scale-105 transition-all shadow-xl shadow-white/10">Upgrade to Prime</button>
               </div>
            </div>
         </div>

         <div class="space-y-10">
            <h3 class="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4 px-2">Open New Request</h3>
            <div class="bg-white p-8 rounded-[3rem] border border-slate-100 shadow-sm space-y-8 relative overflow-hidden group">
               <div class="absolute -left-10 -top-10 w-32 h-32 bg-slate-50 rounded-full blur-2xl group-hover:scale-150 transition-transform duration-700"></div>
               
               <form [formGroup]="ticketForm" class="space-y-6 relative z-10">
                  <div class="space-y-2">
                     <label class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Query Category</label>
                     <select formControlName="category" class="w-full h-12 px-5 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:border-emerald-500 transition-all font-bold text-xs uppercase tracking-widest">
                        <option value="General">General Inquiry</option>
                        <option value="Transaction">Transaction Hub Error</option>
                        <option value="Security">Security Lockdown</option>
                        <option value="Cards">Card Access Hub</option>
                     </select>
                  </div>
                  <div class="space-y-2">
                     <label class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Subject Heading</label>
                     <input type="text" formControlName="subject" placeholder="Concise summary..." class="w-full h-12 px-5 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:border-emerald-500 transition-all font-bold text-sm">
                  </div>
                  <div class="space-y-2">
                     <label class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Detailed Context</label>
                     <textarea formControlName="message" rows="4" placeholder="Describe your requirement in detail..." class="w-full p-5 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:border-emerald-500 transition-all font-medium text-xs no-scrollbar"></textarea>
                  </div>
                  <button (click)="submitTicket()" class="w-full h-14 bg-slate-900 text-white rounded-2xl text-[10px] font-bold uppercase tracking-widest shadow-xl shadow-slate-900/10 hover:bg-slate-800 transition-all flex items-center justify-center gap-2">
                     Finalize Submission <mat-icon>send</mat-icon>
                  </button>
               </form>
            </div>

            <div class="bg-white p-8 rounded-[3rem] border border-slate-100 shadow-sm relative overflow-hidden group">
               <h4 class="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-6">Knowledge Base Hub</h4>
               <div class="space-y-4">
                  <div class="p-4 bg-slate-50 rounded-2xl hover:bg-slate-100 transition-all cursor-pointer group/item flex justify-between items-center">
                     <span class="text-xs font-bold text-slate-900">Mesh Security Protocols</span>
                     <mat-icon class="text-slate-300 group-hover/item:text-slate-900 transition-all text-sm">arrow_forward</mat-icon>
                  </div>
                  <div class="p-4 bg-slate-50 rounded-2xl hover:bg-slate-100 transition-all cursor-pointer group/item flex justify-between items-center">
                     <span class="text-xs font-bold text-slate-900">FX Settlement Cycles</span>
                     <mat-icon class="text-slate-300 group-hover/item:text-slate-900 transition-all text-sm">arrow_forward</mat-icon>
                  </div>
                  <div class="p-4 bg-slate-50 rounded-2xl hover:bg-slate-100 transition-all cursor-pointer group/item flex justify-between items-center">
                     <span class="text-xs font-bold text-slate-900">Virtual Card Deployment</span>
                     <mat-icon class="text-slate-300 group-hover/item:text-slate-900 transition-all text-sm">arrow_forward</mat-icon>
                  </div>
               </div>
            </div>
         </div>
      </div>

    </div>
  `
})
export class CustomerSupport {
  private fb = inject(FormBuilder);

  tickets = [
    { id: 'TIC-9022', subject: 'Inconsistent Mesh Transfer #09', status: 'Open', lastActivity: '2 Hours Ago', category: 'Transaction' },
    { id: 'TIC-8841', subject: 'Security Auth Token Refresh Hub', status: 'Closed', lastActivity: '1 Day Ago', category: 'Security' },
    { id: 'TIC-8762', subject: 'Request for Infinite Card Hub', status: 'Closed', lastActivity: '3 Days Ago', category: 'General' }
  ];

  ticketForm = this.fb.group({
    category: ['General', Validators.required],
    subject: ['', Validators.required],
    message: ['', Validators.required]
  });

  submitTicket() {
    if (this.ticketForm.valid) {
      alert('Your support request has been logged in the secure mesh registry.');
      this.ticketForm.reset({ category: 'General' });
    }
  }
}
