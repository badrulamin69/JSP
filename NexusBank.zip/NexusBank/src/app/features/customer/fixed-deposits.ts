import { Component, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BankingCustomerService } from './banking-customer.service';

@Component({
  selector: 'app-customer-fixed-deposits',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-10 animate-in fade-in slide-in-from-right-4 duration-500">
      
      <!-- Page Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div>
           <h2 class="text-3xl font-bold text-slate-900 tracking-tight">Fixed Deposits</h2>
           <p class="text-xs text-slate-500 mt-1 uppercase tracking-widest font-bold">Guaranteed returns on your locked liquid capital</p>
        </div>
        <button class="px-8 py-4 bg-emerald-600 text-white rounded-2xl text-[10px] font-bold uppercase tracking-widest shadow-lg shadow-emerald-600/20 hover:bg-emerald-700 transition-all flex items-center gap-3">
           <mat-icon class="text-lg">lock</mat-icon>
           Create FD Instance
        </button>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-2 gap-10">
         @for (fd of customerService.fixedDeposits(); track fd.id) {
            <div class="bg-white rounded-[3rem] p-10 border border-slate-100 shadow-sm hover:shadow-md transition-all relative overflow-hidden group">
               <div class="absolute -top-10 -right-10 w-40 h-40 bg-slate-50 rounded-full transition-transform group-hover:scale-110 duration-1000"></div>
               
               <div class="flex justify-between items-start mb-12 relative z-10">
                  <div class="w-16 h-16 bg-slate-100 text-slate-900 rounded-2xl flex items-center justify-center border border-slate-100 group-hover:bg-slate-900 group-hover:text-white transition-all shadow-sm">
                     <mat-icon class="text-3xl">hourglass_bottom</mat-icon>
                  </div>
                  <div class="text-right">
                     <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Interest Rate</p>
                     <p class="text-2xl font-bold font-mono text-emerald-600 tracking-tighter">{{ fd.interestRate }}% P.A.</p>
                  </div>
               </div>

               <div class="space-y-2 relative z-10">
                  <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest italic">Principal Deposit</p>
                  <h3 class="text-5xl font-bold font-mono text-slate-900 tracking-tighter">{{ fd.amount | currency:'USD' }}</h3>
                  <p class="text-xs text-slate-400 font-bold uppercase tracking-widest mt-4">Smart Certificate ID: #{{ fd.id.slice(0,10) }}</p>
               </div>

               <div class="mt-12 grid grid-cols-2 gap-8 relative z-10 pt-10 border-t border-slate-50">
                  <div>
                     <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Maturity Date</p>
                     <p class="text-sm font-bold text-slate-900">{{ fd.maturityDate | date:'MMMM dd, yyyy' }}</p>
                  </div>
                  <div class="text-right">
                     <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Projected Return</p>
                     <p class="text-sm font-bold text-emerald-600 font-mono tracking-tighter">{{ (fd.amount * (1 + fd.interestRate/100)) | currency:'USD' }}</p>
                  </div>
               </div>

               <div class="mt-10 flex gap-3 relative z-10">
                  <button class="flex-1 py-4 bg-slate-50 text-slate-600 rounded-2xl text-[10px] font-bold uppercase tracking-widest hover:bg-slate-900 hover:text-white transition-all">Details</button>
                  <button class="flex-1 py-4 bg-white text-slate-400 border border-slate-100 rounded-2xl text-[10px] font-bold uppercase tracking-widest hover:border-rose-500 hover:text-rose-500 transition-all">Liquidate Early</button>
               </div>
            </div>
         } @empty {
            <div class="lg:col-span-2 py-20 bg-slate-50/50 border-2 border-dashed border-slate-200 rounded-[3rem] flex flex-col items-center justify-center text-center">
               <div class="w-20 h-20 bg-white rounded-3xl flex items-center justify-center mb-6 shadow-sm border border-slate-100">
                  <mat-icon class="text-4xl text-slate-200">savings</mat-icon>
               </div>
               <h3 class="text-lg font-bold text-slate-900">No active deposits found</h3>
               <p class="text-xs text-slate-400 font-bold uppercase tracking-widest mt-2 max-w-xs">Start building guaranteed wealth with our high-yield fixed deposit certificates.</p>
               <button class="mt-10 px-10 py-4 bg-slate-900 text-white rounded-2xl text-[10px] font-bold uppercase tracking-widest hover:scale-105 transition-all shadow-xl shadow-slate-900/10">View Offers</button>
            </div>
         }
      </div>

      <!-- Growth Comparison -->
      <div class="bg-slate-900 rounded-[3rem] p-10 lg:p-14 text-white relative overflow-hidden group shadow-2xl">
         <div class="absolute -right-20 -bottom-20 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl transform group-hover:scale-125 transition-transform duration-1000"></div>
         <div class="relative z-10 max-w-2xl">
            <h3 class="text-2xl font-bold tracking-tight mb-6 leading-tight">Secure your future with <span class="text-emerald-400">Fixed-Growth Hub</span>. Rates starting at 6.5% for all prime customers.</h3>
            <div class="flex flex-wrap gap-10 mt-12">
               <div>
                  <p class="text-[10px] font-bold text-white/40 uppercase tracking-widest mb-2">Total Locked Asset</p>
                  <p class="text-3xl font-bold font-mono">{{ totalFixedDeposits() | currency:'USD' }}</p>
               </div>
               <div>
                  <p class="text-[10px] font-bold text-white/40 uppercase tracking-widest mb-2">Certificates</p>
                  <p class="text-3xl font-bold font-mono">{{ customerService.fixedDeposits().length }} Active</p>
               </div>
            </div>
            <div class="mt-12 h-1 w-full bg-white/5 rounded-full overflow-hidden">
               <div class="h-full bg-emerald-500 w-2/3 shadow-[0_0_15px_#10b981]"></div>
            </div>
         </div>
      </div>

    </div>
  `
})
export class CustomerFixedDeposits {
  customerService = inject(BankingCustomerService);

  totalFixedDeposits = computed(() => {
    return this.customerService.fixedDeposits().reduce((sum, fd) => sum + fd.amount, 0);
  });
}
