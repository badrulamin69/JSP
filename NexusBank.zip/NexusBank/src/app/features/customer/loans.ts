import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BankingCustomerService } from './banking-customer.service';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-customer-loans',
  standalone: true,
  imports: [CommonModule, MatIconModule, ReactiveFormsModule],
  template: `
    <div class="space-y-10 animate-in fade-in slide-in-from-right-4 duration-500">
      
      <!-- Page Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div>
           <h2 class="text-3xl font-bold text-slate-900 tracking-tight">Financing & Loans</h2>
           <p class="text-xs text-slate-500 mt-1 uppercase tracking-widest font-bold">Manage your active credit and apply for growth capital</p>
        </div>
        <button (click)="showApplication.set(true)" class="px-6 py-3 bg-emerald-600 text-white rounded-2xl text-[10px] font-bold uppercase tracking-widest shadow-lg shadow-emerald-600/20 hover:bg-emerald-700 transition-all flex items-center gap-2">
           <mat-icon class="text-lg">add_task</mat-icon>
           New Loan Application
        </button>
      </div>

      @if (showApplication()) {
         <!-- Application Form Modal-like -->
         <div class="bg-white rounded-[3rem] border border-slate-100 shadow-xl overflow-hidden animate-in zoom-in-95 duration-300">
            <div class="p-8 lg:p-12">
               <div class="flex justify-between items-center mb-10">
                  <h3 class="text-xl font-bold text-slate-900">Configure Loan Proposal</h3>
                  <button (click)="showApplication.set(false)" class="p-2 hover:bg-slate-50 rounded-full transition-colors"><mat-icon>close</mat-icon></button>
               </div>
               
               <form [formGroup]="loanForm" class="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
                  <!-- Form Instruction -->
                  <div class="md:col-span-2 pb-2">
                     <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest italic">Fields marked with <span class="text-rose-500">*</span> are mandatory for processing.</p>
                  </div>

                  <!-- Loan Type -->
                  <div class="space-y-2">
                     <label class="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1">
                        Loan Type <span class="text-rose-500">*</span>
                     </label>
                     <select formControlName="type" 
                        [class.border-rose-200]="loanForm.get('type')?.invalid && loanForm.get('type')?.touched"
                        class="w-full h-12 px-4 bg-slate-50 border border-slate-100 rounded-xl outline-none focus:border-emerald-500 text-sm font-bold transition-all appearance-none cursor-pointer">
                        <option value="Personal">Personal Loan</option>
                        <option value="Home">Home Mortgage</option>
                        <option value="Auto">Auto Financing</option>
                        <option value="Business">Business Growth</option>
                     </select>
                     @if (loanForm.get('type')?.invalid && loanForm.get('type')?.touched) {
                        <p class="text-[9px] font-bold text-rose-500 uppercase tracking-tight">Please select a loan type</p>
                     }
                  </div>

                  <!-- Requested Amount -->
                  <div class="space-y-2">
                     <label class="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1">
                        Requested Amount <span class="text-rose-500">*</span>
                     </label>
                     <div class="relative">
                        <span class="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-bold">$</span>
                        <input type="number" formControlName="amount" 
                           [class.border-rose-200]="loanForm.get('amount')?.invalid && loanForm.get('amount')?.touched"
                           placeholder="Enter amount (min $1,000)"
                           class="w-full h-12 pl-10 pr-4 bg-slate-50 border border-slate-100 rounded-xl outline-none focus:border-emerald-500 text-sm font-bold transition-all">
                     </div>
                     @if (loanForm.get('amount')?.invalid && loanForm.get('amount')?.touched) {
                        <p class="text-[9px] font-bold text-rose-500 uppercase tracking-tight">
                           @if (loanForm.get('amount')?.errors?.['required']) { Amount is required }
                           @else { Minimum loan amount is $1,000 }
                        </p>
                     }
                  </div>

                  <!-- Tenure -->
                  <div class="space-y-2">
                     <label class="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1">
                        Tenure (Months) <span class="text-rose-500">*</span>
                     </label>
                     <input type="number" formControlName="tenure" 
                        [class.border-rose-200]="loanForm.get('tenure')?.invalid && loanForm.get('tenure')?.touched"
                        class="w-full h-12 px-4 bg-slate-50 border border-slate-100 rounded-xl outline-none focus:border-emerald-500 text-sm font-bold transition-all">
                     @if (loanForm.get('tenure')?.invalid && loanForm.get('tenure')?.touched) {
                        <p class="text-[9px] font-bold text-rose-500 uppercase tracking-tight">Minimum tenure is 6 months</p>
                     }
                  </div>

                  <!-- Income Range -->
                  <div class="space-y-2">
                     <label class="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1">
                        Monthly Income Range <span class="text-rose-500">*</span>
                     </label>
                     <select formControlName="incomeRange"
                        [class.border-rose-200]="loanForm.get('incomeRange')?.invalid && loanForm.get('incomeRange')?.touched"
                        class="w-full h-12 px-4 bg-slate-50 border border-slate-100 rounded-xl outline-none focus:border-emerald-500 text-sm font-bold transition-all appearance-none cursor-pointer">
                        <option value="">Select Range</option>
                        <option value="$3k - $5k">$3k - $5k</option>
                        <option value="$5k - $10k">$5k - $10k</option>
                        <option value="$10k+">$10k+</option>
                     </select>
                     @if (loanForm.get('incomeRange')?.invalid && loanForm.get('incomeRange')?.touched) {
                        <p class="text-[9px] font-bold text-rose-500 uppercase tracking-tight">Income range is required</p>
                     }
                  </div>

                  <div class="md:col-span-2 text-center pt-8">
                     <div class="flex flex-col md:flex-row items-center justify-center gap-4">
                        <button type="button" (click)="showApplication.set(false)" class="w-full md:w-auto px-10 py-4 bg-white text-slate-500 border border-slate-100 rounded-2xl text-[10px] font-bold uppercase tracking-widest hover:bg-slate-50 transition-all">Discard</button>
                        <button type="button" (click)="submitApplication()" 
                           [disabled]="loanForm.invalid"
                           [class.opacity-50]="loanForm.invalid"
                           class="w-full md:w-auto px-10 py-4 bg-slate-900 text-white rounded-2xl text-[10px] font-bold uppercase tracking-widest hover:bg-slate-800 transition-all shadow-xl shadow-slate-900/10 flex items-center justify-center gap-2">
                           <mat-icon class="text-sm">verified</mat-icon>
                           Submit for AI Verification
                        </button>
                     </div>
                  </div>
               </form>
            </div>
         </div>
      }

      <!-- Performance Stats -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
         <div class="lg:col-span-2 space-y-8">
            <h3 class="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4">Active Facilities</h3>
            <div class="grid gap-6">
               @for (loan of customerService.loans(); track loan.id) {
                  <div class="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm group hover:shadow-md transition-all relative overflow-hidden">
                     <div class="flex flex-col md:flex-row justify-between gap-8 relative z-10">
                        <div class="flex items-center gap-6">
                           <div class="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center text-slate-900 border border-slate-100 group-hover:bg-slate-900 group-hover:text-white transition-all">
                              <mat-icon>{{ loan.type === 'Home' ? 'home' : loan.type === 'Auto' ? 'directions_car' : 'person' }}</mat-icon>
                           </div>
                           <div>
                              <p class="text-[10px] font-bold text-emerald-600 uppercase tracking-widest mb-1">{{ loan.type }} Credit</p>
                              <h4 class="text-lg font-bold text-slate-900">Acc no: {{ loan.loanNumber }}</h4>
                           </div>
                        </div>
                        <div class="flex gap-10">
                           <div class="text-right">
                              <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Interest Rate</p>
                              <p class="text-sm font-bold font-mono">{{ loan.interestRate }}% APR</p>
                           </div>
                           <div class="text-right">
                              <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Monthly EMI</p>
                              <p class="text-sm font-bold font-mono text-slate-900">{{ loan.monthlyInstallment | currency:'USD' }}</p>
                           </div>
                        </div>
                     </div>

                     <div class="mt-10 space-y-4 relative z-10">
                        <div class="flex justify-between text-[10px] font-bold uppercase tracking-widest text-slate-400">
                           <span>Repayment Progress</span>
                           <span class="text-slate-900">{{ (loan.paidAmount / loan.amount * 100) | number:'1.0-0' }}% Completed</span>
                        </div>
                        <div class="h-2 bg-slate-100 rounded-full overflow-hidden">
                           <div class="h-full bg-emerald-500 rounded-full transition-all duration-1000" [style.width]="(loan.paidAmount / loan.amount * 100) + '%'"></div>
                        </div>
                        <div class="flex justify-between text-[10px] font-bold font-mono text-slate-400 italic">
                           <span>Paid: {{ loan.paidAmount | currency:'USD' }}</span>
                           <span>Remaining: {{ (loan.amount - loan.paidAmount) | currency:'USD' }}</span>
                        </div>
                     </div>

                     <div class="mt-8 pt-8 border-t border-slate-50 flex justify-between items-center relative z-10">
                        <div class="flex items-center gap-2">
                           <mat-icon class="text-slate-300 text-sm">schedule</mat-icon>
                           <span class="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Next Due: June 15, 2024</span>
                        </div>
                        <div class="flex gap-2">
                           <button class="px-4 py-2.5 bg-slate-50 text-slate-500 rounded-xl text-[9px] font-bold uppercase tracking-widest hover:bg-slate-900 hover:text-white transition-all">Details</button>
                           <button class="px-4 py-2.5 bg-emerald-600 text-white rounded-xl text-[9px] font-bold uppercase tracking-widest hover:bg-emerald-700 shadow-lg shadow-emerald-600/10 transition-all">Pre-pay Loan</button>
                        </div>
                     </div>
                  </div>
               }
            </div>
         </div>

         <div class="space-y-8">
            <h3 class="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4">Credit Insights</h3>
            <div class="bg-slate-900 p-8 rounded-[2.5rem] text-white shadow-xl relative overflow-hidden group">
               <div class="absolute -top-10 -right-10 w-32 h-32 bg-emerald-500/10 rounded-full blur-2xl group-hover:scale-150 transition-transform duration-700"></div>
               <div class="relative z-10 space-y-8">
                  <div>
                     <p class="text-[10px] font-bold text-white/40 uppercase tracking-widest mb-4 italic">Tier-1 Credit Health</p>
                     <p class="text-5xl font-bold font-mono tracking-tighter">784</p>
                     <p class="text-xs font-bold text-emerald-400 uppercase tracking-widest mt-2 group-hover:translate-x-2 transition-transform inline-flex items-center gap-1">Excellent Score <mat-icon class="text-xs">trending_up</mat-icon></p>
                  </div>
                  
                  <div class="space-y-4">
                     <p class="text-xs font-light text-white/60 leading-relaxed italic">"You are eligible for internal pre-approved loans up to <span class="text-white font-bold">$25,000</span> with 0% processing fee."</p>
                     <button class="w-full py-4 bg-white/10 hover:bg-white text-white hover:text-slate-900 rounded-2xl text-[10px] font-bold uppercase tracking-widest border border-white/10 transition-all">Claim Offer</button>
                  </div>
               </div>
            </div>

            <div class="p-8 bg-white rounded-[2.5rem] border border-slate-100 shadow-sm">
               <h4 class="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-6">Pending Applications</h4>
               @for (app of customerService.loanApplications(); track app.id) {
                  <div class="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-100 mb-4 animate-in fade-in slide-in-from-right-4">
                     <div>
                        <p class="text-xs font-bold text-slate-900">{{ app.type }} Financing</p>
                        <p class="text-[10px] text-slate-400 font-bold uppercase mt-1">Requested: {{ app.amount | currency:'USD' }}</p>
                     </div>
                     <span [class]="'px-2 py-0.5 rounded-lg text-[8px] font-bold uppercase border ' + (app.status === 'Under Review' ? 'bg-amber-50 text-amber-600 border-amber-100' : 'bg-emerald-50 text-emerald-600 border-emerald-100')">{{ app.status }}</span>
                  </div>
               } @empty {
                  <p class="text-[10px] text-slate-400 italic text-center py-4 uppercase font-bold tracking-widest">No active applications</p>
               }
            </div>
         </div>
      </div>

    </div>
  `
})
export class CustomerLoans {
  customerService = inject(BankingCustomerService);
  private fb = inject(FormBuilder);

  showApplication = signal(false);
  loanForm = this.fb.group({
    type: ['Personal', Validators.required],
    amount: [null, [Validators.required, Validators.min(1000)]],
    tenure: [12, [Validators.required, Validators.min(6)]],
    incomeRange: ['', Validators.required]
  });

  submitApplication() {
    if (this.loanForm.valid) {
      const { type, amount, tenure } = this.loanForm.value;
      this.customerService.applyForLoan({
        customerId: '1',
        type: type!,
        amount: Number(amount),
        tenure: Number(tenure),
        status: 'Under Review',
        date: new Date().toISOString()
      }).subscribe(() => {
        this.showApplication.set(false);
        this.loanForm.reset({ type: 'Personal', tenure: 12 });
      });
    }
  }
}
