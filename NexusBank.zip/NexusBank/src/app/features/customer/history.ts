import { Component, inject, computed, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BankingCustomerService } from './banking-customer.service';

@Component({
  selector: 'app-customer-history',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-8 animate-in fade-in slide-in-from-right-4 duration-500">
      <div class="flex flex-col md:flex-row justify-between items-center gap-6 bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm">
        <div>
           <h2 class="text-3xl font-bold text-slate-900 tracking-tight">Statement Ledger</h2>
           <p class="text-slate-500 font-light mt-1 text-sm uppercase tracking-wider font-bold">Comprehensive audit trail of all financial mesh settlements.</p>
        </div>
        <div class="flex gap-3">
           <button class="px-6 py-3 bg-slate-900 text-white rounded-2xl text-[10px] font-bold uppercase tracking-widest hover:bg-slate-800 transition-all flex items-center gap-2 shadow-lg shadow-slate-900/10">
              <mat-icon class="text-lg">download</mat-icon>
              PDF Statements
           </button>
           <button class="px-6 py-3 bg-white text-slate-600 border border-slate-100 rounded-2xl text-[10px] font-bold uppercase tracking-widest hover:bg-slate-50 transition-all">Export CSV</button>
        </div>
      </div>

      <!-- Search & Filters -->
      <div class="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm flex flex-col md:flex-row items-center gap-6">
         <div class="relative flex-1 w-full group">
            <mat-icon class="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-emerald-500 transition-colors">search</mat-icon>
            <input 
              type="text" 
              (input)="searchTerm.set($any($event.target).value)"
              placeholder="Search by merchant, reference or transaction hash..." 
              class="w-full pl-12 pr-6 py-4 bg-slate-50 border border-transparent rounded-2xl outline-none focus:border-emerald-500 focus:bg-white text-sm font-medium transition-all"
            >
         </div>
         <div class="flex gap-3 w-full md:w-auto">
            <select class="flex-1 md:flex-none px-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl text-[10px] font-bold uppercase tracking-widest outline-none focus:border-emerald-500 transition-all cursor-pointer">
               <option>All Operations</option>
               <option>Mesh Transfers</option>
               <option>Deposits</option>
               <option>Merchant Pay</option>
            </select>
            <select class="flex-1 md:flex-none px-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl text-[10px] font-bold uppercase tracking-widest outline-none focus:border-emerald-500 transition-all cursor-pointer">
               <option>Last 30 Cycles</option>
               <option>Quarterly Hub</option>
               <option>Full Fiscal Year</option>
            </select>
         </div>
      </div>

      <!-- Transaction Table -->
      <div class="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm overflow-hidden">
         <div class="overflow-x-auto">
            <table class="w-full text-left">
               <thead>
                  <tr class="bg-slate-50/30">
                     <th class="px-8 py-6 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Operation Detail</th>
                     <th class="px-8 py-6 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Classification</th>
                     <th class="px-8 py-6 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-right">Settlement</th>
                     <th class="px-8 py-6 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-center">Status</th>
                  </tr>
               </thead>
               <tbody class="divide-y divide-slate-50">
                  @for (tx of filteredTransactions(); track tx.id) {
                     <tr class="hover:bg-slate-50/50 transition-all group">
                        <td class="px-8 py-6">
                           <div class="flex items-center gap-4">
                              <div [class]="'w-12 h-12 rounded-2xl flex items-center justify-center transition-all shadow-sm ' + (tx.type === 'deposit' ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-100 text-slate-900')">
                                 <mat-icon>{{ tx.category === 'Shopping' ? 'shopping_bag' : tx.category === 'Food' ? 'restaurant' : 'sync_alt' }}</mat-icon>
                              </div>
                              <div>
                                 <div class="flex items-center gap-2">
                                    <span class="text-sm font-bold text-slate-900">{{ tx.description }}</span>
                                    <span class="text-[8px] font-mono bg-slate-100 px-1.5 py-0.5 rounded text-slate-400 font-bold uppercase">Hash: {{ tx.id.slice(0,8) }}</span>
                                 </div>
                                 <p class="text-[9px] text-slate-400 font-bold uppercase tracking-widest mt-1">{{ tx.date | date:'MMMM dd, yyyy • hh:mm a' }}</p>
                              </div>
                           </div>
                        </td>
                        <td class="px-8 py-6">
                           <span class="px-3 py-1 bg-slate-50 text-slate-500 rounded-lg text-[9px] font-bold uppercase tracking-widest border border-slate-100">{{ tx.category }}</span>
                        </td>
                        <td class="px-8 py-6 text-right">
                           <span [class]="'text-lg font-bold font-mono tracking-tighter ' + (tx.type === 'deposit' ? 'text-emerald-600' : 'text-slate-900')">
                              {{ tx.type === 'deposit' ? '+' : '-' }}{{ tx.amount | currency:'USD' }}
                           </span>
                        </td>
                        <td class="px-8 py-6">
                           <div class="flex justify-center">
                              <span [class]="'px-3 py-1 flex items-center gap-1.5 rounded-full text-[9px] font-bold uppercase tracking-widest border ' + (tx.status === 'completed' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-amber-50 text-amber-600 border-amber-100')">
                                 <div [class]="'w-1.5 h-1.5 rounded-full ' + (tx.status === 'completed' ? 'bg-emerald-500' : 'bg-amber-500')"></div>
                                 {{ tx.status === 'completed' ? 'Settled' : 'Pending' }}
                              </span>
                           </div>
                        </td>
                     </tr>
                  } @empty {
                     <tr>
                        <td colspan="4" class="py-20 text-center">
                           <div class="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4">
                             <mat-icon class="text-slate-200 text-3xl">history</mat-icon>
                           </div>
                           <p class="text-xs font-bold text-slate-400 uppercase tracking-widest italic">No matching operations recorded in the ledger</p>
                        </td>
                     </tr>
                  }
               </tbody>
            </table>
         </div>
         
         <!-- Pagination -->
         <div class="p-8 bg-slate-50/20 border-t border-slate-50 flex items-center justify-between">
            <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Hub Batch Summary: {{ filteredTransactions().length }} Transaction(s) Displayed</p>
            <div class="flex gap-2">
               <button class="w-10 h-10 bg-white border border-slate-100 rounded-xl flex items-center justify-center text-slate-400 hover:text-emerald-600 hover:border-emerald-600 transition-all shadow-sm">
                  <mat-icon>chevron_left</mat-icon>
               </button>
               <button class="px-4 h-10 bg-slate-900 text-white rounded-xl text-xs font-bold font-mono shadow-lg shadow-slate-900/10">1</button>
               <button class="w-10 h-10 bg-white border border-slate-100 rounded-xl flex items-center justify-center text-slate-400 hover:text-emerald-600 hover:border-emerald-600 transition-all shadow-sm">
                  <mat-icon>chevron_right</mat-icon>
               </button>
            </div>
         </div>
      </div>
    </div>
  `
})
export class CustomerHistory {
  private customerService = inject(BankingCustomerService);
  searchTerm = signal('');

  filteredTransactions = computed(() => {
    const term = this.searchTerm().toLowerCase();
    const txs = this.customerService.transactions();
    if (!term) return txs;
    return txs.filter(t => 
      t.description.toLowerCase().includes(term) || 
      t.id.toLowerCase().includes(term) ||
      t.category.toLowerCase().includes(term)
    );
  });
}
