import { Component, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BankingCustomerService } from './banking-customer.service';

@Component({
  selector: 'app-customer-cards',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-10 animate-in fade-in slide-in-from-right-4 duration-500">
      
      <!-- Page Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div>
           <h2 class="text-3xl font-bold text-slate-900 tracking-tight">Access Hub & Cards</h2>
           <p class="text-xs text-slate-500 mt-1 uppercase tracking-widest font-bold">Manage your physical and virtual payment instruments</p>
        </div>
        <button class="px-6 py-3 bg-slate-900 text-white rounded-2xl text-[10px] font-bold uppercase tracking-widest shadow-lg shadow-slate-900/10 hover:bg-slate-800 transition-all flex items-center gap-2">
           <mat-icon class="text-lg">add_card</mat-icon>
           Order Physical Card
        </button>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
         @for (card of customerService.cards(); track card.id) {
            <div [class]="'relative min-h-[220px] rounded-[2.5rem] p-10 text-white overflow-hidden shadow-2xl group transition-all duration-700 ' + (card.type.includes('Visa') ? 'bg-linear-to-tr from-slate-900 via-slate-800 to-slate-950' : 'bg-linear-to-tr from-emerald-900 via-teal-900 to-emerald-950')">
               <!-- Abstract Mesh -->
               <div class="absolute -top-10 -right-10 w-48 h-48 bg-white/5 rounded-full blur-3xl transition-transform group-hover:scale-150 duration-1000"></div>
               
               <div class="relative z-10 flex flex-col h-full justify-between">
                  <div class="flex justify-between items-start mb-12">
                     <div>
                        <p class="text-[10px] font-bold text-white/40 uppercase tracking-widest mb-1">{{ card.type }} Hub</p>
                        <h4 class="text-lg font-bold tracking-tight">Smart Secure Business</h4>
                     </div>
                     <mat-icon class="text-3xl text-white/20">contactless</mat-icon>
                  </div>

                  <div>
                     <p class="text-2xl font-mono font-bold tracking-[0.2em] mb-8 drop-shadow-lg">{{ formatCardNumber(card.number) }}</p>
                     <div class="flex justify-between items-end">
                        <div class="flex gap-12">
                           <div>
                              <p class="text-[8px] font-bold text-white/40 uppercase tracking-widest mb-1">Holder</p>
                              <p class="text-[10px] font-bold uppercase">Jane Cooper</p>
                           </div>
                           <div>
                              <p class="text-[8px] font-bold text-white/40 uppercase tracking-widest mb-1">Valid Thru</p>
                              <p class="text-[10px] font-bold font-mono">{{ card.expiry }}</p>
                           </div>
                        </div>
                        <div class="w-14 h-10 bg-white/10 rounded-xl overflow-hidden flex items-center justify-center backdrop-blur-md border border-white/5 grayscale group-hover:grayscale-0 transition-all">
                           <mat-icon class="text-white/40 text-[24px]">credit_card</mat-icon>
                        </div>
                     </div>
                  </div>
               </div>

               @if (card.status === 'blocked') {
                  <div class="absolute inset-0 bg-slate-900/90 backdrop-blur-md flex items-center justify-center z-20">
                     <div class="text-center">
                        <mat-icon class="text-5xl text-rose-500 mb-2">lock_person</mat-icon>
                        <p class="text-[10px] font-bold uppercase tracking-widest border-t border-rose-500/20 pt-2">Security Freeze Active</p>
                     </div>
                  </div>
               }
               
               <div class="absolute top-4 right-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-all z-30">
                  <button (click)="toggleCard(card.id, card.status)" class="p-3 bg-white/10 hover:bg-white/20 rounded-xl transition-all">
                     <mat-icon class="text-sm">{{ card.status === 'active' ? 'lock' : 'lock_open' }}</mat-icon>
                  </button>
                  <button class="p-3 bg-white/10 hover:bg-white/20 rounded-xl transition-all">
                     <mat-icon class="text-sm">visibility</mat-icon>
                  </button>
               </div>
            </div>
         }

         <div class="min-h-[220px] rounded-[2.5rem] border-2 border-dashed border-slate-200 p-10 flex flex-col items-center justify-center text-center group cursor-pointer hover:border-emerald-500 hover:bg-emerald-50/20 transition-all">
            <div class="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-emerald-50 group-hover:scale-110 transition-all border border-slate-100 shadow-sm">
               <mat-icon class="text-slate-400 group-hover:text-emerald-600">add</mat-icon>
            </div>
            <p class="text-sm font-bold text-slate-700">Digital Virtual Card</p>
            <p class="text-[10px] text-slate-400 uppercase tracking-widest font-bold mt-1">Instant mesh activation</p>
         </div>
      </div>

      <!-- Quick Actions Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 pt-10 border-t border-slate-50">
         <div class="bg-white p-6 rounded-3xl border border-slate-100 hover:border-emerald-500 shadow-sm transition-all cursor-pointer group">
            <div class="w-12 h-12 bg-slate-50 rounded-2xl flex items-center justify-center mb-4 group-hover:bg-emerald-600 group-hover:text-white transition-all">
               <mat-icon>password</mat-icon>
            </div>
            <p class="text-xs font-bold text-slate-900">Change PIN</p>
            <p class="text-[9px] text-slate-400 font-bold uppercase tracking-widest mt-1">Instant update</p>
         </div>
         <div class="bg-white p-6 rounded-3xl border border-slate-100 hover:border-emerald-500 shadow-sm transition-all cursor-pointer group">
            <div class="w-12 h-12 bg-slate-50 rounded-2xl flex items-center justify-center mb-4 group-hover:bg-emerald-600 group-hover:text-white transition-all">
               <mat-icon>language</mat-icon>
            </div>
            <p class="text-xs font-bold text-slate-900">Usage Limits</p>
            <p class="text-[9px] text-slate-400 font-bold uppercase tracking-widest mt-1">Geo-fencing hub</p>
         </div>
         <div class="bg-white p-6 rounded-3xl border border-slate-100 hover:border-emerald-500 shadow-sm transition-all cursor-pointer group">
            <div class="w-12 h-12 bg-slate-50 rounded-2xl flex items-center justify-center mb-4 group-hover:bg-emerald-600 group-hover:text-white transition-all">
               <mat-icon>support_agent</mat-icon>
            </div>
            <p class="text-xs font-bold text-slate-900">Lost/Stolen</p>
            <p class="text-[9px] text-slate-400 font-bold uppercase tracking-widest mt-1">Emergency block</p>
         </div>
         <div class="bg-white p-6 rounded-3xl border border-slate-100 hover:border-emerald-500 shadow-sm transition-all cursor-pointer group">
            <div class="w-12 h-12 bg-slate-50 rounded-2xl flex items-center justify-center mb-4 group-hover:bg-emerald-600 group-hover:text-white transition-all">
               <mat-icon>redeem</mat-icon>
            </div>
            <p class="text-xs font-bold text-slate-900">Smart Rewards</p>
            <p class="text-[9px] text-slate-400 font-bold uppercase tracking-widest mt-1">Cashback & miles</p>
         </div>
      </div>

    </div>
  `
})
export class CustomerCards {
  customerService = inject(BankingCustomerService);

  formatCardNumber(num: string) {
    return num.replace(/(.{4})/g, '$1 ').trim();
  }

  toggleCard(id: string, status: string) {
    if (confirm(`Are you sure you want to ${status === 'active' ? 'lock' : 'unlock'} this banking instrument?`)) {
      this.customerService.toggleCardStatus(id, status).subscribe();
    }
  }
}
