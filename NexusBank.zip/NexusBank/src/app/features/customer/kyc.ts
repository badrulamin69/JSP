import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-customer-kyc',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-10 animate-in fade-in slide-in-from-right-4 duration-500 pb-20">
      
      <!-- Page Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div>
           <h2 class="text-3xl font-bold text-slate-900 tracking-tight">KYC Compliance Hub</h2>
           <p class="text-xs text-slate-500 mt-1 uppercase tracking-widest font-bold">Verified digital personhood status and regulatory mesh clearance</p>
        </div>
        <div class="bg-emerald-50 px-5 py-2 rounded-2xl border border-emerald-100 flex items-center gap-3">
           <div class="w-3 h-3 bg-emerald-500 rounded-full shadow-[0_0_8px_#10b981]"></div>
           <span class="text-[10px] font-bold text-emerald-600 uppercase tracking-widest">Global Verified Status</span>
        </div>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-3 gap-10">
         <!-- Status Board -->
         <div class="lg:col-span-1 space-y-8">
            <div class="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm text-center relative overflow-hidden group">
               <div class="absolute -right-10 -top-10 w-32 h-32 bg-emerald-50 rounded-full blur-2xl group-hover:scale-150 transition-transform duration-[2s]"></div>
               <div class="relative z-10">
                  <div class="w-32 h-32 rounded-full border-8 border-slate-50 flex items-center justify-center mx-auto shadow-2xl bg-white mb-8 group/icon">
                     <mat-icon class="text-6xl text-emerald-500 group-hover/icon:scale-110 transition-transform">verified</mat-icon>
                  </div>
                  <h3 class="text-2xl font-bold text-slate-900 tracking-tight">Identity Tier 04</h3>
                  <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-2 italic leading-relaxed">Your personhood has been verified across 12 regulated global hubs.</p>
                  
                  <div class="mt-12 space-y-4">
                     <div class="flex justify-between items-center text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-2">
                        <span>Mesh Trust Score</span>
                        <span class="text-emerald-600">98/100</span>
                     </div>
                     <div class="h-2 w-full bg-slate-50 rounded-full overflow-hidden">
                        <div class="h-full bg-emerald-500 w-[98%] shadow-[0_0_10px_#10b981]"></div>
                     </div>
                  </div>
               </div>
            </div>

            <div class="bg-slate-900 p-8 rounded-[2.5rem] text-white shadow-xl relative overflow-hidden">
               <div class="absolute -left-10 -bottom-10 w-40 h-40 bg-blue-500/10 rounded-full blur-3xl"></div>
               <div class="relative z-10 space-y-6">
                  <div class="flex items-center gap-4">
                     <div class="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center text-blue-400 border border-white/5">
                        <mat-icon>vpn_lock</mat-icon>
                     </div>
                     <p class="text-sm font-bold uppercase tracking-widest italic leading-tight">Advanced Proof-of-Mesh</p>
                  </div>
                  <p class="text-[10px] text-white/50 font-light leading-relaxed uppercase tracking-widest">Connect your hardware biometric node to unlock Tier 10 limits ($5,000,000 daily mesh settlement).</p>
                  <button class="w-full py-4 bg-white text-slate-900 rounded-2xl text-[10px] font-bold uppercase tracking-widest hover:bg-emerald-500 hover:text-white transition-all shadow-xl">Activate Mesh Node</button>
               </div>
            </div>
         </div>

         <!-- Requirement List -->
         <div class="lg:col-span-2">
            <div class="bg-white p-10 lg:p-14 rounded-[3.5rem] border border-slate-100 shadow-sm">
               <h3 class="text-xl font-bold text-slate-900 mb-10 tracking-tight">Identity Artifacts & Verifications</h3>
               
               <div class="space-y-6">
                  @for (req of kycRequirements; track req.id) {
                     <div class="flex items-center justify-between p-7 bg-slate-50 rounded-[2rem] border border-slate-100 group hover:border-slate-900 transition-all hover:translate-x-2">
                        <div class="flex items-center gap-6">
                           <div [class]="'w-14 h-14 rounded-2xl flex items-center justify-center transition-all shadow-sm ' + (req.status === 'Verified' ? 'bg-emerald-100 text-emerald-600' : 'bg-slate-200 text-slate-400')">
                              <mat-icon>{{ req.icon }}</mat-icon>
                           </div>
                           <div>
                              <h4 class="text-sm font-bold text-slate-900">{{ req.name }}</h4>
                              <p class="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">{{ req.desc }}</p>
                           </div>
                        </div>
                        <div class="flex items-center gap-6">
                           <span [class]="'px-4 py-1.5 rounded-xl text-[9px] font-bold uppercase border ' + (req.status === 'Verified' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-amber-50 text-amber-600 border-amber-100')">
                              {{ req.status }}
                           </span>
                           <button class="w-10 h-10 bg-white border border-slate-100 rounded-xl flex items-center justify-center text-slate-400 hover:text-slate-900 transition-all shadow-sm">
                              <mat-icon class="text-sm">visibility</mat-icon>
                           </button>
                        </div>
                     </div>
                  }
               </div>

               <div class="mt-14 p-8 bg-slate-900 rounded-[2.5rem] text-white flex items-center justify-between relative overflow-hidden group">
                  <div class="absolute inset-0 bg-linear-to-r from-emerald-600/10 to-transparent"></div>
                  <div class="relative z-10">
                     <p class="text-[10px] font-bold text-white/40 uppercase tracking-widest mb-1">Upcoming Renewal Hub</p>
                     <p class="text-xs font-bold leading-relaxed uppercase tracking-widest">Passport Verification Mesh expires in <span class="text-emerald-400">142 Days</span></p>
                  </div>
                  <button class="relative z-10 px-6 py-3 bg-white/10 hover:bg-white text-white hover:text-slate-900 rounded-xl text-[10px] font-bold uppercase tracking-widest border border-white/10 transition-all">Update Document</button>
               </div>
            </div>
         </div>
      </div>

    </div>
  `
})
export class CustomerKyc {
  kycRequirements = [
    { id: 1, name: 'Proof of Hub Forename', desc: 'Passport / National ID Registry', icon: 'badge', status: 'Verified' },
    { id: 2, name: 'Mesh Residency Verification', desc: 'Verified Mesh Utility Settlement Bill', icon: 'home', status: 'Verified' },
    { id: 3, name: 'Biometric Mesh Scan', desc: 'Secure Neural Face Identity Liveness', icon: 'face', status: 'Verified' },
    { id: 4, name: 'Social Mesh Context', desc: 'Verified Professional Gateway Link', icon: 'public', status: 'Pending' }
  ];
}
