import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { BankingCustomerService } from './banking-customer.service';
import { SessionService } from '../../core/services/session.service';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-customer-layout',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink, RouterLinkActive, MatIconModule],
  template: `
    <div class="min-h-screen bg-slate-50 flex flex-col lg:flex-row overflow-hidden font-sans">
      
      <!-- Desktop Sidebar -->
      <aside class="hidden lg:flex flex-col w-72 bg-white border-r border-slate-200 h-screen shrink-0 overflow-y-auto custom-scrollbar shadow-sm z-50">
        <div class="h-20 flex items-center px-8 border-b border-slate-100">
           <div class="flex items-center gap-3">
              <div class="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-600/20">
                 <mat-icon class="text-white">account_balance</mat-icon>
              </div>
              <div>
                <h1 class="text-lg font-bold text-slate-900 leading-tight">Smart Secure</h1>
                <p class="text-[10px] text-emerald-600 font-bold uppercase tracking-widest leading-none">Enterprise Banking</p>
              </div>
           </div>
        </div>

        <nav class="flex-1 p-6 space-y-1">
           @for (section of menuSections; track section.title) {
             <p class="px-3 text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-6 mb-2">{{ section.title }}</p>
             @for (item of section.items; track item.path) {
               <a 
                 [routerLink]="['/customer', item.path]"
                 routerLinkActive="bg-emerald-50 text-emerald-700 font-bold border-r-4 border-emerald-600"
                 class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-500 hover:bg-slate-50 hover:text-slate-900 transition-all text-sm group"
               >
                  <mat-icon class="text-lg group-hover:scale-110 transition-transform">{{ item.icon }}</mat-icon>
                  <span>{{ item.label }}</span>
               </a>
             }
           }
           
           <div class="mt-8 pt-6 border-t border-slate-100">
             <button (click)="auth.logout()" class="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-rose-500 hover:bg-rose-50 transition-all text-sm font-bold group">
                <mat-icon class="text-lg group-hover:rotate-180 transition-transform">logout</mat-icon>
                <span>End Secure Session</span>
             </button>
           </div>
        </nav>

        <div class="p-6 border-t border-slate-100">
           <div class="bg-slate-900 rounded-2xl p-5 text-white relative overflow-hidden">
              <div class="absolute -top-10 -right-10 w-24 h-24 bg-emerald-500/10 rounded-full blur-2xl"></div>
              <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Portfolio Balance</p>
              <p class="text-xl font-bold font-mono">{{ customerService.totalBalance() | currency:'USD' }}</p>
              <button [routerLink]="['/customer', 'accounts']" class="w-full mt-3 py-2 bg-white/10 hover:bg-white/20 rounded-lg text-[9px] font-bold uppercase tracking-widest transition-all">My Assets</button>
           </div>
        </div>
      </aside>

      <!-- Main Content Area -->
      <main class="flex-1 flex flex-col min-w-0 h-screen overflow-hidden">
        
        <!-- Navbar -->
        <header class="h-16 lg:h-20 bg-white/80 backdrop-blur-md border-b border-slate-200 flex items-center justify-between px-6 lg:px-10 shrink-0 z-40 sticky top-0">
           <div class="flex items-center gap-4">
              <div class="lg:hidden flex items-center gap-3">
                 <div class="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center">
                    <mat-icon class="text-white text-base">account_balance</mat-icon>
                 </div>
                 <span class="font-bold text-slate-900 text-sm">Smart Secure</span>
              </div>
              <div class="hidden lg:flex items-center gap-4">
                 <div class="flex items-center gap-2 px-3 py-1.5 bg-emerald-50 text-emerald-700 text-[10px] font-bold rounded-full border border-emerald-100">
                   <div class="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></div>
                   KYC VERIFIED
                 </div>
                 <p class="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Server Time: {{ today | date:'HH:mm:ss' }}</p>
              </div>
           </div>

           <div class="flex items-center gap-2 lg:gap-6">
              <div class="relative group cursor-pointer lg:pr-6 border-slate-100 flex items-center gap-3">
                 <div class="text-right hidden sm:block">
                    <p class="text-xs font-bold text-slate-900">{{ session.session()?.name }}</p>
                    <p class="text-[9px] text-slate-400 font-bold uppercase tracking-tighter">{{ session.session()?.role }} Account</p>
                 </div>
                 <div class="relative">
                   <img [src]="'https://i.pravatar.cc/150?u=' + session.session()?.id" class="w-9 h-9 lg:w-11 lg:h-11 rounded-full border-2 border-white shadow-sm ring-1 ring-slate-100" alt="Avatar">
                   <div class="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 border-2 border-white rounded-full"></div>
                 </div>
              </div>
              <button [routerLink]="['/customer/notifications']" class="relative p-2 text-slate-500 hover:bg-slate-100 rounded-full transition-all">
                <mat-icon>notifications</mat-icon>
                @if (customerService.unreadNotificationsCount() > 0) {
                  <span class="absolute top-2 right-2 w-2 h-2 bg-rose-500 rounded-full border-2 border-white"></span>
                }
              </button>
              <button (click)="auth.logout()" class="lg:hidden p-2 text-rose-500 hover:bg-rose-50 rounded-full transition-all">
                <mat-icon>logout</mat-icon>
              </button>
           </div>
        </header>

        <!-- Content Area -->
        <div class="flex-1 overflow-y-auto p-4 lg:p-10 custom-scrollbar pb-24 lg:pb-10 bg-slate-50/50">
           <router-outlet></router-outlet>
        </div>

        <!-- Mobile Bottom Nav -->
        <nav class="lg:hidden fixed bottom-4 left-4 right-4 h-16 bg-slate-900 rounded-2xl border border-white/10 flex items-center justify-around px-4 z-50 shadow-2xl">
           @for (item of mobileItems; track item.path) {
             <a 
               [routerLink]="['/customer', item.path]"
               routerLinkActive="text-emerald-400 scale-110"
               class="flex flex-col items-center gap-1 text-slate-400 transition-all duration-300"
             >
                <mat-icon class="text-xl">{{ item.icon }}</mat-icon>
                <span class="text-[8px] font-bold uppercase tracking-widest">{{ item.label }}</span>
             </a>
           }
        </nav>
      </main>
    </div>
  `,
  styles: [`
    .custom-scrollbar::-webkit-scrollbar {
      width: 4px;
    }
    .custom-scrollbar::-webkit-scrollbar-track {
      background: transparent;
    }
    .custom-scrollbar::-webkit-scrollbar-thumb {
      background: rgba(0, 0, 0, 0.05);
      border-radius: 10px;
    }
  `]
})
export class CustomerLayout {
  customerService = inject(BankingCustomerService);
  session = inject(SessionService);
  auth = inject(AuthService);
  today = new Date();

  menuSections = [
    {
      title: 'Banking Core',
      items: [
        { path: 'dashboard', label: 'Dashboard', icon: 'dashboard' },
        { path: 'accounts', label: 'My Accounts', icon: 'account_balance' },
        { path: 'history', label: 'Transactions', icon: 'history' },
        { path: 'transfer', label: 'Transfer Money', icon: 'send' },
        { path: 'beneficiaries', label: 'Beneficiaries', icon: 'people' },
      ]
    },
    {
      title: 'Financial Products',
      items: [
        { path: 'loans', label: 'Loans & Credit', icon: 'handshake' },
        { path: 'investments', label: 'Wealth & Stock', icon: 'trending_up' },
        { path: 'fixed-deposits', label: 'Fixed Deposits', icon: 'savings' },
        { path: 'cards', label: 'Card Management', icon: 'credit_card' },
      ]
    },
    {
      title: 'Tools & Services',
      items: [
        { path: 'exchange', label: 'Currency Exchange', icon: 'currency_exchange' },
        { path: 'statements', label: 'E-Statements', icon: 'description' },
        { path: 'locator', label: 'ATM & Branches', icon: 'location_on' },
        { path: 'support', label: 'Help & Support', icon: 'support_agent' },
      ]
    },
    {
      title: 'Account Control',
      items: [
        { path: 'profile', label: 'My Profile', icon: 'person' },
        { path: 'security', label: 'Security Panel', icon: 'verified_user' },
        { path: 'kyc', label: 'KYC Verification', icon: 'assignment_ind' },
      ]
    }
  ];

  mobileItems = [
    { path: 'dashboard', label: 'Home', icon: 'dashboard' },
    { path: 'transfer', label: 'Send', icon: 'send' },
    { path: 'accounts', label: 'Cards', icon: 'credit_card' },
    { path: 'history', label: 'Activity', icon: 'history' },
    { path: 'profile', label: 'Me', icon: 'person' },
  ];
}
