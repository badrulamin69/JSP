import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BankingCustomerService } from './banking-customer.service';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-customer-beneficiaries',
  standalone: true,
  imports: [CommonModule, MatIconModule, ReactiveFormsModule],
  template: `
    <div class="space-y-10 animate-in fade-in slide-in-from-right-4 duration-500">
      
      <!-- Page Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div>
           <h2 class="text-3xl font-bold text-slate-900 tracking-tight">Trusted Beneficiaries</h2>
           <p class="text-xs text-slate-500 mt-1 uppercase tracking-widest font-bold">Manage verified identities for instant mesh transfers</p>
        </div>
        <button (click)="showForm.set(true)" class="px-6 py-3 bg-slate-900 text-white rounded-2xl text-[10px] font-bold uppercase tracking-widest shadow-lg shadow-slate-900/10 hover:bg-slate-800 transition-all flex items-center gap-2">
           <mat-icon class="text-lg">person_add_alt</mat-icon>
           Add Beneficiary
        </button>
      </div>

      @if (showForm()) {
         <div class="bg-white rounded-[2.5rem] border border-slate-100 shadow-xl overflow-hidden animate-in zoom-in-95 duration-300">
            <div class="p-8 lg:p-10">
               <div class="flex justify-between items-center mb-8">
                  <h3 class="text-lg font-bold text-slate-900">Beneficiary Registry</h3>
                  <button (click)="showForm.set(false)" class="p-2 hover:bg-slate-50 rounded-full transition-colors"><mat-icon>close</mat-icon></button>
               </div>
               <form [formGroup]="benForm" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <div class="space-y-2">
                     <label class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Full Legal Name</label>
                     <input type="text" formControlName="name" placeholder="John Doe" class="w-full h-12 px-5 bg-slate-50 border border-slate-100 rounded-xl outline-none focus:border-emerald-500 transition-all font-bold text-sm">
                  </div>
                  <div class="space-y-2">
                     <label class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Bank Identifier</label>
                     <input type="text" formControlName="bank" placeholder="Global Mesh Bank" class="w-full h-12 px-5 bg-slate-50 border border-slate-100 rounded-xl outline-none focus:border-emerald-500 transition-all font-bold text-sm">
                  </div>
                  <div class="space-y-2">
                     <label class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Account Number / IBAN</label>
                     <input type="text" formControlName="account" placeholder="AC-902244111" class="w-full h-12 px-5 bg-slate-50 border border-slate-100 rounded-xl outline-none focus:border-emerald-500 transition-all font-bold font-mono text-sm">
                  </div>
                  <div class="lg:col-span-3 pt-6 text-center">
                     <button (click)="submitForm()" class="px-10 py-3 bg-emerald-600 text-white rounded-2xl text-[10px] font-bold uppercase tracking-widest shadow-lg shadow-emerald-600/10 hover:bg-emerald-700 transition-all">Verify & Save Identity</button>
                  </div>
               </form>
            </div>
         </div>
      }

      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
         @for (ben of customerService.beneficiaries(); track ben.id) {
            <div class="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm hover:shadow-md transition-all group group relative overflow-hidden">
               <div class="absolute -right-6 -top-6 w-20 h-20 bg-slate-50 rounded-full group-hover:scale-150 transition-transform duration-700 border border-slate-100"></div>
               
               <div class="relative z-10 flex flex-col items-center text-center">
                  <div class="w-20 h-20 bg-slate-100 rounded-3xl flex items-center justify-center mb-6 border border-slate-100 group-hover:bg-slate-900 transition-all">
                     <mat-icon class="text-3xl text-slate-400 group-hover:text-white">{{ ben.name.charAt(0) === 'A' ? 'business' : 'person' }}</mat-icon>
                  </div>
                  <h4 class="text-lg font-bold text-slate-900">{{ ben.name }}</h4>
                  <p class="text-[10px] font-bold text-emerald-600 uppercase tracking-widest mt-1">{{ ben.bank }}</p>
                  <p class="text-[10px] font-mono text-slate-400 mt-4 tracking-widest">{{ ben.account }}</p>
                  
                  <div class="mt-8 pt-8 border-t border-slate-50 flex gap-2 w-full">
                     <button class="flex-1 py-3 bg-slate-50 text-slate-600 rounded-xl text-[10px] font-bold uppercase tracking-widest hover:bg-slate-900 hover:text-white transition-all shadow-sm">Transfer</button>
                     <button class="p-3 bg-slate-50 text-slate-400 rounded-xl hover:bg-rose-50 hover:text-rose-500 transition-all shadow-sm">
                        <mat-icon class="text-sm">delete</mat-icon>
                     </button>
                  </div>
               </div>
            </div>
         }
      </div>

    </div>
  `
})
export class CustomerBeneficiaries {
  customerService = inject(BankingCustomerService);
  private fb = inject(FormBuilder);

  showForm = signal(false);
  benForm = this.fb.group({
    name: ['', Validators.required],
    bank: ['', Validators.required],
    account: ['', Validators.required]
  });

  submitForm() {
    if (this.benForm.valid) {
      const { name, bank, account } = this.benForm.value;
      this.customerService.addBeneficiary({
        name: name!,
        bank: bank!,
        account: account!,
        type: 'Domestic'
      }).subscribe(() => {
        this.showForm.set(false);
        this.benForm.reset();
      });
    }
  }
}
