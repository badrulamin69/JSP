import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BankingCustomerService } from './banking-customer.service';

@Component({
  selector: 'app-customer-statements',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-10 animate-in fade-in slide-in-from-right-4 duration-500">
      
      <!-- Page Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div>
           <h2 class="text-3xl font-bold text-slate-900 tracking-tight">E-Statements</h2>
           <p class="text-xs text-slate-500 mt-1 uppercase tracking-widest font-bold">Secure digital copies of your historical financial ledgers</p>
        </div>
        <div class="flex gap-3">
           <button class="px-6 py-3 bg-white text-slate-600 rounded-2xl text-[10px] font-bold uppercase tracking-widest border border-slate-100 shadow-sm hover:bg-slate-50 transition-all">Consolidated Audit</button>
           <button class="px-6 py-3 bg-slate-900 text-white rounded-2xl text-[10px] font-bold uppercase tracking-widest shadow-lg shadow-slate-900/10 hover:bg-slate-800 transition-all">Tax Reports</button>
        </div>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
         @for (month of months; track month) {
            <div class="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm hover:shadow-md transition-all group relative overflow-hidden">
               <div class="absolute -right-6 -top-6 w-20 h-20 bg-slate-50 rounded-full group-hover:scale-150 transition-transform duration-700"></div>
               
               <div class="relative z-10 flex flex-col h-full">
                  <div class="w-14 h-14 bg-slate-50 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-slate-900 transition-all">
                     <mat-icon class="text-slate-400 group-hover:text-white">description</mat-icon>
                  </div>
                  <h4 class="text-lg font-bold text-slate-900">{{ month }} 2024</h4>
                  <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">Status: Generated</p>
                  
                  <div class="mt-10 pt-8 border-t border-slate-50 flex items-center justify-between">
                     <div class="flex gap-2">
                        <mat-icon class="text-xs text-emerald-500">verified</mat-icon>
                        <span class="text-[9px] font-bold text-slate-400 uppercase tracking-widest italic">Digitally Signed</span>
                     </div>
                     <button class="p-3 bg-slate-50 text-slate-600 rounded-xl hover:bg-emerald-600 hover:text-white transition-all shadow-sm">
                        <mat-icon class="text-sm">download</mat-icon>
                     </button>
                  </div>
               </div>
            </div>
         }
      </div>

      <!-- Settings Hub -->
      <div class="bg-slate-900 rounded-[3rem] p-10 lg:p-14 text-white relative overflow-hidden group shadow-2xl">
         <div class="absolute -right-20 -top-20 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl group-hover:scale-125 transition-transform duration-1000"></div>
         <div class="relative z-10 grid grid-cols-1 md:grid-cols-2 gap-10 items-center">
            <div class="space-y-6">
               <h3 class="text-3xl font-bold tracking-tight leading-tight">Eco-Hub Subscription</h3>
               <p class="text-sm text-white/50 font-light leading-relaxed">You are currently receiving digital statements. By opting for E-Statements, you have saved approximately <span class="text-emerald-400 font-bold">12 trees</span> this year.</p>
               <button class="px-8 py-3 bg-white text-slate-900 rounded-2xl text-[10px] font-bold uppercase tracking-widest hover:scale-105 transition-all">Manage Preferences</button>
            </div>
            <div class="flex justify-start md:justify-end">
               <div class="w-32 h-32 rounded-full border-8 border-emerald-500/20 flex items-center justify-center p-2">
                  <div class="w-full h-full rounded-full border-8 border-emerald-500 flex items-center justify-center">
                     <mat-icon class="text-4xl text-emerald-500">park</mat-icon>
                  </div>
               </div>
            </div>
         </div>
      </div>

    </div>
  `
})
export class CustomerStatements {
  customerService = inject(BankingCustomerService);
  months = ['January', 'February', 'March', 'April', 'May'];
}
