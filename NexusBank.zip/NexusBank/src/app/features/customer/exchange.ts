import { Component, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BankingCustomerService } from './banking-customer.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-customer-exchange',
  standalone: true,
  imports: [CommonModule, MatIconModule, FormsModule],
  template: `
    <div class="space-y-10 animate-in fade-in slide-in-from-right-4 duration-500">
      
      <!-- Page Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div>
           <h2 class="text-3xl font-bold text-slate-900 tracking-tight">Currency Hub</h2>
           <p class="text-xs text-slate-500 mt-1 uppercase tracking-widest font-bold">Real-time global FX settlements with 0% markup</p>
        </div>
        <div class="flex gap-3">
           <button class="px-6 py-3 bg-white text-slate-600 rounded-2xl text-[10px] font-bold uppercase tracking-widest border border-slate-100 shadow-sm hover:bg-slate-50 transition-all">Hub Status</button>
           <button class="px-6 py-3 bg-slate-900 text-white rounded-2xl text-[10px] font-bold uppercase tracking-widest shadow-lg shadow-slate-900/10 hover:bg-slate-800 transition-all">Multi-Currency Wallet</button>
        </div>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-2 gap-10">
         <!-- Exchange Calculator -->
         <div class="bg-white rounded-[3rem] p-10 border border-slate-100 shadow-sm space-y-10 relative overflow-hidden">
            <div class="absolute -right-20 -top-20 w-60 h-60 bg-emerald-50 rounded-full blur-3xl opacity-50"></div>
            
            <h3 class="text-xl font-bold text-slate-900 relative z-10">Convert Assets</h3>
            
            <div class="space-y-2 relative z-10">
               <!-- From -->
               <div class="bg-slate-50 p-8 rounded-[2rem] border border-slate-100 space-y-4">
                  <div class="flex justify-between items-center text-[10px] font-bold uppercase tracking-widest text-slate-400">
                     <span>From Currency</span>
                     <span>Available: {{ sourceBalance() | currency:'USD' }}</span>
                  </div>
                  <div class="flex justify-between items-center gap-4">
                     <input type="number" [(ngModel)]="fromAmount" class="flex-1 bg-transparent text-4xl font-bold font-mono text-slate-900 outline-none border-none p-0 focus:ring-0">
                     <div class="flex items-center gap-3 bg-white px-4 py-2 rounded-xl border border-slate-100 shadow-sm">
                        <img src="https://flagcdn.com/w40/us.png" class="w-6 h-4 rounded-xs" alt="USA">
                        <span class="text-sm font-bold">USD</span>
                     </div>
                  </div>
               </div>

               <!-- Switch Icon -->
               <div class="flex justify-center -my-6 relative z-20">
                  <button class="w-12 h-12 bg-slate-900 text-white rounded-full flex items-center justify-center shadow-2xl border-4 border-white hover:scale-110 transition-transform shadow-slate-900/40">
                     <mat-icon>swap_vert</mat-icon>
                  </button>
               </div>

               <!-- To -->
               <div class="bg-slate-50 p-8 rounded-[2rem] border border-slate-100 space-y-4">
                  <div class="flex justify-between items-center text-[10px] font-bold uppercase tracking-widest text-slate-400">
                     <span>To Currency</span>
                     <span>Estimated Hub Value</span>
                  </div>
                  <div class="flex justify-between items-center gap-4">
                     <div class="flex-1 text-4xl font-bold font-mono text-slate-900">{{ toPrice() | number:'1.2-2' }}</div>
                     <select [(ngModel)]="targetCurrency" class="flex items-center gap-3 bg-white px-4 py-2 rounded-xl border border-slate-100 shadow-sm text-sm font-bold outline-none cursor-pointer">
                        @for (rate of rates; track rate.code) {
                           <option [value]="rate.code">{{ rate.code }} ({{ rate.symbol }})</option>
                        }
                     </select>
                  </div>
               </div>
            </div>

            <div class="bg-emerald-50 rounded-2xl p-6 border border-emerald-100 relative z-10">
               <div class="flex justify-between items-center mb-1">
                  <span class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Market Hub Rate</span>
                  <span class="text-xs font-bold text-emerald-600 font-mono italic">1 USD = {{ activeRate().rate }} {{ targetCurrency }}</span>
               </div>
               <p class="text-[9px] text-slate-400 font-bold uppercase tracking-widest">Rate locked for 60s • Guaranteed best mesh price</p>
            </div>

            <button class="w-full h-16 bg-slate-900 text-white rounded-3xl text-sm font-bold uppercase tracking-widest shadow-2xl hover:bg-slate-800 transition-all active:scale-95 relative z-10 flex items-center justify-center gap-2">
               Execute Exchange Hub <mat-icon>bolt</mat-icon>
            </button>
         </div>

         <!-- Market Watch -->
         <div class="space-y-8">
            <h3 class="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4 px-2">Global Mesh Rates</h3>
            <div class="bg-white rounded-[3rem] border border-slate-100 shadow-sm overflow-hidden min-h-[400px]">
               <div class="p-8">
                  <div class="space-y-6">
                     @for (rate of rates; track rate.code) {
                        <div class="flex items-center justify-between group cursor-pointer p-4 hover:bg-slate-50 rounded-2xl transition-all border border-transparent hover:border-slate-100">
                           <div class="flex items-center gap-4">
                              <div class="w-12 h-12 bg-slate-50 flex items-center justify-center rounded-2xl text-slate-900 font-bold group-hover:bg-slate-900 group-hover:text-white transition-all shadow-sm">
                                 {{ rate.symbol }}
                              </div>
                              <div>
                                 <p class="text-sm font-bold text-slate-900">{{ rate.name }}</p>
                                 <p class="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1 italic">{{ rate.code }} Zone</p>
                              </div>
                           </div>
                           <div class="text-right">
                              <p class="text-sm font-bold font-mono text-slate-900">{{ rate.rate }}</p>
                              <p class="text-[9px] text-emerald-500 font-bold uppercase tracking-widest mt-1">▲ {{ 0.22 }}%</p>
                           </div>
                        </div>
                     }
                  </div>
               </div>
            </div>
            
            <div class="bg-slate-900 p-8 rounded-[3rem] text-white shadow-xl relative overflow-hidden flex items-center gap-6">
               <div class="absolute -top-10 -right-10 w-32 h-32 bg-emerald-500/10 rounded-full blur-3xl"></div>
               <div class="w-14 h-14 bg-white/10 rounded-2xl flex items-center justify-center shrink-0 border border-white/5">
                  <mat-icon class="text-emerald-400">public</mat-icon>
               </div>
               <div>
                  <h4 class="text-xs font-bold leading-relaxed mb-1 italic uppercase tracking-wider">Smart Global Hub</h4>
                  <p class="text-[10px] text-white/40 font-light leading-relaxed uppercase tracking-widest">Connect international payroll for zero-spread institutional pricing.</p>
               </div>
            </div>
         </div>
      </div>

    </div>
  `
})
export class CustomerExchange {
  customerService = inject(BankingCustomerService);
  
  fromAmount = 1000;
  targetCurrency = 'EUR';

  sourceBalance = computed(() => this.customerService.totalBalance());

  rates = [
    { code: 'EUR', name: 'Euro Zone Hub', symbol: '€', rate: 0.92 },
    { code: 'GBP', name: 'Sterling Hub', symbol: '£', rate: 0.79 },
    { code: 'JPY', name: 'Yen High Hub', symbol: '¥', rate: 151.40 },
    { code: 'AUD', name: 'Aussie Prime Hub', symbol: 'A$', rate: 1.52 },
    { code: 'CHF', name: 'Swiss Secure Hub', symbol: 'Fr', rate: 0.91 }
  ];

  activeRate = computed(() => this.rates.find(r => r.code === this.targetCurrency) || this.rates[0]);
  toPrice = computed(() => this.fromAmount * this.activeRate().rate);
}
