import { Component, ChangeDetectionStrategy, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-security',
  standalone: true,
  imports: [MatIconModule],
  template: `
    <div class="pt-32 pb-20 bg-bank-navy text-white min-h-screen">
      <div class="max-w-7xl mx-auto px-4 sm:px-6">
        <!-- Hero -->
        <div class="max-w-3xl space-y-8 mb-24">
          <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-bank-blue/20 text-bank-blue text-xs font-bold tracking-widest uppercase">
            Military-Grade Protection
          </div>
          <h1 class="text-5xl md:text-7xl font-display font-bold tracking-tight leading-tight">
            Security is not <br> a feature. <span class="text-bank-blue">It’s our core.</span>
          </h1>
          <p class="text-xl text-slate-400 font-light leading-relaxed">
            We employ multi-layer encryption, real-time fraud monitoring, and biometric authentication to ensure your assets remain untouchable.
          </p>
        </div>

        <!-- Security Pillars -->
        <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-32">
          @for (pillar of pillars(); track pillar.title) {
            <div class="p-10 rounded-[2rem] bg-white/5 border border-white/10 hover:bg-white/10 transition-all group">
              <div class="w-16 h-16 rounded-2xl bg-bank-blue flex items-center justify-center mb-8 shadow-lg shadow-bank-blue/20 group-hover:scale-110 transition-transform">
                <mat-icon>{{ pillar.icon }}</mat-icon>
              </div>
              <h3 class="text-2xl font-bold mb-4">{{ pillar.title }}</h3>
              <p class="text-slate-400 leading-relaxed font-light">{{ pillar.description }}</p>
            </div>
          }
        </div>

        <!-- Compliance Section -->
        <div class="glass border-white/5 rounded-[3rem] p-8 md:p-20 flex flex-col lg:flex-row items-center gap-16">
          <div class="lg:w-1/2 space-y-8">
            <h2 class="text-4xl font-display font-bold">Global Compliance & Trust</h2>
            <p class="text-slate-400 font-light leading-relaxed">
              Smart Secure Bank is regulated by the Swiss Financial Market Supervisory Authority (FINMA) and adheres to strict international banking standards.
            </p>
            <div class="grid grid-cols-2 gap-4">
              @for (cert of ['ISO 27001', 'SOC 2 Type II', 'GDPR Compliant', 'PCI DSS Level 1']; track cert) {
                <div class="flex items-center gap-3 px-4 py-3 rounded-xl bg-white/5 border border-white/10">
                  <mat-icon class="text-emerald-500">verified</mat-icon>
                  <span class="text-sm font-medium">{{ cert }}</span>
                </div>
              }
            </div>
          </div>
          <div class="lg:w-1/2 relative">
             <div class="absolute inset-0 bg-bank-blue/20 blur-[100px]"></div>
             <div class="relative bg-bank-navy border border-white/10 p-8 rounded-[2rem] premium-shadow">
               <div class="space-y-6">
                 <div class="flex items-center justify-between">
                   <p class="text-xs font-bold text-slate-500 uppercase tracking-widest">Active Protection</p>
                   <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                 </div>
                 <div class="space-y-4">
                   @for (log of [
                     'Encrypted tunnel established',
                     'Biometric signature verified',
                     'Real-time fraud scan complete',
                     'Geographic anomaly check: Clear'
                   ]; track log) {
                     <div class="flex items-center gap-3 text-sm text-slate-400 font-mono">
                       <span class="text-bank-blue">></span>
                       <span>{{ log }}</span>
                     </div>
                   }
                 </div>
               </div>
             </div>
          </div>
        </div>
      </div>
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SecurityPage {
  pillars = signal([
    {
      icon: 'lock',
      title: 'End-to-End Encryption',
      description: 'Your data is encrypted at rest and in transit with AES-256 standards, ensuring zero-knowledge privacy.'
    },
    {
      icon: 'fingerprint',
      title: 'Biometric Auth',
      description: 'Multi-factor authentication using biometric signatures and hardware security keys for maximum access control.'
    },
    {
      icon: 'radar',
      title: 'Real-time Monitoring',
      description: 'AI-driven systems monitor every transaction for anomalies, instantly blocking suspicious activity globally.'
    }
  ]);
}
