import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-401',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './401.component.html',
  styleUrl: './401.component.css'
})
export class Error401Component {}