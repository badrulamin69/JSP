import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-403',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './403.component.html',
  styleUrl: './403.component.css'
})
export class Error403Component {}