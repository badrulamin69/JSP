import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-500',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './500.component.html',
  styleUrl: './500.component.css'
})
export class Error500Component {}