/** Barrel — routes import `./layout` for stable path */
export { AdminLayout } from './admin-layout.component';
