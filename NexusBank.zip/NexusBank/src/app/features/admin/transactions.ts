import { Component, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BankingAdminService } from './banking-admin.service';

@Component({
  selector: 'app-admin-transactions',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-8 animate-in fade-in slide-in-from-right-4 duration-500">
      <!-- Header -->
      <div class="bg-slate-900 rounded-[2.5rem] p-10 text-white shadow-2xl relative overflow-hidden">
        <div class="absolute top-0 right-0 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl"></div>
        <div class="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div>
            <h2 class="text-3xl font-display font-bold tracking-tight">Financial Ledger</h2>
            <p class="text-slate-400 font-light mt-1">Institutional-grade tracking for all global asset movements.</p>
          </div>
          <div class="flex gap-3">
             <div class="bg-white/5 border border-white/10 p-4 rounded-2xl">
                <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Total Volume (24h)</p>
                <p class="text-xl font-bold font-mono">$1.2M</p>
             </div>
             <div class="bg-white/5 border border-white/10 p-4 rounded-2xl">
                <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Success Rate</p>
                <p class="text-xl font-bold font-mono text-emerald-400">99.9%</p>
             </div>
          </div>
        </div>
      </div>

      <!-- Filters -->
      <div class="flex flex-wrap gap-4 items-center justify-between">
         <div class="flex gap-2">
            @for (filter of filters; track filter) {
              <button 
                (click)="activeFilter.set(filter)" 
                [class]="'px-6 py-2.5 rounded-xl text-xs font-bold uppercase tracking-widest transition-all ' + 
                (activeFilter() === filter ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/20' : 'bg-white text-slate-500 hover:bg-slate-50 border border-slate-100')"
              >
                {{ filter }}
              </button>
            }
         </div>
         <div class="flex items-center gap-3">
            <span class="text-xs font-bold text-slate-400 uppercase tracking-widest">Export As:</span>
            <button class="bg-white p-2 rounded-lg border border-slate-100 hover:bg-slate-50 text-slate-600 transition-all">CSV</button>
            <button class="bg-white p-2 rounded-lg border border-slate-100 hover:bg-slate-50 text-slate-600 transition-all">PDF</button>
         </div>
      </div>

      <!-- Transaction Grid -->
      <div class="grid gap-4">
        @for (tx of filteredTransactions(); track tx.id) {
          <div class="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm hover:shadow-xl hover:translate-x-2 transition-all duration-300 group">
             <div class="flex flex-col sm:flex-row items-center gap-6">
                <!-- Icon -->
                <div [class]="'w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 ' + getTypeBg(tx.type)">
                   <mat-icon [class]="getTypeColor(tx.type)">{{ getTypeIcon(tx.type) }}</mat-icon>
                </div>

                <!-- Info -->
                <div class="flex-1 text-center sm:text-left">
                   <p class="text-sm font-bold text-slate-900">{{ tx.description }}</p>
                   <p class="text-[10px] text-slate-400 uppercase font-bold tracking-widest mt-1">TRX ID: {{ tx.id }} • {{ tx.date | date:'medium' }}</p>
                </div>

                <!-- Status -->
                <div class="px-6 py-2 border-l border-r border-slate-50 hidden md:block">
                   <div class="flex flex-col items-center">
                      <span [class]="'text-[10px] font-bold uppercase tracking-widest mb-1 ' + getStatusColor(tx.status)">{{ tx.status }}</span>
                      <span class="text-[9px] text-slate-400 font-bold uppercase italic">Tier 1 Verified</span>
                   </div>
                </div>

                <!-- Amount -->
                <div class="text-right sm:min-w-[150px]">
                   <p class="text-xl font-bold font-mono text-slate-900">{{ tx.type === 'transfer' ? '-' : '+' }}{{ tx.amount | currency:'USD' }}</p>
                   <p class="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Settled Balance</p>
                </div>

                <!-- Action -->
                <button class="p-3 bg-slate-50 rounded-xl text-slate-400 hover:bg-blue-600 hover:text-white transition-all opacity-0 group-hover:opacity-100">
                   <mat-icon>more_vert</mat-icon>
                </button>
             </div>
          </div>
        }
      </div>
    </div>
  `
})
export class AdminTransactions {
  private service = inject(BankingAdminService);
  
  filters = ['All', 'Transfer', 'Deposit', 'Withdrawal', 'Loan'];
  activeFilter = signal('All');

  transactions = this.service.transactions;

  filteredTransactions = computed(() => {
    const filter = this.activeFilter().toLowerCase();
    if (filter === 'all') return this.transactions();
    return this.transactions().filter(t => t.type === filter);
  });

  getTypeIcon(type: string) {
    switch (type) {
      case 'transfer': return 'swap_horiz';
      case 'deposit': return 'south_west';
      case 'withdrawal': return 'north_east';
      case 'loan': return 'handshake';
      default: return 'payment';
    }
  }

  getTypeBg(type: string) {
    switch (type) {
      case 'transfer': return 'bg-blue-50';
      case 'deposit': return 'bg-emerald-50';
      case 'withdrawal': return 'bg-rose-50';
      case 'loan': return 'bg-purple-50';
      default: return 'bg-slate-50';
    }
  }

  getTypeColor(type: string) {
    switch (type) {
      case 'transfer': return 'text-blue-600';
      case 'deposit': return 'text-emerald-600';
      case 'withdrawal': return 'text-rose-600';
      case 'loan': return 'text-purple-600';
      default: return 'text-slate-600';
    }
  }

  getStatusColor(status: string) {
    switch (status) {
      case 'completed': return 'text-emerald-500';
      case 'pending': return 'text-amber-500';
      case 'failed': return 'text-rose-500';
      default: return 'text-slate-500';
    }
  }
}
