import {
  Component,
  inject,
  viewChild,
  ElementRef,
  AfterViewInit,
  PLATFORM_ID,
  computed,
  OnInit,
} from '@angular/core';
import { isPlatformBrowser, CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { BankingAdminService } from './banking-admin.service';
import { Chart, registerables } from 'chart.js';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, MatIconModule, RouterLink],
  templateUrl: './admin-dashboard.component.html',
})
export class AdminDashboard implements OnInit, AfterViewInit {
  private static chartRegistered = false;
  private service = inject(BankingAdminService);
  private platformId = inject(PLATFORM_ID);

  revenueChart = viewChild<ElementRef<HTMLCanvasElement>>('revenueChart');

  formattedKpiStats = computed(() => {
    const s = this.service.stats();
    return [
      {
        label: 'Total AUM',
        value: '$' + (s.totalAUM / 1000).toFixed(1) + 'k',
        icon: 'payments',
        trend: '+8.2%',
        isPositive: true,
        bgClass: 'bg-blue-50',
        iconClass: 'text-blue-600',
      },
      {
        label: 'Active Customers',
        value: String(s.activeUsers),
        icon: 'group',
        trend: '+4.1%',
        isPositive: true,
        bgClass: 'bg-emerald-50',
        iconClass: 'text-emerald-600',
      },
      {
        label: 'Growth (target)',
        value: s.growthRate,
        icon: 'trending_up',
        trend: '+0.5%',
        isPositive: true,
        bgClass: 'bg-purple-50',
        iconClass: 'text-purple-600',
      },
      {
        label: 'Liquidity index',
        value: s.liquidity,
        icon: 'account_balance',
        trend: '-1.2%',
        isPositive: false,
        bgClass: 'bg-orange-50',
        iconClass: 'text-orange-600',
      },
    ];
  });

  securityAlerts = computed(() => {
    const rows = this.service.auditLogs();
    const iconFor = (action: string) =>
      action.includes('LOGIN') ? 'security' : action.includes('UPDATE') ? 'edit' : 'info';
    return rows.slice(0, 5).map((a) => ({
      id: a.id,
      title: a.action,
      subtitle: `${a.actor} · ${a.resource} · ${new Date(a.timestamp).toLocaleString()}`,
      icon: iconFor(a.action),
      bg: 'bg-blue-500/20',
      iconClass: 'text-blue-300',
    }));
  });

  quickActions = [
    { label: 'Customers', icon: 'group', link: '/admin/customers' },
    { label: 'Transactions', icon: 'swap_horiz', link: '/admin/transactions' },
    { label: 'Loans', icon: 'payments', link: '/admin/loans' },
    { label: 'Branches', icon: 'account_balance', link: '/admin/branches' },
    { label: 'Support', icon: 'support_agent', link: '/admin/support-tickets' },
    { label: 'Audit', icon: 'history_edu', link: '/admin/audit' },
  ];

  ngOnInit() {
    this.service.loadAuditLogs();
  }

  ngAfterViewInit() {
    if (isPlatformBrowser(this.platformId)) {
      this.initCharts();
    }
  }

  private initCharts() {
    if (isPlatformBrowser(this.platformId) && !AdminDashboard.chartRegistered) {
      Chart.register(...registerables);
      AdminDashboard.chartRegistered = true;
    }
    const ctx = this.revenueChart()?.nativeElement?.getContext('2d');
    if (!ctx) return;

    new Chart(ctx, {
      type: 'line',
      data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [
          {
            label: 'Deposits',
            data: [65, 59, 80, 81, 56, 95],
            borderColor: '#2563eb',
            backgroundColor: 'rgba(37, 99, 235, 0.1)',
            fill: true,
            tension: 0.4,
            borderWidth: 3,
            pointRadius: 0,
            pointHoverRadius: 6,
          },
          {
            label: 'Withdrawals',
            data: [28, 48, 40, 19, 86, 27],
            borderColor: '#10b981',
            backgroundColor: 'rgba(16, 185, 129, 0.1)',
            fill: true,
            tension: 0.4,
            borderWidth: 3,
            pointRadius: 0,
            pointHoverRadius: 6,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
        },
        scales: {
          y: {
            grid: { display: false },
            ticks: { color: '#94a3b8', font: { size: 10 } },
          },
          x: {
            grid: { display: false },
            ticks: { color: '#94a3b8', font: { size: 10 } },
          },
        },
      },
    });
  }
}
