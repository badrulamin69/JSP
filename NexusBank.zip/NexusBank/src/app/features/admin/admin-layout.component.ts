import { Component, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { SessionService } from '../../core/services/session.service';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-admin-layout',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink, RouterLinkActive, MatIconModule],
  templateUrl: './admin-layout.component.html',
  styleUrl: './admin-layout.component.scss',
})
export class AdminLayout {
  session = inject(SessionService);
  auth = inject(AuthService);
  isSidebarOpen = signal(true);

  menuItems = [
    { path: 'dashboard', label: 'Overview', icon: 'dashboard', badge: 'Live' },
    { path: 'users', label: 'User Management', icon: 'manage_accounts' },
    { path: 'customers', label: 'Customers', icon: 'group' },
    { path: 'employees', label: 'Employees', icon: 'badge' },
    { path: 'accounts', label: 'Accounts', icon: 'account_balance_wallet' },
    { path: 'transactions', label: 'Transactions', icon: 'swap_horiz' },
    { path: 'support-tickets', label: 'Support Tickets', icon: 'support_agent' },
    { path: 'audit', label: 'Audit Logs', icon: 'history_edu' },
  ];

  assetItems = [
    { path: 'loans', label: 'Loans & Credit', icon: 'payments' },
    { path: 'fixed-deposits', label: 'Fixed Deposits', icon: 'savings' },
    { path: 'investments', label: 'Investments', icon: 'trending_up' },
    { path: 'branches', label: 'Branches', icon: 'account_balance' },
    { path: 'atms', label: 'ATM Network', icon: 'atm' },
    { path: 'reports', label: 'Reports', icon: 'analytics' },
    { path: 'roles', label: 'Roles & RBAC', icon: 'admin_panel_settings' },
    { path: 'settings', label: 'Settings', icon: 'settings' },
  ];

  toggleSidebar() {
    this.isSidebarOpen.update((v) => !v);
  }
}
