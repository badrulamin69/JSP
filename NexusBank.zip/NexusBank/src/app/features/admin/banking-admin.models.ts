export interface User {
  id: string;
  name: string;
  email: string;
  password?: string;
  role: 'admin' | 'employee' | 'customer';
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  status: 'active' | 'pending' | 'suspended';
  balance: number;
  avatar: string;
  role: string;
  kycStatus?: string;
  phone?: string;
  address?: string;
}

export interface Transaction {
  id: string;
  customerId: string;
  type: string;
  amount: number;
  status: 'completed' | 'pending' | 'failed';
  date: string;
  description: string;
  category?: string;
}

export interface Employee {
  id: string;
  name: string;
  email: string;
  role: string;
  branchId: string;
  department: string;
  status: 'active' | 'inactive';
}

export interface Branch {
  id: string;
  name: string;
  location: string;
  status: string;
  manager: string;
  phone: string;
}

export interface Atm {
  id: string;
  name: string;
  status: string;
  cashLevel: number;
  location: string;
  type: string;
}

export interface Loan {
  id: string;
  customerId: string;
  amount: number;
  type: string;
  status: string;
  interest: number;
  duration: number;
  remainingAmount: number;
  nextPayment: string;
}

export interface LoanApplication {
  id: string;
  customerId: string;
  amount: number;
  type: string;
  status: string;
  date: string;
}

export interface FixedDeposit {
  id: string;
  customerId: string;
  amount: number;
  interestRate: number;
  durationMonths: number;
  startDate: string;
  maturityDate: string;
  status: string;
}

export interface Investment {
  id: string;
  customerId: string;
  name: string;
  amount: number;
  currentValue: number;
  growth: number;
  type: string;
}

export interface BankAccount {
  id: string;
  customerId: string;
  type: string;
  balance: number;
  currency: string;
  accountNumber: string;
  status: string;
}

export interface AuditLog {
  id: string;
  action: string;
  actor: string;
  resource: string;
  timestamp: string;
  status: string;
  details: string;
}

export interface ReportRow {
  id: string;
  title: string;
  category: string;
  generatedAt: string;
  period: string;
}

export interface SupportTicket {
  id: string;
  customerId: string;
  subject: string;
  status: string;
  date: string;
  priority: string;
  lastReply?: string;
}

export interface AppSettings {
  id: string;
  defaultCurrency: string;
  timezone: string;
  sessionTimeoutMinutes: number;
  maintenanceMode: boolean;
  fraudAlertsEnabled: boolean;
}
