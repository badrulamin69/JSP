import { Component, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BankingAdminService, Customer } from './banking-admin.service';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-admin-customers',
  standalone: true,
  imports: [CommonModule, MatIconModule, ReactiveFormsModule],
  template: `
    <div class="space-y-8 animate-in slide-in-from-bottom-4 duration-500">
      <!-- Header -->
      <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-8 rounded-[2rem] border border-slate-100 shadow-sm">
        <div>
          <h2 class="text-2xl font-display font-bold text-slate-900">Customer Repository</h2>
          <p class="text-slate-500 text-sm font-light">Manage and monitor {{ filteredCustomers().length }} institutional and retail clients.</p>
        </div>
        <button (click)="openAddModal()" class="px-6 py-3 bg-blue-600 text-white rounded-2xl font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-500/20 active:scale-95 flex items-center gap-2">
          <mat-icon>person_add</mat-icon>
          Onboard Client
        </button>
      </div>

      <!-- Filters & Search -->
      <div class="bg-white p-4 rounded-3xl border border-slate-100 shadow-sm flex flex-col md:flex-row gap-4 items-center">
         <div class="flex-1 w-full bg-slate-50 rounded-2xl px-4 py-2 flex items-center gap-3 border border-slate-100 focus-within:border-blue-500 focus-within:ring-2 focus-within:ring-blue-500/10 transition-all">
            <mat-icon class="text-slate-400">search</mat-icon>
            <input 
               type="text" 
               [value]="searchTerm()" 
               (input)="updateSearch($event)"
               placeholder="Search by name, email, or account ID..." 
               class="bg-transparent border-none outline-hidden text-sm w-full font-medium"
            >
         </div>
         <div class="flex items-center gap-2 w-full md:w-auto">
            <select class="bg-slate-50 border border-slate-100 rounded-2xl px-4 py-2.5 text-xs font-bold text-slate-600 outline-hidden focus:border-blue-500 transition-all">
               <option>All Status</option>
               <option>Active</option>
               <option>Pending</option>
               <option>Suspended</option>
            </select>
            <button class="p-2.5 bg-slate-50 border border-slate-100 rounded-2xl text-slate-500 hover:bg-slate-100 transition-all">
               <mat-icon>filter_list</mat-icon>
            </button>
         </div>
      </div>

      <!-- Data Table -->
      <div class="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm overflow-hidden">
        <div class="overflow-x-auto">
          <table class="w-full text-left border-collapse">
            <thead>
              <tr class="border-b border-slate-50 bg-slate-50/50">
                <th class="px-8 py-5 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Client Identity</th>
                <th class="px-8 py-5 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Type / Tier</th>
                <th class="px-8 py-5 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-right">Liquidity</th>
                <th class="px-8 py-5 text-[10px] font-bold text-slate-400 uppercase tracking-widest">State</th>
                <th class="px-8 py-5 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-center">Actions</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-50">
              @for (client of filteredCustomers(); track client.id) {
                <tr class="hover:bg-slate-50/80 transition-colors group">
                  <td class="px-8 py-5">
                    <div class="flex items-center gap-4">
                      <img [src]="client.avatar" class="w-10 h-10 rounded-xl border border-slate-100 group-hover:scale-110 transition-transform" alt="">
                      <div>
                        <p class="text-sm font-bold text-slate-900 leading-tight">{{ client.name }}</p>
                        <p class="text-[10px] text-slate-500 font-medium">{{ client.email }}</p>
                      </div>
                    </div>
                  </td>
                  <td class="px-8 py-5">
                    <div class="flex flex-col">
                      <span class="text-xs font-bold text-slate-700">{{ client.role }} Account</span>
                      <span class="text-[10px] text-slate-400 font-medium lowercase">id: {{ client.id }}</span>
                    </div>
                  </td>
                  <td class="px-8 py-5 text-right font-mono font-bold text-slate-900">
                    {{ client.balance | currency:'USD' }}
                  </td>
                  <td class="px-8 py-5">
                    <span [class]="'px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ' + getStatusClass(client.status)">
                      {{ client.status }}
                    </span>
                  </td>
                  <td class="px-8 py-5">
                    <div class="flex items-center justify-center gap-2">
                       <button (click)="openEditModal(client)" class="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-all">
                          <mat-icon class="text-lg">edit</mat-icon>
                       </button>
                       <button class="p-2 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-xl transition-all">
                          <mat-icon class="text-lg">visibility</mat-icon>
                       </button>
                       <button (click)="deleteClient(client.id)" class="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-all">
                          <mat-icon class="text-lg">delete</mat-icon>
                       </button>
                    </div>
                  </td>
                </tr>
              } @empty {
                <tr>
                  <td colspan="5" class="px-8 py-20 text-center">
                    <div class="flex flex-col items-center gap-4">
                      <div class="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center text-slate-200">
                        <mat-icon class="text-5xl">person_off</mat-icon>
                      </div>
                      <p class="text-slate-400 font-medium">No clients found matching your search.</p>
                    </div>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

      <!-- Add/Edit Modal (Simple implementation) -->
      @if (isModalOpen()) {
        <div class="fixed inset-0 z-100 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-300">
           <div class="bg-white w-full max-w-lg rounded-[2.5rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300">
              <div class="p-8 border-b border-slate-100 flex justify-between items-center">
                 <h3 class="text-xl font-display font-bold text-slate-900">Client Operations</h3>
                 <button (click)="closeModal()" class="p-2 text-slate-400 hover:bg-slate-50 rounded-xl transition-all">
                    <mat-icon>close</mat-icon>
                 </button>
              </div>
              
              <form [formGroup]="clientForm" (ngSubmit)="saveClient()" class="p-8 space-y-6">
                 <div>
                    <label for="clientName" class="text-[10px] uppercase font-bold tracking-widest text-slate-400 mb-2 block">Full Legal Name</label>
                    <input id="clientName" type="text" formControlName="name" class="w-full bg-slate-50 border border-slate-100 rounded-2xl px-5 py-3 outline-hidden focus:border-blue-500 focus:ring-4 focus:ring-blue-500/5 transition-all text-sm font-medium">
                 </div>
                 <div class="grid grid-cols-2 gap-4">
                    <div>
                      <label for="clientEmail" class="text-[10px] uppercase font-bold tracking-widest text-slate-400 mb-2 block">E-mail Address</label>
                      <input id="clientEmail" type="email" formControlName="email" class="w-full bg-slate-50 border border-slate-100 rounded-2xl px-5 py-3 outline-hidden focus:border-blue-500 transition-all text-sm font-medium">
                    </div>
                    <div>
                      <label for="clientTier" class="text-[10px] uppercase font-bold tracking-widest text-slate-400 mb-2 block">Account Tier</label>
                      <select id="clientTier" formControlName="role" class="w-full bg-slate-50 border border-slate-100 rounded-2xl px-5 py-3 outline-hidden focus:border-blue-500 transition-all text-sm font-medium">
                         <option value="Premium">Premium</option>
                         <option value="Elite">Elite</option>
                         <option value="Standard">Standard</option>
                         <option value="Corporate">Corporate</option>
                      </select>
                    </div>
                 </div>
                 
                 <div class="flex gap-4 pt-4">
                    <button type="button" (click)="closeModal()" class="flex-1 py-4 text-slate-600 font-bold hover:bg-slate-50 rounded-2xl transition-all">Cancel</button>
                    <button type="submit" [disabled]="clientForm.invalid" class="flex-1 py-4 bg-blue-600 text-white font-bold rounded-2xl shadow-lg shadow-blue-500/20 hover:bg-blue-700 transition-all active:scale-95 disabled:opacity-50">Persist Data</button>
                 </div>
              </form>
           </div>
        </div>
      }
    </div>
  `
})
export class AdminCustomers {
  private service = inject(BankingAdminService);
  private fb = inject(FormBuilder);
  
  searchTerm = signal('');
  isModalOpen = signal(false);
  editingId = signal<string | null>(null);

  customers = this.service.customers;

  filteredCustomers = computed(() => {
    const term = this.searchTerm().toLowerCase();
    return this.customers().filter(c => 
      c.name.toLowerCase().includes(term) || 
      c.email.toLowerCase().includes(term) ||
      c.id.includes(term)
    );
  });

  clientForm = this.fb.group({
    name: ['', [Validators.required]],
    email: ['', [Validators.required, Validators.email]],
    role: ['Premium', [Validators.required]],
    status: ['active' as 'active' | 'pending' | 'suspended']
  });

  updateSearch(event: Event) {
    const input = event.target as HTMLInputElement;
    this.searchTerm.set(input.value);
  }

  getStatusClass(status: string) {
    switch (status) {
      case 'active': return 'bg-emerald-50 text-emerald-600 border border-emerald-100';
      case 'pending': return 'bg-amber-50 text-amber-600 border border-amber-100';
      case 'suspended': return 'bg-rose-50 text-rose-600 border border-rose-100';
      default: return 'bg-slate-50 text-slate-600';
    }
  }

  openAddModal() {
    this.editingId.set(null);
    this.clientForm.reset({ role: 'Premium', status: 'active' });
    this.isModalOpen.set(true);
  }

  openEditModal(client: Customer) {
    this.editingId.set(client.id);
    this.clientForm.patchValue({
      name: client.name,
      email: client.email,
      role: client.role,
      status: client.status
    });
    this.isModalOpen.set(true);
  }

  closeModal() {
    this.isModalOpen.set(false);
  }

  saveClient() {
    if (this.clientForm.valid) {
      const formValue = this.clientForm.value;
      const id = this.editingId();
      
      if (id) {
        this.service.updateCustomer(id, formValue as Partial<Customer>).subscribe(() => this.closeModal());
      } else {
        this.service.addCustomer({
          name: formValue.name!,
          email: formValue.email!,
          role: formValue.role!,
          status: 'active',
          balance: 0,
          avatar: `https://i.pravatar.cc/150?u=${Math.random()}`
        }).subscribe(() => this.closeModal());
      }
    }
  }

  deleteClient(id: string) {
    if (confirm('Are you sure you want to offboard this client? This action is recorded in audit logs.')) {
      this.service.deleteCustomer(id).subscribe();
    }
  }
}
