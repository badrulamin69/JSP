import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-atms',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './atms.component.html',
  styleUrl: './atms.component.css'
})
export class AtmsComponent {}