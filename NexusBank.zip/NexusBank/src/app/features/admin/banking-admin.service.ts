import { Injectable, signal, computed, inject } from '@angular/core';
import { ApiService } from '../../core/services/api.service';
import { Api } from '../../core/constants/api.constant';
import { finalize, forkJoin, tap } from 'rxjs';
import type {
  User,
  Customer,
  Transaction,
  Employee,
  Branch,
  Atm,
  Loan,
  LoanApplication,
  FixedDeposit,
  Investment,
  BankAccount,
  AuditLog,
  ReportRow,
  SupportTicket,
  AppSettings,
} from './banking-admin.models';

export type {
  User,
  Customer,
  Transaction,
  Employee,
  Branch,
  Atm,
  Loan,
  LoanApplication,
  FixedDeposit,
  Investment,
  BankAccount,
  AuditLog,
  ReportRow,
  SupportTicket,
  AppSettings,
} from './banking-admin.models';

@Injectable({
  providedIn: 'root',
})
export class BankingAdminService {
  private api = inject(ApiService);

  private usersSignal = signal<User[]>([]);
  private customersSignal = signal<Customer[]>([]);
  private transactionsSignal = signal<Transaction[]>([]);
  private employeesSignal = signal<Employee[]>([]);
  private branchesSignal = signal<Branch[]>([]);
  private atmsSignal = signal<Atm[]>([]);
  private loansSignal = signal<Loan[]>([]);
  private loanApplicationsSignal = signal<LoanApplication[]>([]);
  private fixedDepositsSignal = signal<FixedDeposit[]>([]);
  private investmentsSignal = signal<Investment[]>([]);
  private accountsSignal = signal<BankAccount[]>([]);
  private auditLogsSignal = signal<AuditLog[]>([]);
  private reportsSignal = signal<ReportRow[]>([]);
  private supportTicketsSignal = signal<SupportTicket[]>([]);
  private appSettingsSignal = signal<AppSettings | null>(null);

  private loadingSignal = signal(false);

  users = this.usersSignal.asReadonly();
  customers = this.customersSignal.asReadonly();
  transactions = this.transactionsSignal.asReadonly();
  employees = this.employeesSignal.asReadonly();
  branches = this.branchesSignal.asReadonly();
  atms = this.atmsSignal.asReadonly();
  loans = this.loansSignal.asReadonly();
  loanApplications = this.loanApplicationsSignal.asReadonly();
  fixedDeposits = this.fixedDepositsSignal.asReadonly();
  investments = this.investmentsSignal.asReadonly();
  accounts = this.accountsSignal.asReadonly();
  auditLogs = this.auditLogsSignal.asReadonly();
  reports = this.reportsSignal.asReadonly();
  supportTickets = this.supportTicketsSignal.asReadonly();
  appSettings = this.appSettingsSignal.asReadonly();

  isLoading = this.loadingSignal.asReadonly();

  totalBalance = computed(() =>
    this.customersSignal().reduce((acc, c) => acc + c.balance, 0),
  );

  stats = computed(() => ({
    totalAUM: this.totalBalance(),
    activeUsers: this.customersSignal().filter((c) => c.status === 'active').length,
    userCount: this.usersSignal().length,
    growthRate: '+12.5%',
    liquidity: '84.2%',
  }));

  constructor() {
    this.refreshCoreDashboardData();
  }

  /** Loads datasets needed for KPI widgets & primary ops screens */
  refreshCoreDashboardData() {
    this.loadingSignal.set(true);
    forkJoin({
      users: this.api.get<User[]>(Api.USERS),
      customers: this.api.get<Customer[]>(Api.CUSTOMERS),
      transactions: this.api.get<Transaction[]>(Api.TRANSACTIONS),
    })
      .pipe(finalize(() => this.loadingSignal.set(false)))
      .subscribe(({ users, customers, transactions }) => {
        this.usersSignal.set(users);
        this.customersSignal.set(customers);
        this.transactionsSignal.set(transactions);
      });
  }

  loadEmployees() {
    this.api.get<Employee[]>(Api.EMPLOYEES).subscribe((rows) => this.employeesSignal.set(rows));
  }

  addEmployee(row: Omit<Employee, 'id'>) {
    return this.api.post<Employee>(Api.EMPLOYEES, row).pipe(
      tap((created) => this.employeesSignal.update((list) => [created, ...list])),
    );
  }

  updateEmployee(id: string, body: Partial<Employee>) {
    return this.api.patch<Employee>(`${Api.EMPLOYEES}/${id}`, body).pipe(
      tap((updated) =>
        this.employeesSignal.update((list) => list.map((e) => (e.id === id ? updated : e))),
      ),
    );
  }

  deleteEmployee(id: string) {
    return this.api.delete<void>(`${Api.EMPLOYEES}/${id}`).pipe(
      tap(() => this.employeesSignal.update((list) => list.filter((e) => e.id !== id))),
    );
  }

  loadBranches() {
    this.api.get<Branch[]>(Api.BRANCHES).subscribe((rows) => this.branchesSignal.set(rows));
  }

  updateBranch(id: string, body: Partial<Branch>) {
    return this.api.patch<Branch>(`${Api.BRANCHES}/${id}`, body).pipe(
      tap((updated) =>
        this.branchesSignal.update((list) => list.map((b) => (b.id === id ? updated : b))),
      ),
    );
  }

  loadAtms() {
    this.api.get<Atm[]>(Api.ATMS).subscribe((rows) => this.atmsSignal.set(rows));
  }

  updateAtm(id: string, body: Partial<Atm>) {
    return this.api.patch<Atm>(`${Api.ATMS}/${id}`, body).pipe(
      tap((updated) =>
        this.atmsSignal.update((list) => list.map((a) => (a.id === id ? updated : a))),
      ),
    );
  }

  loadLoansAndApplications() {
    forkJoin({
      loans: this.api.get<Loan[]>(Api.LOANS),
      apps: this.api.get<LoanApplication[]>(Api.LOAN_APPLICATIONS),
    }).subscribe(({ loans, apps }) => {
      this.loansSignal.set(loans);
      this.loanApplicationsSignal.set(apps);
    });
  }

  patchLoanApplication(id: string, body: Partial<LoanApplication>) {
    return this.api.patch<LoanApplication>(`${Api.LOAN_APPLICATIONS}/${id}`, body).pipe(
      tap((updated) =>
        this.loanApplicationsSignal.update((list) =>
          list.map((x) => (x.id === id ? updated : x)),
        ),
      ),
    );
  }

  loadFixedDeposits() {
    this.api
      .get<FixedDeposit[]>(Api.FIXED_DEPOSITS)
      .subscribe((rows) => this.fixedDepositsSignal.set(rows));
  }

  loadInvestments() {
    this.api
      .get<Investment[]>(Api.INVESTMENTS)
      .subscribe((rows) => this.investmentsSignal.set(rows));
  }

  loadAccounts() {
    this.api.get<BankAccount[]>(Api.ACCOUNTS).subscribe((rows) => this.accountsSignal.set(rows));
  }

  patchAccount(id: string, body: Partial<BankAccount>) {
    return this.api.patch<BankAccount>(`${Api.ACCOUNTS}/${id}`, body).pipe(
      tap((updated) =>
        this.accountsSignal.update((list) => list.map((a) => (a.id === id ? updated : a))),
      ),
    );
  }

  loadAuditLogs() {
    this.api.get<AuditLog[]>(Api.AUDIT_LOGS).subscribe((rows) => this.auditLogsSignal.set(rows));
  }

  loadReports() {
    this.api.get<ReportRow[]>(Api.REPORTS).subscribe((rows) => this.reportsSignal.set(rows));
  }

  loadSupportTickets() {
    this.api
      .get<SupportTicket[]>(Api.SUPPORT_TICKETS)
      .subscribe((rows) => this.supportTicketsSignal.set(rows));
  }

  patchSupportTicket(id: string, body: Partial<SupportTicket>) {
    return this.api.patch<SupportTicket>(`${Api.SUPPORT_TICKETS}/${id}`, body).pipe(
      tap((updated) =>
        this.supportTicketsSignal.update((list) =>
          list.map((t) => (t.id === id ? updated : t)),
        ),
      ),
    );
  }

  loadAppSettings() {
    this.api.get<AppSettings[]>(Api.APP_SETTINGS).subscribe((rows) => {
      const global = rows.find((r) => r.id === 'global') ?? rows[0] ?? null;
      this.appSettingsSignal.set(global);
    });
  }

  saveAppSettings(body: AppSettings) {
    return this.api.put<AppSettings>(`${Api.APP_SETTINGS}/${body.id}`, body).pipe(
      tap((saved) => this.appSettingsSignal.set(saved)),
    );
  }

  // --- Users (admin RBAC users table) ---
  loadUsers() {
    this.api.get<User[]>(Api.USERS).subscribe((users) => this.usersSignal.set(users));
  }

  addUser(user: Omit<User, 'id'>) {
    return this.api.post<User>(Api.USERS, user).pipe(
      tap((newUser) => this.usersSignal.update((list) => [newUser, ...list])),
    );
  }

  updateUser(id: string, updates: Partial<User>) {
    return this.api.patch<User>(`${Api.USERS}/${id}`, updates).pipe(
      tap((updated) =>
        this.usersSignal.update((list) => list.map((u) => (u.id === id ? updated : u))),
      ),
    );
  }

  deleteUser(id: string) {
    return this.api.delete<void>(`${Api.USERS}/${id}`).pipe(
      tap(() => this.usersSignal.update((list) => list.filter((u) => u.id !== id))),
    );
  }

  loadCustomers() {
    this.api
      .get<Customer[]>(Api.CUSTOMERS)
      .subscribe((c) => this.customersSignal.set(c));
  }

  addCustomer(customer: Omit<Customer, 'id'>) {
    return this.api.post<Customer>(Api.CUSTOMERS, customer).pipe(
      tap((newC) => this.customersSignal.update((list) => [newC, ...list])),
    );
  }

  updateCustomer(id: string, updates: Partial<Customer>) {
    return this.api.patch<Customer>(`${Api.CUSTOMERS}/${id}`, updates).pipe(
      tap((updated) =>
        this.customersSignal.update((list) => list.map((c) => (c.id === id ? updated : c))),
      ),
    );
  }

  deleteCustomer(id: string) {
    return this.api.delete<void>(`${Api.CUSTOMERS}/${id}`).pipe(
      tap(() => this.customersSignal.update((list) => list.filter((c) => c.id !== id))),
    );
  }

  loadTransactions() {
    this.api
      .get<Transaction[]>(Api.TRANSACTIONS)
      .subscribe((t) => this.transactionsSignal.set(t));
  }

  refreshAllData() {
    this.refreshCoreDashboardData();
  }
}
