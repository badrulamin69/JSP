export interface Customer {
  id: string;
  name: string;
  email: string;
  status: string; // 'active' | 'pending' | 'suspended'
  balance: number;
  avatar: string;
  role: string; // 'Premium' | 'Standard' | 'Elite'
  kycStatus: 'pending' | 'verified' | 'rejected';
  phone: string;
  address: string;
  activityLog: string[]; // References AuditLog IDs
  isSuspended: boolean;
  suspensionReason: string | null;
  riskIndicators: string[];
  highValueCustomer: boolean;
  nidVerification: { status: 'pending' | 'verified' | 'rejected'; documentUrl: string | null; };
  addressVerification: { status: 'pending' | 'verified' | 'rejected'; documentUrl: string | null; };
}

export interface BankAccount {
  id: string;
  customerId: string;
  type: string;
  balance: number;
  currency: string;
  accountNumber: string;
  status: string;
}

export interface Transaction {
  id: string;
  customerId: string;
  type: 'transfer' | 'deposit' | 'withdrawal';
  amount: number;
  status: string;
  date: string;
  description: string;
  category: string;
  failureReason: string | null;
  retryAttempts: number;
  scheduledDate: string | null;
  isRecurring: boolean;
}

export interface AuditLog {
  id: string;
  action: string;
  actor: string;
  resource: string;
  timestamp: string;
  status: string;
  details: string;
}

export interface SupportTicket {
  id: string;
  customerId: string;
  subject: string;
  status: string;
  date: string;
  priority: string;
  lastReply: string;
}
