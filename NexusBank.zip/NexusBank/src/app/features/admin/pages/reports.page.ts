import { ChangeDetectionStrategy, Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BankingAdminService } from '../banking-admin.service';

@Component({
  standalone: true,
  selector: 'app-admin-reports',
  imports: [CommonModule, MatIconModule],
  templateUrl: './reports.page.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AdminReportsPage implements OnInit {
  admin = inject(BankingAdminService);

  ngOnInit() {
    this.admin.loadReports();
  }

  exportStub(format: 'pdf' | 'xlsx', title: string) {
    window.alert(`Export ${format.toUpperCase()} queued for "${title}" (wire to a backend exporter).`);
  }
}
