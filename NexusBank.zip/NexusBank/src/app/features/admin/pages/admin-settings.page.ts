import {
  ChangeDetectionStrategy,
  Component,
  effect,
  inject,
  OnInit,
  signal,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { BankingAdminService } from '../banking-admin.service';

@Component({
  standalone: true,
  selector: 'app-admin-settings',
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './admin-settings.page.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AdminSettingsPage implements OnInit {
  private fb = inject(FormBuilder);
  admin = inject(BankingAdminService);

  saving = signal(false);

  form = this.fb.nonNullable.group({
    defaultCurrency: ['USD', Validators.required],
    timezone: ['UTC', Validators.required],
    sessionTimeoutMinutes: [30, [Validators.required, Validators.min(5)]],
    maintenanceMode: [false],
    fraudAlertsEnabled: [true],
  });

  constructor() {
    effect(() => {
      const g = this.admin.appSettings();
      if (g) this.patchForm(g);
    });
  }

  ngOnInit() {
    this.admin.loadAppSettings();
  }

  private patchForm(s: {
    defaultCurrency: string;
    timezone: string;
    sessionTimeoutMinutes: number;
    maintenanceMode: boolean;
    fraudAlertsEnabled: boolean;
  }) {
    this.form.patchValue({
      defaultCurrency: s.defaultCurrency,
      timezone: s.timezone,
      sessionTimeoutMinutes: s.sessionTimeoutMinutes,
      maintenanceMode: s.maintenanceMode,
      fraudAlertsEnabled: s.fraudAlertsEnabled,
    });
  }

  save() {
    if (this.form.invalid) return;
    const base = this.admin.appSettings();
    if (!base) return;
    this.saving.set(true);
    const body = { ...base, ...this.form.getRawValue() };
    this.admin.saveAppSettings(body).subscribe({
      complete: () => this.saving.set(false),
      error: () => this.saving.set(false),
    });
  }
}
