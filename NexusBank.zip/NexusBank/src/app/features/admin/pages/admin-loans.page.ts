import { ChangeDetectionStrategy, Component, inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BankingAdminService } from '../banking-admin.service';

@Component({
  standalone: true,
  selector: 'app-admin-loans',
  imports: [CommonModule, MatIconModule],
  templateUrl: './admin-loans.page.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AdminLoansPage implements OnInit {
  admin = inject(BankingAdminService);
  busyId = signal<string | null>(null);

  ngOnInit() {
    this.admin.loadLoansAndApplications();
  }

  setApplicationStatus(id: string, status: 'approved' | 'rejected') {
    this.busyId.set(id);
    this.admin.patchLoanApplication(id, { status }).subscribe({
      complete: () => this.busyId.set(null),
      error: () => this.busyId.set(null),
    });
  }
}
