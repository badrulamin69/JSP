import { ChangeDetectionStrategy, Component, inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BankingAdminService } from '../banking-admin.service';

@Component({
  standalone: true,
  selector: 'app-admin-branches',
  imports: [CommonModule, MatIconModule],
  templateUrl: './branches.page.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AdminBranchesPage implements OnInit {
  admin = inject(BankingAdminService);
  busyId = signal<string | null>(null);

  ngOnInit() {
    this.admin.loadBranches();
  }

  patch(id: string, field: 'status', value: string) {
    this.busyId.set(id);
    this.admin.updateBranch(id, { [field]: value }).subscribe({
      complete: () => this.busyId.set(null),
      error: () => this.busyId.set(null),
    });
  }
}
