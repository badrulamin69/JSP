import {
  ChangeDetectionStrategy,
  Component,
  inject,
  OnInit,
  signal,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { BankingAdminService } from '../banking-admin.service';
import type { Employee } from '../banking-admin.models';

@Component({
  selector: 'app-admin-employees',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, MatIconModule],
  templateUrl: './employees.page.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AdminEmployeesPage implements OnInit {
  private fb = inject(FormBuilder);
  admin = inject(BankingAdminService);

  saving = signal(false);
  editingId = signal<string | null>(null);

  form = this.fb.group({
    name: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    role: ['operations', Validators.required],
    branchId: ['b1', Validators.required],
    department: ['Operations', Validators.required],
    status: this.fb.nonNullable.control<'active' | 'inactive'>('active', Validators.required),
  });

  ngOnInit() {
    this.admin.loadEmployees();
  }

  startEdit(row: { id: string; name: string; email: string; role: string; branchId: string; department: string; status: 'active' | 'inactive' }) {
    this.editingId.set(row.id);
    this.form.patchValue(row);
  }

  cancelEdit() {
    this.editingId.set(null);
    this.form.reset({
      name: '',
      email: '',
      role: 'operations',
      branchId: 'b1',
      department: 'Operations',
      status: 'active' as const,
    });
  }

  submit() {
    if (this.form.invalid) return;
    this.saving.set(true);
    const v = this.form.getRawValue() as Omit<Employee, 'id'>;
    const id = this.editingId();
    const done = () => {
      this.saving.set(false);
      this.cancelEdit();
    };
    if (id) {
      this.admin.updateEmployee(id, v).subscribe({ next: done, error: done });
    } else {
      this.admin.addEmployee(v).subscribe({ next: done, error: done });
    }
  }

  remove(id: string) {
    if (!confirm('Remove this employee record?')) return;
    this.admin.deleteEmployee(id).subscribe();
  }
}
