import { ChangeDetectionStrategy, Component, inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BankingAdminService } from '../banking-admin.service';

@Component({
  standalone: true,
  selector: 'app-admin-accounts',
  imports: [CommonModule],
  templateUrl: './admin-accounts.page.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AdminAccountsPage implements OnInit {
  admin = inject(BankingAdminService);
  busyId = signal<string | null>(null);
  draftBalance = signal<Record<string, number>>({});

  ngOnInit() {
    this.admin.loadAccounts();
  }

  trackDraft(id: string, value: number) {
    this.draftBalance.update((m) => ({ ...m, [id]: value }));
  }

  displayedBalance(id: string, fallback: number): number {
    const v = this.draftBalance()[id];
    return v !== undefined ? v : fallback;
  }

  saveBalance(id: string, current: number) {
    const next = this.draftBalance()[id] ?? current;
    this.busyId.set(id);
    this.admin.patchAccount(id, { balance: next }).subscribe({
      complete: () => this.busyId.set(null),
      error: () => this.busyId.set(null),
    });
  }

  setStatus(id: string, status: string) {
    this.busyId.set(id);
    this.admin.patchAccount(id, { status }).subscribe({
      complete: () => this.busyId.set(null),
      error: () => this.busyId.set(null),
    });
  }
}
