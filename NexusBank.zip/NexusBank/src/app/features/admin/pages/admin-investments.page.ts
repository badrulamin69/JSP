import { ChangeDetectionStrategy, Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BankingAdminService } from '../banking-admin.service';

@Component({
  standalone: true,
  selector: 'app-admin-investments',
  imports: [CommonModule],
  templateUrl: './admin-investments.page.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AdminInvestmentsPage implements OnInit {
  admin = inject(BankingAdminService);

  ngOnInit() {
    this.admin.loadInvestments();
  }
}
