import { ChangeDetectionStrategy, Component, inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BankingAdminService } from '../banking-admin.service';

@Component({
  standalone: true,
  selector: 'app-admin-atms',
  imports: [CommonModule, MatIconModule],
  templateUrl: './atms.page.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AdminAtmsPage implements OnInit {
  admin = inject(BankingAdminService);
  busyId = signal<string | null>(null);

  ngOnInit() {
    this.admin.loadAtms();
  }

  patch(id: string, body: Partial<{ status: string; cashLevel: number }>) {
    this.busyId.set(id);
    this.admin.updateAtm(id, body).subscribe({
      complete: () => this.busyId.set(null),
      error: () => this.busyId.set(null),
    });
  }
}
