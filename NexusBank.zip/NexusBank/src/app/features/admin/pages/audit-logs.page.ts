import { ChangeDetectionStrategy, Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BankingAdminService } from '../banking-admin.service';

@Component({
  standalone: true,
  selector: 'app-admin-audit-logs',
  imports: [CommonModule, MatIconModule],
  templateUrl: './audit-logs.page.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AdminAuditLogsPage implements OnInit {
  admin = inject(BankingAdminService);

  ngOnInit() {
    this.admin.loadAuditLogs();
  }
}
