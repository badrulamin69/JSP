import { ChangeDetectionStrategy, Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BankingAdminService } from '../banking-admin.service';

@Component({
  standalone: true,
  selector: 'app-admin-fixed-deposits',
  imports: [CommonModule],
  templateUrl: './admin-fixed-deposits.page.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AdminFixedDepositsPage implements OnInit {
  admin = inject(BankingAdminService);

  ngOnInit() {
    this.admin.loadFixedDeposits();
  }
}
