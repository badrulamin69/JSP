import { ChangeDetectionStrategy, Component, inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../../core/services/api.service';

interface RoleRow {
  id: string;
  name: string;
  permissions: string[];
}

interface PermissionRow {
  id: string;
  name: string;
}

@Component({
  standalone: true,
  selector: 'app-admin-roles',
  imports: [CommonModule],
  templateUrl: './roles.page.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AdminRolesPage implements OnInit {
  private api = inject(ApiService);

  roles = signal<RoleRow[]>([]);
  permissions = signal<PermissionRow[]>([]);

  ngOnInit() {
    this.api.get<RoleRow[]>('roles').subscribe((r) => this.roles.set(r));
    this.api.get<PermissionRow[]>('permissions').subscribe((p) => this.permissions.set(p));
  }
}
