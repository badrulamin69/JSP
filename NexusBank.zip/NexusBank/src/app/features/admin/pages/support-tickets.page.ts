import { ChangeDetectionStrategy, Component, inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BankingAdminService } from '../banking-admin.service';

@Component({
  standalone: true,
  selector: 'app-admin-support-tickets',
  imports: [CommonModule],
  templateUrl: './support-tickets.page.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AdminSupportTicketsPage implements OnInit {
  admin = inject(BankingAdminService);
  busyId = signal<string | null>(null);

  ngOnInit() {
    this.admin.loadSupportTickets();
  }

  setStatus(id: string, status: string) {
    this.busyId.set(id);
    this.admin.patchSupportTicket(id, { status }).subscribe({
      complete: () => this.busyId.set(null),
      error: () => this.busyId.set(null),
    });
  }
}
