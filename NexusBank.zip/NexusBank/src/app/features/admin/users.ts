import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { BankingAdminService, User } from './banking-admin.service';

@Component({
  selector: 'app-admin-users',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, MatIconModule],
  template: `
    <div class="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <!-- Header Section -->
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 class="text-3xl font-display font-bold text-slate-900">User Management</h1>
          <p class="text-slate-500 mt-1">Manage system access, roles, and security credentials.</p>
        </div>
        <button (click)="openAddModal()" class="bg-blue-600 text-white px-6 py-3 rounded-xl font-bold flex items-center gap-2 hover:bg-blue-700 transition-all shadow-lg shadow-blue-600/20 active:scale-95">
          <mat-icon>person_add</mat-icon>
          Create New User
        </button>
      </div>

      <!-- Stats Grid -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div class="glass p-6 rounded-3xl border border-white/40 shadow-xl">
           <div class="flex items-center gap-4">
              <div class="w-12 h-12 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center">
                 <mat-icon>group</mat-icon>
              </div>
              <div>
                 <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Total Users</p>
                 <p class="text-2xl font-bold text-slate-900">{{ adminService.users().length }}</p>
              </div>
           </div>
        </div>
        <div class="glass p-6 rounded-3xl border border-white/40 shadow-xl">
           <div class="flex items-center gap-4">
              <div class="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center">
                 <mat-icon>security</mat-icon>
              </div>
              <div>
                 <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Admins</p>
                 <p class="text-2xl font-bold text-slate-900">{{ getRoleCount('admin') }}</p>
              </div>
           </div>
        </div>
        <div class="glass p-6 rounded-3xl border border-white/40 shadow-xl">
           <div class="flex items-center gap-4">
              <div class="w-12 h-12 bg-amber-50 text-amber-600 rounded-2xl flex items-center justify-center">
                 <mat-icon>badge</mat-icon>
              </div>
              <div>
                 <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Employees</p>
                 <p class="text-2xl font-bold text-slate-900">{{ getRoleCount('employee') }}</p>
              </div>
           </div>
        </div>
      </div>

      <!-- Users Table Card -->
      <div class="glass rounded-[2rem] border border-white/40 shadow-2xl overflow-hidden">
        <div class="p-8 border-b border-slate-100 flex items-center justify-between">
          <h2 class="text-lg font-bold text-slate-900">System Users</h2>
          <div class="flex items-center gap-3">
             <span class="text-xs font-bold text-slate-400 uppercase tracking-widest">Sync Status:</span>
             <span class="flex items-center gap-1.5 px-2 py-1 bg-emerald-50 text-emerald-600 text-[10px] font-bold rounded-full">
                <span class="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></span>
                LIVE
             </span>
          </div>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full">
            <thead>
              <tr class="bg-slate-50/50">
                <th class="px-8 py-4 text-left text-[10px] font-bold text-slate-400 uppercase tracking-widest">User Details</th>
                <th class="px-8 py-4 text-left text-[10px] font-bold text-slate-400 uppercase tracking-widest">System Role</th>
                <th class="px-8 py-4 text-left text-[10px] font-bold text-slate-400 uppercase tracking-widest">Security</th>
                <th class="px-8 py-4 text-right text-[10px] font-bold text-slate-400 uppercase tracking-widest">Actions</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              @for (user of adminService.users(); track user.id) {
                <tr class="hover:bg-slate-50/50 transition-colors group">
                  <td class="px-8 py-6">
                    <div class="flex items-center gap-4">
                      <div class="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-500 font-bold group-hover:bg-blue-100 group-hover:text-blue-600 transition-colors">
                        {{ user.name.charAt(0) }}
                      </div>
                      <div>
                        <p class="text-sm font-bold text-slate-900">{{ user.name }}</p>
                        <p class="text-xs text-slate-500">{{ user.email }}</p>
                      </div>
                    </div>
                  </td>
                  <td class="px-8 py-6">
                    <span [class]="getRoleClass(user.role)" class="px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider">
                      {{ user.role }}
                    </span>
                  </td>
                  <td class="px-8 py-6">
                    <div class="flex items-center gap-2 text-slate-400">
                      <mat-icon class="text-lg">shield</mat-icon>
                      <span class="text-[10px] font-bold uppercase tracking-widest">AES-256</span>
                    </div>
                  </td>
                  <td class="px-8 py-6 text-right">
                    <div class="flex items-center justify-end gap-2">
                      <button (click)="openEditModal(user)" class="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all">
                        <mat-icon>edit</mat-icon>
                      </button>
                      <button (click)="onDeleteUser(user.id)" class="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all">
                        <mat-icon>delete</mat-icon>
                      </button>
                    </div>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

      <!-- User Modal -->
      @if (showModal()) {
        <div class="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6">
          <div class="absolute inset-0 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-300" (click)="closeModal()"></div>
          
          <div class="bg-white w-full max-w-lg rounded-[2.5rem] shadow-2xl relative overflow-hidden animate-in zoom-in-95 duration-300">
            <div class="p-8 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 class="text-xl font-bold text-slate-900">{{ isEditing() ? 'Edit Security Profile' : 'New User Enrollment' }}</h3>
                <p class="text-xs text-slate-500 font-medium uppercase tracking-widest mt-1">Enterprise Access Control</p>
              </div>
              <button (click)="closeModal()" class="p-2 text-slate-400 hover:bg-slate-50 rounded-full">
                <mat-icon>close</mat-icon>
              </button>
            </div>

            <form [formGroup]="userForm" (ngSubmit)="onSave()" class="p-8 space-y-6">
              <div class="space-y-4">
                <div>
                  <label class="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2 block px-1">Full Name</label>
                  <input type="text" formControlName="name" class="w-full bg-slate-50 border border-slate-100 rounded-2xl py-3.5 px-4 focus:outline-hidden focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 transition-all">
                </div>
                <div>
                  <label class="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2 block px-1">Email Address</label>
                  <input type="email" formControlName="email" class="w-full bg-slate-50 border border-slate-100 rounded-2xl py-3.5 px-4 focus:outline-hidden focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 transition-all">
                </div>
                <div>
                  <label class="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2 block px-1">Security Role</label>
                  <select formControlName="role" class="w-full bg-slate-50 border border-slate-100 rounded-2xl py-3.5 px-4 focus:outline-hidden focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 transition-all">
                    <option value="admin">Administrator</option>
                    <option value="employee">Bank Employee</option>
                    <option value="customer">Retail Customer</option>
                  </select>
                </div>
                @if (!isEditing()) {
                  <div>
                    <label class="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2 block px-1">Temporary Password</label>
                    <input type="password" formControlName="password" class="w-full bg-slate-50 border border-slate-100 rounded-2xl py-3.5 px-4 focus:outline-hidden focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 transition-all">
                  </div>
                }
              </div>

              <div class="flex gap-4 pt-4">
                <button type="button" (click)="closeModal()" class="flex-1 px-6 py-4 rounded-2xl border border-slate-100 text-slate-600 font-bold hover:bg-slate-50 transition-all">Cancel</button>
                <button type="submit" [disabled]="userForm.invalid" class="flex-[2] bg-blue-600 text-white font-bold py-4 rounded-2xl hover:bg-blue-700 transition-all shadow-lg shadow-blue-600/20 active:scale-95 disabled:opacity-50">
                  {{ isEditing() ? 'Update Security Profile' : 'Finalize Enrollment' }}
                </button>
              </div>
            </form>
          </div>
        </div>
      }
    </div>
  `,
  styles: [`
    .glass {
      background: rgba(255, 255, 255, 0.7);
      backdrop-filter: blur(20px);
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AdminUsers {
  adminService = inject(BankingAdminService);
  private fb = inject(FormBuilder);

  showModal = signal(false);
  isEditing = signal(false);
  selectedUserId = signal<string | null>(null);

  userForm = this.fb.group({
    name: ['', [Validators.required]],
    email: ['', [Validators.required, Validators.email]],
    role: ['customer' as const, [Validators.required]],
    password: ['']
  });

  getRoleCount(role: string) {
    return this.adminService.users().filter(u => u.role === role).length;
  }

  getRoleClass(role: string) {
    switch (role) {
      case 'admin': return 'bg-purple-50 text-purple-700 border border-purple-100';
      case 'employee': return 'bg-amber-50 text-amber-700 border border-amber-100';
      default: return 'bg-blue-50 text-blue-700 border border-blue-100';
    }
  }

  openAddModal() {
    this.isEditing.set(false);
    this.selectedUserId.set(null);
    this.userForm.reset({ role: 'customer' });
    this.userForm.get('password')?.setValidators([Validators.required]);
    this.showModal.set(true);
  }

  openEditModal(user: User) {
    this.isEditing.set(true);
    this.selectedUserId.set(user.id);
    this.userForm.patchValue({
      name: user.name,
      email: user.email,
      role: user.role as any
    });
    this.userForm.get('password')?.clearValidators();
    this.showModal.set(true);
  }

  closeModal() {
    this.showModal.set(false);
  }

  onSave() {
    if (this.userForm.invalid) return;

    const userData = this.userForm.getRawValue();
    const id = this.selectedUserId();

    if (this.isEditing() && id) {
      this.adminService.updateUser(id, {
        name: userData.name!,
        email: userData.email!,
        role: userData.role!
      }).subscribe(() => this.closeModal());
    } else {
      this.adminService.addUser({
        name: userData.name!,
        email: userData.email!,
        role: userData.role!,
        password: userData.password!
      }).subscribe(() => this.closeModal());
    }
  }

  onDeleteUser(id: string) {
    if (confirm('Are you sure you want to revoke this user\'s access permanently?')) {
      this.adminService.deleteUser(id).subscribe();
    }
  }
}
