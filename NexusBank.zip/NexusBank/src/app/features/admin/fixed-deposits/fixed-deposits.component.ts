import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-fixed-deposits',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './fixed-deposits.component.html',
  styleUrl: './fixed-deposits.component.css'
})
export class FixedDepositsComponent {}