import { Component, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { SessionService } from '../../core/services/session.service';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-employee-layout',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink, RouterLinkActive, MatIconModule],
  template: `
    <div class="min-h-screen bg-slate-50 flex overflow-hidden">
      <!-- Sidebar -->
      <aside 
        class="fixed inset-y-0 left-0 z-50 w-72 bg-emerald-950 text-white transform transition-transform duration-300 lg:relative lg:translate-x-0"
        [class.-translate-x-full]="!isSidebarOpen()"
      >
        <div class="h-full flex flex-col">
          <div class="h-20 flex items-center px-8 border-b border-white/5">
            <div class="flex items-center gap-3">
              <div class="w-10 h-10 bg-emerald-500 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-500/20">
                <mat-icon class="text-white">badge</mat-icon>
              </div>
              <div>
                <h1 class="text-lg font-display font-bold tracking-tight">Staff Portal</h1>
                <p class="text-[10px] text-emerald-400 uppercase tracking-widest font-bold">Banking Operations</p>
              </div>
            </div>
          </div>

          <nav class="flex-1 overflow-y-auto py-6 px-4 space-y-1 custom-scrollbar">
            <p class="px-4 text-[10px] font-bold text-emerald-700/60 uppercase tracking-widest mb-4">Operations Dashboard</p>
            
            @for (item of mainItems; track item.path) {
              <a 
                [routerLink]="['/employee', item.path]"
                routerLinkActive="bg-emerald-600 text-white shadow-xl shadow-emerald-600/20"
                class="flex items-center gap-3 px-4 py-3 rounded-xl text-emerald-100/60 hover:bg-white/5 hover:text-white transition-all group"
              >
                <mat-icon class="text-lg">{{ item.icon }}</mat-icon>
                <span class="font-medium text-sm">{{ item.label }}</span>
                @if (item.badge) {
                  <span class="ml-auto px-2 py-0.5 text-[10px] font-bold bg-amber-500 text-white rounded-full">
                    {{ item.badge }}
                  </span>
                }
              </a>
            }

            <p class="px-4 text-[10px] font-bold text-emerald-700/60 uppercase tracking-widest mt-8 mb-4">Credit & Risk</p>
            @for (item of riskItems; track item.path) {
              <a 
                [routerLink]="['/employee', item.path]"
                routerLinkActive="bg-emerald-600 text-white"
                class="flex items-center gap-3 px-4 py-3 rounded-xl text-emerald-100/60 hover:bg-white/5 hover:text-white transition-all group"
              >
                <mat-icon class="text-lg">{{ item.icon }}</mat-icon>
                <span class="font-medium text-sm">{{ item.label }}</span>
              </a>
            }
          </nav>

          <!-- User Quick Profile -->
          <div class="p-6 border-t border-white/5">
             <div class="flex items-center gap-3 bg-white/5 p-3 rounded-2xl">
                <img [src]="'https://ui-avatars.com/api/?name=' + session.session()?.name + '&background=10b981&color=fff'" class="w-10 h-10 rounded-xl" alt="">
                <div class="overflow-hidden">
                   <p class="text-xs font-bold truncate">{{ session.session()?.name }}</p>
                   <p class="text-[10px] text-emerald-400 font-medium uppercase">{{ session.session()?.role }}</p>
                </div>
                <button (click)="auth.logout()" class="ml-auto p-1.5 text-emerald-400 hover:bg-white/5 rounded-lg transition-colors group">
                   <mat-icon class="text-lg group-hover:rotate-180 transition-transform">logout</mat-icon>
                </button>
             </div>
          </div>
        </div>
      </aside>

      <!-- Main Content -->
      <main class="flex-1 flex flex-col min-w-0 h-screen overflow-hidden">
        <header class="h-20 bg-white border-b border-slate-200 flex items-center justify-between px-8 shrink-0 z-40">
           <div class="flex items-center gap-4">
             <button (click)="toggleSidebar()" class="lg:hidden p-2 text-slate-500 hover:bg-slate-50 rounded-lg">
               <mat-icon>menu</mat-icon>
             </button>
             <h2 class="text-sm font-bold text-slate-400 uppercase tracking-widest">Employee Terminal v2.1</h2>
           </div>

           <div class="flex items-center gap-6">
             <div class="hidden md:flex flex-col items-end">
                <p class="text-xs font-bold text-slate-900">Zurich Main Branch</p>
                <p class="text-[10px] text-emerald-600 font-bold uppercase tracking-widest">Active Shift</p>
             </div>
             
             <button class="relative p-2.5 bg-slate-50 text-slate-500 rounded-xl hover:bg-emerald-50 hover:text-emerald-600 transition-all">
                <mat-icon>mail</mat-icon>
                <span class="absolute top-2 right-2 w-2 h-2 bg-amber-500 rounded-full border-2 border-white"></span>
             </button>
           </div>
        </header>

        <div class="flex-1 overflow-y-auto p-8 custom-scrollbar">
           <router-outlet></router-outlet>
        </div>
      </main>
    </div>
  `,
  styles: [`
    .custom-scrollbar::-webkit-scrollbar {
      width: 6px;
    }
    .custom-scrollbar::-webkit-scrollbar-track {
      background: transparent;
    }
    .custom-scrollbar::-webkit-scrollbar-thumb {
      background: rgba(16, 185, 129, 0.1);
      border-radius: 10px;
    }
  `]
})
export class EmployeeLayout {
  session = inject(SessionService);
  auth = inject(AuthService);
  isSidebarOpen = signal(true);

  mainItems = [
    { path: 'dashboard', label: 'Operations', icon: 'speed', badge: '5' },
    { path: 'cash', label: 'Counter Ops', icon: 'account_balance_wallet' },
    { path: 'customers', label: 'Client Directory', icon: 'group' },
    { path: 'compliance', label: 'KYC / AML', icon: 'verified_user' },
  ];

  riskItems = [
    { path: 'loans', label: 'Loan Processing', icon: 'assignment' },
    { path: 'tickets', label: 'Support Desk', icon: 'contact_support' },
    { path: 'analytics', label: 'Branch Stats', icon: 'analytics' },
    { path: 'settings', label: 'Preferences', icon: 'tune' },
  ];

  toggleSidebar() {
    this.isSidebarOpen.update(v => !v);
  }
}
