import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BankingEmployeeService } from './banking-employee.service';

@Component({
  selector: 'app-employee-compliance',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-8 animate-in slide-in-from-bottom-4 duration-500">
      <!-- Summary -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
         <div class="md:col-span-2 bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm flex flex-col justify-between">
            <div>
               <h2 class="text-3xl font-display font-bold text-slate-900 tracking-tight">Compliance & KYC</h2>
               <p class="text-slate-500 font-light mt-1">Identity validation and Anti-Money Laundering (AML) checks center.</p>
            </div>
            <div class="flex gap-8 mt-10">
               <div>
                  <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Active Cases</p>
                  <p class="text-2xl font-bold text-slate-900">{{ service.kycRecords().length }}</p>
               </div>
               <div>
                  <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Verification Speed</p>
                  <p class="text-2xl font-bold text-emerald-600">4.2h</p>
               </div>
               <div>
                  <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Global Risk</p>
                  <p class="text-2xl font-bold text-blue-600">Low</p>
               </div>
            </div>
         </div>
         <div class="bg-emerald-950 p-10 rounded-[3rem] text-white flex flex-col justify-center items-center text-center shadow-xl">
            <div class="w-16 h-16 bg-emerald-500/20 rounded-2xl flex items-center justify-center mb-6 border border-emerald-500/20">
               <mat-icon class="text-3xl text-emerald-400">gavel</mat-icon>
            </div>
            <h4 class="text-lg font-bold">Standard Regulatory Compliance</h4>
            <p class="text-emerald-100/60 text-xs mt-2 font-light">Last synced with Central Bank 12 minutes ago.</p>
            <button class="mt-8 px-6 py-3 bg-emerald-500 text-emerald-950 font-bold rounded-2xl text-xs uppercase tracking-widest hover:bg-emerald-400 transition-all">Export AML Audit</button>
         </div>
      </div>

      <!-- Verification List -->
      <div class="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm overflow-hidden">
         <div class="px-10 py-8 border-b border-slate-50">
            <h3 class="text-lg font-bold text-slate-900">Verification Queue</h3>
         </div>
         <div class="overflow-x-auto">
            <table class="w-full text-left">
               <thead>
                  <tr class="bg-slate-50/50">
                     <th class="px-10 py-5 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Case ID</th>
                     <th class="px-10 py-5 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Client Name</th>
                     <th class="px-10 py-5 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Documents Provided</th>
                     <th class="px-10 py-5 text-[10px] font-bold text-slate-400 uppercase tracking-widest">State</th>
                     <th class="px-10 py-5 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-center">Operation</th>
                  </tr>
               </thead>
               <tbody class="divide-y divide-slate-50">
                  @for (record of records(); track record.id) {
                     <tr class="hover:bg-slate-50/50 transition-colors">
                        <td class="px-10 py-6 font-mono text-xs font-bold text-slate-900">{{ record.id }}</td>
                        <td class="px-10 py-6">
                           <div class="flex items-center gap-3">
                              <div class="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center">
                                 <mat-icon class="text-lg text-slate-400">person</mat-icon>
                              </div>
                              <span class="text-sm font-bold text-slate-900">{{ record.customerName }}</span>
                           </div>
                        </td>
                        <td class="px-10 py-6">
                           <div class="flex gap-2">
                              @for (doc of record.documents; track doc) {
                                 <span class="px-2 py-1 bg-blue-50 text-blue-600 text-[10px] font-bold rounded-md">{{ doc }}</span>
                              }
                           </div>
                        </td>
                        <td class="px-10 py-6">
                           <span [class]="'px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest ' + getStatusClass(record.status)">
                              {{ record.status }}
                           </span>
                        </td>
                        <td class="px-10 py-6">
                           <div class="flex justify-center gap-2">
                              @if (record.status === 'pending') {
                                 <button (click)="verify(record.id)" class="px-4 py-2 bg-emerald-600 text-white text-[10px] font-bold uppercase rounded-xl hover:bg-emerald-700 transition-all">Verify</button>
                                 <button (click)="fail(record.id)" class="px-4 py-2 bg-rose-50 text-rose-600 text-[10px] font-bold uppercase rounded-xl hover:bg-rose-100 transition-all">Flag</button>
                              } @else {
                                 <button class="px-4 py-2 bg-slate-50 text-slate-400 text-[10px] font-bold uppercase rounded-xl hover:bg-slate-100 transition-all">View Logs</button>
                              }
                           </div>
                        </td>
                     </tr>
                  }
               </tbody>
            </table>
         </div>
      </div>
    </div>
  `
})
export class EmployeeCompliance {
  service = inject(BankingEmployeeService);
  records = this.service.kycRecords;

  getStatusClass(status: string) {
    switch (status) {
      case 'verified': return 'bg-emerald-50 text-emerald-600 border border-emerald-100';
      case 'pending': return 'bg-amber-50 text-amber-600 border border-amber-100';
      case 'failed': return 'bg-rose-50 text-rose-600 border border-rose-100';
      default: return 'bg-slate-50 text-slate-600';
    }
  }

  verify(id: string) {
    this.service.updateKYCStatus(id, 'verified');
  }

  fail(id: string) {
    this.service.updateKYCStatus(id, 'failed');
  }
}
