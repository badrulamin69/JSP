import { Component, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BankingEmployeeService } from './banking-employee.service';

@Component({
  selector: 'app-employee-dashboard',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-8 animate-in fade-in duration-700">
      <!-- Welcome Header -->
      <div class="bg-linear-to-r from-emerald-900 to-emerald-800 rounded-[2.5rem] p-10 text-white shadow-2xl relative overflow-hidden">
        <div class="absolute -bottom-24 -left-24 w-64 h-64 bg-white/5 rounded-full blur-3xl"></div>
        <div class="relative z-10">
          <div class="flex items-center gap-4 mb-4">
             <span class="px-3 py-1 bg-emerald-500/20 border border-emerald-500/20 rounded-full text-[10px] font-bold uppercase tracking-widest text-emerald-400">Operations Center</span>
             <span class="text-white/40 text-xs font-medium">Monday, 11 May 2026</span>
          </div>
          <h2 class="text-4xl font-display font-bold tracking-tight">Good day, Officer John.</h2>
          <p class="text-emerald-100/60 mt-2 max-w-xl font-light">You have <span class="text-emerald-400 font-bold">{{ stats().pendingRequests }} pending assignments</span> awaiting your review in the current shift.</p>
        </div>
      </div>

      <!-- Quick Stats -->
      <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
        @for (item of dashboardCards(); track item.label) {
          <div class="bg-white p-6 rounded-3xl border border-slate-100 shadow-xs hover:shadow-lg transition-all group">
             <div class="flex items-center justify-between mb-4">
                <div [class]="'w-12 h-12 rounded-2xl flex items-center justify-center ' + item.bg">
                   <mat-icon [class]="item.color">{{ item.icon }}</mat-icon>
                </div>
                <div class="text-right">
                   <p class="text-xs font-bold text-slate-400 uppercase tracking-widest">{{ item.label }}</p>
                   <p class="text-xl font-bold text-slate-900">{{ item.value }}</p>
                </div>
             </div>
             <div class="h-1 bg-slate-50 rounded-full overflow-hidden">
                <div class="h-full bg-emerald-500 w-2/3 group-hover:w-full transition-all duration-700"></div>
             </div>
          </div>
        }
      </div>

      <div class="grid lg:grid-cols-3 gap-8">
        <!-- Operations Queue -->
        <div class="lg:col-span-2 space-y-6">
           <div class="flex items-center justify-between">
              <h3 class="text-lg font-bold text-slate-900">Task Queue</h3>
              <button class="text-emerald-600 text-xs font-bold uppercase tracking-widest hover:underline">View All Tasks</button>
           </div>

           <div class="bg-white rounded-[2rem] border border-slate-100 shadow-sm overflow-hidden">
             @for (loan of pendingLoans(); track loan.id) {
               <div class="p-6 border-b border-slate-50 last:border-0 hover:bg-slate-50 transition-colors flex items-center gap-6">
                  <div class="w-12 h-12 bg-amber-50 text-amber-600 rounded-xl flex items-center justify-center">
                     <mat-icon>description</mat-icon>
                  </div>
                  <div class="flex-1">
                     <div class="flex items-center gap-2">
                        <p class="text-sm font-bold text-slate-900">Loan Request: {{ loan.type }}</p>
                        <span class="px-2 py-0.5 bg-amber-50 text-amber-600 text-[9px] font-bold uppercase rounded-md tracking-tighter">Review Required</span>
                     </div>
                     <p class="text-xs text-slate-500 mt-1">Applicant: {{ loan.customerName }} • Amount: {{ loan.amount | currency:'USD' }} • Credit Score: <span class="font-bold text-slate-900">{{ loan.score }}</span></p>
                  </div>
                  <div class="flex gap-2">
                     <button (click)="approve(loan.id)" class="px-4 py-2 bg-emerald-600 text-white text-[10px] font-bold uppercase rounded-xl hover:bg-emerald-700 transition-all">Approve</button>
                     <button (click)="reject(loan.id)" class="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-all">
                        <mat-icon class="text-lg">close</mat-icon>
                     </button>
                  </div>
               </div>
             }
           </div>
        </div>

        <!-- System Status & Notifications -->
        <div class="space-y-6">
           <h3 class="text-lg font-bold text-slate-900">System Priority</h3>
           <div class="bg-slate-900 p-8 rounded-[2rem] text-white space-y-6">
              <div class="space-y-2">
                 <p class="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Branch Liquidity</p>
                 <div class="flex items-center justify-between">
                    <p class="text-2xl font-bold font-mono">$452,000</p>
                    <span class="text-emerald-400 text-xs font-bold">+2.4%</span>
                 </div>
              </div>

              <div class="h-[1px] bg-white/10 w-full"></div>

              <div class="space-y-4">
                 @for (notif of recentActivity; track notif.title) {
                   <div class="flex gap-3">
                      <div class="w-1.5 h-1.5 bg-emerald-500 rounded-full mt-1.5"></div>
                      <div>
                         <p class="text-xs font-bold">{{ notif.title }}</p>
                         <p class="text-[10px] text-slate-500 mt-0.5">{{ notif.time }}</p>
                      </div>
                   </div>
                 }
              </div>

              <button class="w-full py-4 bg-emerald-500 text-emerald-950 text-xs font-bold uppercase rounded-2xl hover:bg-emerald-400 transition-all">
                 System Health Check
              </button>
           </div>
        </div>
      </div>
    </div>
  `
})
export class EmployeeDashboard {
  private service = inject(BankingEmployeeService);
  
  stats = this.service.stats;
  pendingLoans = computed(() => this.service.loans().filter(l => l.status === 'pending').slice(0, 3));

  dashboardCards = computed(() => {
    const s = this.service.stats();
    return [
      { label: 'Pending Tasks', value: s.pendingRequests, icon: 'assignment', bg: 'bg-amber-50', color: 'text-amber-600' },
      { label: 'KYC Progress', value: '82%', icon: 'verified_user', bg: 'bg-emerald-50', color: 'text-emerald-600' },
      { label: 'Approval Rate', value: s.approvalRate, icon: 'analytics', bg: 'bg-blue-50', color: 'text-blue-600' },
      { label: 'Credit Score Ø', value: s.avgScore, icon: 'credit_score', bg: 'bg-purple-50', color: 'text-purple-600' },
    ];
  });

  recentActivity = [
    { title: 'ATM ZRH-01 Replenished', time: '12m ago' },
    { title: 'Large Withdrawal Verified', time: '45m ago' },
    { title: 'SWIFT Cluster Sync Complete', time: '1h ago' },
  ];

  approve(id: string) {
    this.service.updateLoanStatus(id, 'approved').subscribe();
  }

  reject(id: string) {
    this.service.updateLoanStatus(id, 'rejected').subscribe();
  }
}
