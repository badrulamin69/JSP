import { Injectable, signal, computed, inject } from '@angular/core';
import { ApiService } from '../../core/services/api.service';
import { tap, forkJoin } from 'rxjs';

export interface LoanRequest {
  id: string;
  customerId: string;
  customerName?: string;
  amount: number;
  type: string;
  status: 'pending' | 'approved' | 'rejected' | 'disbursed';
  date: string;
  score?: number;
}

export interface KYCRecord {
  id: string;
  customerId: string;
  customerName?: string;
  status: 'pending' | 'verified' | 'failed';
  documents: string[];
  updatedAt: string;
}

@Injectable({
  providedIn: 'root'
})
export class BankingEmployeeService {
  private api = inject(ApiService);

  private loansSignal = signal<LoanRequest[]>([]);
  private kycSignal = signal<KYCRecord[]>([]);

  // Read-only signals
  loans = this.loansSignal.asReadonly();
  kycRecords = this.kycSignal.asReadonly();

  // Computed Stats
  pendingLoansCount = computed(() => this.loansSignal().filter(l => l.status === 'pending').length);
  pendingKYCCount = computed(() => this.kycSignal().filter(k => k.status === 'pending').length);

  stats = computed(() => ({
    pendingRequests: this.pendingLoansCount() + this.pendingKYCCount(),
    avgScore: '715',
    approvalRate: '68%',
    complianceStatus: 'Healthy'
  }));

  constructor() {
    this.refreshAllData();
  }

  refreshAllData() {
    forkJoin({
      loans: this.api.get<LoanRequest[]>('loanApplications'),
      kyc: this.api.get<KYCRecord[]>('kycRecords'),
      customers: this.api.get<any[]>('customers')
    }).subscribe(({ loans, kyc, customers }) => {
      const enrichedLoans = loans.map(l => ({
        ...l,
        customerName: customers.find(c => c.id === l.customerId)?.name || 'Unknown',
        score: Math.floor(Math.random() * (850 - 600) + 600)
      }));
      const enrichedKyc = kyc.map(k => ({
        ...k,
        customerName: customers.find(c => c.id === k.customerId)?.name || 'Unknown'
      }));

      this.loansSignal.set(enrichedLoans);
      this.kycSignal.set(enrichedKyc);
    });
  }

  // Operations
  updateLoanStatus(id: string, status: LoanRequest['status']) {
    return this.api.patch<LoanRequest>(`loanApplications/${id}`, { status }).pipe(
      tap(() => this.refreshAllData())
    );
  }

  updateKYCStatus(id: string, status: KYCRecord['status']) {
    return this.api.patch<KYCRecord>(`kycRecords/${id}`, { status, updatedAt: new Date().toISOString() }).pipe(
      tap(() => this.refreshAllData())
    );
  }

  processWithdrawal(customerId: string, amount: number) {
     // Triggering a transaction via API
     const newTx = {
        customerId,
        type: 'withdrawal',
        amount,
        status: 'completed',
        date: new Date().toISOString(),
        description: 'Employee-initiated withdrawal',
        category: 'Cash'
     };
     return this.api.post('transactions', newTx);
  }

  processDeposit(customerId: string, amount: number) {
     const newTx = {
        customerId,
        type: 'deposit',
        amount,
        status: 'completed',
        date: new Date().toISOString(),
        description: 'Employee-initiated deposit',
        category: 'Cash'
     };
     return this.api.post('transactions', newTx);
  }
}
