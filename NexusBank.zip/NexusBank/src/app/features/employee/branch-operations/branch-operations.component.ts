import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-branch-operations',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './branch-operations.component.html',
  styleUrl: './branch-operations.component.css'
})
export class BranchOperationsComponent {}