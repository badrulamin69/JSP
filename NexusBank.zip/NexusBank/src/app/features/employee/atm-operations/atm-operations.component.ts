import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-atm-operations',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './atm-operations.component.html',
  styleUrl: './atm-operations.component.css'
})
export class AtmOperationsComponent {}