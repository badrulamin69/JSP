import { Component, inject, computed, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BankingEmployeeService } from './banking-employee.service';

@Component({
  selector: 'app-employee-loans',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-8 animate-in slide-in-from-right-4 duration-500">
      <!-- Header -->
      <div class="flex flex-col sm:flex-row justify-between items-center gap-6 bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm">
        <div>
          <h2 class="text-3xl font-display font-bold text-slate-900 tracking-tight">Loan Underwriting</h2>
          <p class="text-slate-500 font-light mt-1">Institutional credit risk assessment and approval workflow.</p>
        </div>
        <div class="flex gap-4">
           <div class="text-right">
              <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-none">Global Cap</p>
              <p class="text-2xl font-bold text-slate-900">$2.5M</p>
           </div>
           <div class="w-[1px] h-10 bg-slate-100"></div>
           <div class="text-right">
              <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-none">Utilization</p>
              <p class="text-2xl font-bold text-emerald-600">64%</p>
           </div>
        </div>
      </div>

      <!-- Filters -->
      <div class="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm flex items-center gap-4">
         <mat-icon class="text-slate-400">filter_alt</mat-icon>
         <div class="flex gap-2">
            @for (status of statuses; track status) {
              <button 
                (click)="selectedStatus.set(status)"
                [class]="'px-5 py-2 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all ' + 
                (selectedStatus() === status ? 'bg-emerald-600 text-white' : 'bg-slate-50 text-slate-500 hover:bg-slate-100')"
              >
                {{ status }}
              </button>
            }
         </div>
      </div>

      <!-- Loan Cards -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        @for (loan of filteredLoans(); track loan.id) {
          <div class="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm overflow-hidden hover:shadow-xl transition-all duration-500 group">
             <!-- Card Top -->
             <div class="p-8 border-b border-slate-50">
                <div class="flex justify-between items-start mb-6">
                   <div [class]="'w-14 h-14 rounded-2xl flex items-center justify-center ' + getTypeBg(loan.type)">
                      <mat-icon [class]="getTypeColor(loan.type)">{{ getTypeIcon(loan.type) }}</mat-icon>
                   </div>
                   <span [class]="'px-4 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest ' + getStatusClass(loan.status)">
                      {{ loan.status }}
                   </span>
                </div>
                
                <div class="space-y-1">
                   <p class="text-xs font-bold text-slate-400 uppercase tracking-widest">Applicant Profile</p>
                   <h4 class="text-xl font-bold text-slate-900">{{ loan.customerName }}</h4>
                </div>

                <div class="grid grid-cols-2 gap-8 mt-8">
                   <div>
                      <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Requested Amount</p>
                      <p class="text-lg font-bold font-mono text-slate-900">{{ loan.amount | currency:'USD' }}</p>
                   </div>
                   <div>
                      <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Credit Score</p>
                      <div class="flex items-center gap-2">
                         <p [class]="'text-lg font-bold ' + getScoreColor(loan.score)">{{ loan.score }}</p>
                         <span class="text-[10px] font-bold px-1.5 py-0.5 rounded-sm bg-slate-100 text-slate-500">Tier A</span>
                      </div>
                   </div>
                </div>
             </div>

             <!-- Card Bottom Action -->
             <div class="px-8 py-5 bg-slate-50/50 flex items-center justify-between">
                <span class="text-[10px] text-slate-400 font-bold uppercase">{{ loan.date | date:'mediumDate' }}</span>
                
                @if (loan.status === 'pending') {
                  <div class="flex gap-2">
                    <button (click)="approve(loan.id)" class="px-4 py-2 bg-emerald-600 text-white text-[10px] font-bold uppercase rounded-xl hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-500/20">Approve</button>
                    <button (click)="reject(loan.id)" class="px-4 py-2 bg-white text-rose-600 border border-rose-100 text-[10px] font-bold uppercase rounded-xl hover:bg-rose-50 transition-all mt-0.5">Reject</button>
                  </div>
                } @else {
                  <button class="px-4 py-2 bg-white border border-slate-200 text-slate-600 text-[10px] font-bold uppercase rounded-xl hover:bg-slate-50 transition-all">View Details</button>
                }
             </div>
          </div>
        }
      </div>
    </div>
  `
})
export class EmployeeLoans {
  private service = inject(BankingEmployeeService);
  
  statuses = ['All', 'pending', 'approved', 'rejected', 'disbursed'];
  selectedStatus = signal('All');

  loans = this.service.loans;

  filteredLoans = computed(() => {
    const status = this.selectedStatus().toLowerCase();
    if (status === 'all') return this.loans();
    return this.loans().filter(l => l.status === status);
  });

  getTypeIcon(type: string) {
    switch (type) {
      case 'Mortgage': return 'home';
      case 'Business': return 'business_center';
      case 'Personal': return 'person';
      default: return 'payments';
    }
  }

  getTypeBg(type: string) {
    switch (type) {
      case 'Mortgage': return 'bg-blue-50';
      case 'Business': return 'bg-emerald-50';
      case 'Personal': return 'bg-purple-50';
      default: return 'bg-slate-50';
    }
  }

  getTypeColor(type: string) {
    switch (type) {
      case 'Mortgage': return 'text-blue-600';
      case 'Business': return 'text-emerald-600';
      case 'Personal': return 'text-purple-600';
      default: return 'text-slate-600';
    }
  }

  getStatusClass(status: string) {
    switch (status) {
      case 'approved': return 'bg-emerald-100 text-emerald-700';
      case 'pending': return 'bg-amber-100 text-amber-700';
      case 'rejected': return 'bg-rose-100 text-rose-700';
      default: return 'bg-slate-100 text-slate-700';
    }
  }

  getScoreColor(score?: number) {
    if (!score) return 'text-slate-400';
    if (score > 700) return 'text-emerald-600';
    if (score > 600) return 'text-amber-600';
    return 'text-rose-600';
  }

  approve(id: string) {
    this.service.updateLoanStatus(id, 'approved').subscribe();
  }

  reject(id: string) {
    this.service.updateLoanStatus(id, 'rejected').subscribe();
  }
}
