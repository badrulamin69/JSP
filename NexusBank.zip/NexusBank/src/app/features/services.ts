import { Component, ChangeDetectionStrategy, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-services',
  standalone: true,
  imports: [MatIconModule],
  template: `
    <div class="pt-32 pb-20">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 text-center space-y-4 mb-20">
        <h1 class="text-5xl md:text-6xl font-display font-bold text-bank-navy tracking-tight">Our Banking Ecosystem</h1>
        <p class="text-xl text-slate-500 max-w-2xl mx-auto font-light leading-relaxed">
          From personal wealth management to enterprise-scale financial infrastructure, we provide the tools you need to succeed globally.
        </p>
      </div>

      <div class="max-w-7xl mx-auto px-4 sm:px-6 space-y-32">
        @for (service of services(); track service.title; let i = $index) {
          <div class="flex flex-col lg:items-center gap-16" [class.lg:flex-row]="i % 2 === 0" [class.lg:flex-row-reverse]="i % 2 !== 0">
            <div class="lg:w-1/2 space-y-6">
              <div class="w-16 h-16 rounded-2xl bg-bank-blue/10 flex items-center justify-center text-bank-blue">
                <mat-icon>{{ service.icon }}</mat-icon>
              </div>
              <h2 class="text-4xl font-display font-bold text-bank-navy">{{ service.title }}</h2>
              <p class="text-lg text-slate-500 font-light leading-relaxed">{{ service.description }}</p>
              <ul class="space-y-4">
                @for (item of service.features; track item) {
                  <li class="flex items-center gap-3 text-slate-700">
                    <mat-icon class="text-emerald-500 text-sm">check_circle</mat-icon>
                    <span>{{ item }}</span>
                  </li>
                }
              </ul>
              <button class="bg-bank-navy text-white px-8 py-4 rounded-xl font-bold hover:bg-slate-800 transition-all">Learn More</button>
            </div>
            <div class="lg:w-1/2">
              <div class="aspect-video rounded-[2.5rem] overflow-hidden bg-slate-100 premium-shadow group">
                <img [src]="'https://picsum.photos/seed/bank' + i + '/800/600'" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" alt="Service Image">
              </div>
            </div>
          </div>
        }
      </div>
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ServicesPage {
  services = signal([
    {
      icon: 'person',
      title: 'Premium Personal Banking',
      description: 'Experience banking tailored to your lifestyle. Secure, fast, and globally accessible.',
      features: ['24/7 Priority Support', 'No Global ATM Fees', 'Custom Metal Credit Cards', 'Multi-currency Wallets']
    },
    {
      icon: 'business',
      title: 'Enterprise Solutions',
      description: 'Scale your business with powerful financial tools designed for complex international operations.',
      features: ['Mass Payments API', 'Multi-user Access Control', 'Corporate Expense Mgmt', 'Tax Compliance Tools']
    },
    {
      icon: 'account_balance_wallet',
      title: 'Wealth Management',
      description: 'Expert advice and cutting-edge tools to grow your assets with Swiss precision.',
      features: ['Dedicated Asset Manager', 'Exclusive Investment Access', 'Risk Management Tools', 'Detailed Portfolio Reports']
    }
  ]);
}
