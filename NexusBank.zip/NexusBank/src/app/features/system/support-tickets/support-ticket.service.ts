import { Injectable, signal, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { SupportTicket } from '../../../core/models/models';
import { ApiService } from '../../../core/services/api.service';
import { Api } from '../../../core/constants/api.constant';

@Injectable({
  providedIn: 'root'
})
export class SupportTicketService {
  private apiService = inject(ApiService);

  private _openTicketsCount = signal<number>(0);
  getOpenTicketsCount = this._openTicketsCount.asReadonly();

  getSupportTickets(filter?: Record<string, string | number | boolean>): Observable<SupportTicket[]> {
    return this.apiService.get<SupportTicket[]>(Api.SUPPORT_TICKETS, filter);
  }

  getSupportTicketById(id: string): Observable<SupportTicket> {
    return this.apiService.get<SupportTicket>(`${Api.SUPPORT_TICKETS}/${id}`);
  }

  createSupportTicket(ticket: Partial<SupportTicket>): Observable<SupportTicket> {
    return this.apiService.post<SupportTicket>(Api.SUPPORT_TICKETS, ticket);
  }

  updateSupportTicket(id: string, ticket: Partial<SupportTicket>): Observable<SupportTicket> {
    return this.apiService.patch<SupportTicket>(`${Api.SUPPORT_TICKETS}/${id}`, ticket);
  }

  addTicketReply(ticketId: string, reply: string): Observable<unknown> {
    return this.apiService.post<unknown>(`${Api.SUPPORT_TICKETS}/${ticketId}/replies`, { reply });
  }
}
