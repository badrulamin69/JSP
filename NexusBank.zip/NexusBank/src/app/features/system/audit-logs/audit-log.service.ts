import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { AuditLog } from '../../../core/models/models';
import { ApiService } from '../../../core/services/api.service';
import { Api } from '../../../core/constants/api.constant';

@Injectable({
  providedIn: 'root'
})
export class AuditLogService {
  private apiService = inject(ApiService);

  getAuditLogs(filter?: Record<string, string | number | boolean>): Observable<AuditLog[]> {
    return this.apiService.get<AuditLog[]>(Api.AUDIT_LOGS, filter);
  }

  getAuditLogById(id: string): Observable<AuditLog> {
    return this.apiService.get<AuditLog>(`${Api.AUDIT_LOGS}/${id}`);
  }

  searchAuditLogs(query: string, filter?: Record<string, string | number | boolean>): Observable<AuditLog[]> {
    return this.apiService.get<AuditLog[]>(Api.AUDIT_LOGS, { q: query, ...filter });
  }
}
