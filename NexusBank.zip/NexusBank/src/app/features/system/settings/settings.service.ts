import { Injectable, signal, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { Setting } from '../../../core/models/models';
import { ApiService } from '../../../core/services/api.service';

@Injectable({
  providedIn: 'root'
})
export class SettingsService {
  private apiService = inject(ApiService);

  private _displayTheme = signal<string>('light');
  getDisplayTheme = this._displayTheme.asReadonly();

  getAppSettings(): Observable<Setting[]> {
    return this.apiService.get<Setting[]>('settings');
  }

  updateAppSetting(id: string, value: string): Observable<Setting> {
    return this.apiService.patch<Setting>(`settings/${id}`, { value });
  }

  getUserPreferences(userId: string): Observable<Record<string, unknown>> {
    return this.apiService.get<Record<string, unknown>>(`user-preferences/${userId}`);
  }

  updateUserPreferences(userId: string, preferences: Record<string, unknown>): Observable<Record<string, unknown>> {
    return this.apiService.patch<Record<string, unknown>>(`user-preferences/${userId}`, preferences);
  }
}
