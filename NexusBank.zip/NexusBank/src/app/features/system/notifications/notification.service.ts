import { Injectable, signal, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { Notification } from '../../../core/models/models';
import { ApiService } from '../../../core/services/api.service';
import { Api } from '../../../core/constants/api.constant';

@Injectable({
  providedIn: 'root'
})
export class NotificationService {
  private apiService = inject(ApiService);

  private _unreadNotificationsCount = signal<number>(0);
  getUnreadNotificationsCount = this._unreadNotificationsCount.asReadonly();

  getNotifications(filter?: Record<string, string | number | boolean>): Observable<Notification[]> {
    return this.apiService.get<Notification[]>(Api.NOTIFICATIONS, filter);
  }

  getNotificationById(id: string): Observable<Notification> {
    return this.apiService.get<Notification>(`${Api.NOTIFICATIONS}/${id}`);
  }

  markAsRead(id: string): Observable<Notification> {
    return this.apiService.patch<Notification>(`${Api.NOTIFICATIONS}/${id}`, { isRead: true });
  }

  deleteNotification(id: string): Observable<void> {
    return this.apiService.delete<void>(`${Api.NOTIFICATIONS}/${id}`);
  }
}
