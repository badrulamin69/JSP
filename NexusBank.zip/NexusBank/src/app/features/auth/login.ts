import { Component, ChangeDetectionStrategy, inject, signal, OnInit } from '@angular/core';
import { Router, RouterLink, ActivatedRoute } from '@angular/router';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../core/services/auth.service';
import { SessionService } from '../../core/services/session.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, RouterLink, ReactiveFormsModule, MatIconModule],
  template: `
    <div class="min-h-screen flex items-center justify-center pt-24 pb-12 px-4 sm:px-6 bg-slate-50 relative overflow-hidden">
      <!-- Background Decorative Elements -->
      <div class="absolute top-0 left-0 w-full h-full overflow-hidden -z-10">
        <div class="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-bank-blue/10 rounded-full blur-[120px]"></div>
        <div class="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-bank-navy/5 rounded-full blur-[120px]"></div>
      </div>

      <div class="max-w-md w-full space-y-8 relative">
        <div class="text-center space-y-3">
          <div class="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-bank-navy text-white shadow-xl mb-4 rotate-3">
            <mat-icon class="text-3xl">account_balance</mat-icon>
          </div>
          <h2 class="text-4xl font-display font-bold text-bank-navy tracking-tight">Smart Secure Bank</h2>
          <p class="text-slate-500 font-light text-lg">Secure access to your global assets.</p>
        </div>

        <div class="glass p-8 rounded-[2.5rem] border border-white/40 shadow-2xl relative overflow-hidden backdrop-blur-xl">
          <!-- Loading Overlay -->
          <div *ngIf="isLoading()" class="absolute inset-0 bg-white/60 backdrop-blur-sm z-50 flex flex-col items-center justify-center gap-4">
             <div class="animate-spin rounded-full h-12 w-12 border-4 border-bank-blue border-t-transparent"></div>
             <p class="text-bank-navy font-bold animate-pulse">Authenticating...</p>
          </div>

          <form [formGroup]="loginForm" (ngSubmit)="onSubmit()" class="space-y-6">
            <div *ngIf="success()" class="bg-emerald-50 border-l-4 border-emerald-500 p-4 rounded-xl flex items-center gap-3 animate-in fade-in slide-in-from-top-2">
              <mat-icon class="text-emerald-500">check_circle</mat-icon>
              <p class="text-sm text-emerald-700 font-medium">{{ success() }}</p>
            </div>

            <div *ngIf="error()" class="bg-red-50 border-l-4 border-red-500 p-4 rounded-xl flex items-center gap-3 animate-in fade-in slide-in-from-top-2">
              <mat-icon class="text-red-500">error</mat-icon>
              <p class="text-sm text-red-700 font-medium">{{ error() }}</p>
            </div>

            <div class="space-y-5">
              <div>
                <label for="login-email" class="text-xs font-bold text-slate-500 uppercase tracking-widest pl-1 mb-2 block">Email Address</label>
                <div class="relative group">
                  <mat-icon class="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 transition-colors group-focus-within:text-bank-blue">mail</mat-icon>
                  <input id="login-email" type="email" formControlName="email" 
                    class="w-full bg-slate-50/50 border border-slate-200 rounded-2xl py-4 pl-12 pr-4 focus:outline-hidden focus:border-bank-blue focus:ring-4 focus:ring-bank-blue/10 transition-all text-slate-900 placeholder:text-slate-400" 
                    placeholder="name@company.com">
                </div>
                <div *ngIf="loginForm.get('email')?.touched && loginForm.get('email')?.errors?.['email']" class="text-[10px] text-red-500 mt-1 ml-1 font-bold uppercase tracking-wider">
                  Invalid email address format
                </div>
              </div>

              <div>
                <div class="flex justify-between items-center mb-2 pl-1 pr-1">
                  <label for="login-password" class="text-xs font-bold text-slate-500 uppercase tracking-widest block">Password</label>
                  <a href="#" class="text-[10px] font-bold text-bank-blue uppercase tracking-widest hover:underline transition-colors">Forgot Password?</a>
                </div>
                <div class="relative group">
                  <mat-icon class="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 transition-colors group-focus-within:text-bank-blue">lock</mat-icon>
                  <input id="login-password" [type]="showPassword() ? 'text' : 'password'" formControlName="password" 
                    class="w-full bg-slate-50/50 border border-slate-200 rounded-2xl py-4 pl-12 pr-12 focus:outline-hidden focus:border-bank-blue focus:ring-4 focus:ring-bank-blue/10 transition-all text-slate-900 placeholder:text-slate-400" 
                    placeholder="••••••••">
                  <button type="button" (click)="showPassword.set(!showPassword())" class="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-bank-navy transition-colors">
                    <mat-icon>{{ showPassword() ? 'visibility_off' : 'visibility' }}</mat-icon>
                  </button>
                </div>
              </div>
            </div>

            <div class="flex items-center px-1">
              <label class="flex items-center gap-3 cursor-pointer group">
                <input type="checkbox" class="w-5 h-5 rounded-lg border-slate-300 text-bank-blue focus:ring-bank-blue/20 cursor-pointer">
                <span class="text-sm text-slate-600 font-medium group-hover:text-bank-navy transition-colors">Keep me signed in for 30 days</span>
              </label>
            </div>

            <button type="submit" [disabled]="loginForm.invalid || isLoading()" 
              class="w-full bg-bank-navy text-white font-bold py-5 rounded-2xl hover:bg-slate-800 transition-all shadow-xl shadow-bank-navy/20 active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed text-lg">
              Sign In Securely
            </button>
          </form>

          <div class="mt-8 pt-8 border-t border-slate-100 text-center">
            <p class="text-sm text-slate-500 font-medium">
              New to Smart Secure? 
              <a routerLink="/register" class="text-bank-blue font-bold hover:underline ml-1">Create an account</a>
            </p>
          </div>
        </div>

        <!-- Security Badge -->
        <div class="flex items-center justify-center gap-3 text-slate-400 bg-white/50 backdrop-blur-sm py-3 px-6 rounded-full border border-white/50 w-fit mx-auto">
           <mat-icon class="text-sm">verified_user</mat-icon>
           <span class="text-[10px] font-bold uppercase tracking-widest">End-to-End Encrypted Session</span>
        </div>

        <div class="text-center">
          <a routerLink="/" class="text-xs font-bold text-slate-400 hover:text-bank-navy transition-colors uppercase tracking-widest inline-flex items-center gap-2">
            <mat-icon class="text-sm">arrow_back</mat-icon>
            Back to Homepage
          </a>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .glass {
      background: rgba(255, 255, 255, 0.7);
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LoginPage implements OnInit {
  private fb = inject(FormBuilder);
  private auth = inject(AuthService);
  private router = inject(Router);
  private session = inject(SessionService);
  private route = inject(ActivatedRoute);

  isLoading = signal(false);
  error = signal<string | null>(null);
  success = signal<string | null>(null);
  showPassword = signal(false);

  loginForm = this.fb.group({
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required]]
  });

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      if (params['registered']) {
        this.success.set('Account created successfully! Please log in.');
      }
    });
  }

  onSubmit() {
    if (this.loginForm.invalid) return;

    this.isLoading.set(true);
    this.error.set(null);
    this.success.set(null);

    const { email, password } = this.loginForm.getRawValue();

    this.auth.login(email!, password!).subscribe({
      next: (success) => {
        if (success) {
          const role = this.session.userRole();
          const redirectUrl = this.auth.getRedirectUrl(role!);
          this.router.navigate([redirectUrl]);
        } else {
          this.error.set('Invalid credentials. Please check your email and password.');
          this.isLoading.set(false);
        }
      },
      error: () => {
        this.error.set('A security error occurred. Please try again later.');
        this.isLoading.set(false);
      }
    });
  }
}
