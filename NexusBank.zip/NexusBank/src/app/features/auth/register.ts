import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, RouterLink, ReactiveFormsModule, MatIconModule],
  template: `
    <div class="min-h-screen flex items-center justify-center pt-24 pb-12 px-4 sm:px-6">
      <div class="max-w-md w-full space-y-8">
        <div class="text-center space-y-2">
          <h2 class="text-3xl font-display font-bold text-bank-navy">Join Smart Secure</h2>
          <p class="text-slate-500 font-light">Start your premium banking journey today.</p>
        </div>

        <div class="glass p-8 rounded-[2rem] border-white/50 premium-shadow relative overflow-hidden">
          <!-- Loading Overlay -->
          <div *ngIf="isLoading()" class="absolute inset-0 bg-white/60 backdrop-blur-sm z-50 flex flex-col items-center justify-center gap-4">
             <div class="animate-spin rounded-full h-12 w-12 border-4 border-bank-blue border-t-transparent"></div>
             <p class="text-bank-navy font-bold animate-pulse">Creating account...</p>
          </div>

          <form [formGroup]="registerForm" (ngSubmit)="onSubmit()" class="space-y-6">
            <div *ngIf="error()" class="bg-red-50 border-l-4 border-red-500 p-4 rounded-xl flex items-center gap-3">
              <mat-icon class="text-red-500">error</mat-icon>
              <p class="text-sm text-red-700 font-medium">{{ error() }}</p>
            </div>

            <div class="space-y-4">
              <div>
                <label for="reg-name" class="text-xs font-bold text-slate-500 uppercase tracking-widest pl-1 mb-1 block">Full Name</label>
                <div class="relative">
                  <mat-icon class="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">person</mat-icon>
                  <input id="reg-name" type="text" formControlName="name" class="w-full bg-slate-50 border border-slate-100 rounded-xl py-3 pl-10 pr-4 focus:outline-hidden focus:border-bank-blue transition-colors" placeholder="John Doe">
                </div>
              </div>

              <div>
                <label for="reg-email" class="text-xs font-bold text-slate-500 uppercase tracking-widest pl-1 mb-1 block">Email Address</label>
                <div class="relative">
                  <mat-icon class="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">mail</mat-icon>
                  <input id="reg-email" type="email" formControlName="email" class="w-full bg-slate-50 border border-slate-100 rounded-xl py-3 pl-10 pr-4 focus:outline-hidden focus:border-bank-blue transition-colors" placeholder="john@example.com">
                </div>
              </div>

              <div>
                <label for="reg-password" class="text-xs font-bold text-slate-500 uppercase tracking-widest pl-1 mb-1 block">Secure Password</label>
                <div class="relative">
                  <mat-icon class="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">lock</mat-icon>
                  <input id="reg-password" type="password" formControlName="password" class="w-full bg-slate-50 border border-slate-100 rounded-xl py-3 pl-10 pr-4 focus:outline-hidden focus:border-bank-blue transition-colors" placeholder="••••••••">
                </div>
              </div>
            </div>

            <div class="flex items-center gap-2">
              <input type="checkbox" id="terms" class="w-4 h-4 rounded-sm border-slate-300 text-bank-blue focus:ring-bank-blue" required>
              <label for="terms" class="text-sm text-slate-500">I agree to the <a routerLink="/terms" class="text-bank-blue font-semibold hover:underline">Terms of Service</a></label>
            </div>

            <button type="submit" [disabled]="registerForm.invalid || isLoading()" class="w-full bg-bank-navy text-white font-bold py-4 rounded-xl hover:bg-slate-800 transition-all shadow-xl active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed">
              Create Account
            </button>
          </form>

          <div class="mt-8 pt-8 border-t border-slate-100 text-center">
            <p class="text-sm text-slate-500">
              Already have an account? 
              <a routerLink="/login" class="text-bank-blue font-bold hover:underline">Log in</a>
            </p>
          </div>
        </div>
      </div>
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class RegisterPage {
  private fb = inject(FormBuilder);
  private auth = inject(AuthService);
  private router = inject(Router);

  isLoading = signal(false);
  error = signal<string | null>(null);

  registerForm = this.fb.group({
    name: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(8)]]
  });

  onSubmit() {
    if (this.registerForm.invalid) return;

    this.isLoading.set(true);
    this.error.set(null);

    const { name, email, password } = this.registerForm.getRawValue();

    this.auth.register({ name: name!, email: email!, password: password! }).subscribe({
      next: (success) => {
        if (success) {
          this.router.navigate(['/login'], { queryParams: { registered: true } });
        } else {
          this.error.set('Registration failed. Please try again.');
          this.isLoading.set(false);
        }
      },
      error: () => {
        this.error.set('An error occurred during registration.');
        this.isLoading.set(false);
      }
    });
  }
}
