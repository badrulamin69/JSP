import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-biometric-login',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './biometric-login.component.html',
  styleUrl: './biometric-login.component.css'
})
export class BiometricLoginComponent {}