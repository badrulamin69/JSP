import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth.guard';
import { roleGuard } from './core/guards/role.guard';

export const routes: Routes = [
  {
    path: '',
    loadComponent: () => import('./features/home/index').then(m => m.Homepage)
  },
  {
    path: 'services',
    loadComponent: () => import('./features/services').then(m => m.ServicesPage)
  },
  {
    path: 'security',
    loadComponent: () => import('./features/security').then(m => m.SecurityPage)
  },
  {
    path: 'pricing',
    loadComponent: () => import('./features/home/index').then(m => m.Homepage)
  },
  {
    path: 'about',
    loadComponent: () => import('./features/home/index').then(m => m.Homepage)
  },
  {
    path: 'contact',
    loadComponent: () => import('./features/home/index').then(m => m.Homepage)
  },
  {
    path: 'terms',
    loadComponent: () => import('./features/home/index').then(m => m.Homepage)
  },
  {
    path: 'privacy',
    loadComponent: () => import('./features/home/index').then(m => m.Homepage)
  },
  {
    path: 'cookies',
    loadComponent: () => import('./features/cookies/cookies').then(m => m.CookiesPage)
  },
  {
    path: 'register',
    loadComponent: () => import('./features/auth/register').then(m => m.RegisterPage)
  },
  {
    path: 'login',
    loadComponent: () => import('./features/auth/login').then(m => m.LoginPage)
  },
  {
    path: 'admin',
    canActivate: [authGuard, roleGuard],
    data: { roles: ['admin'] },
    loadComponent: () => import('./features/admin/layout').then(m => m.AdminLayout),
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      {
        path: 'dashboard',
        loadComponent: () => import('./features/admin/dashboard').then((m) => m.AdminDashboard),
      },
      {
        path: 'users',
        loadComponent: () => import('./features/admin/users').then((m) => m.AdminUsers),
      },
      {
        path: 'customers',
        loadComponent: () => import('./features/admin/customers').then((m) => m.AdminCustomers),
      },
      {
        path: 'employees',
        loadComponent: () =>
          import('./features/admin/pages/employees.page').then((m) => m.AdminEmployeesPage),
      },
      {
        path: 'accounts',
        loadComponent: () =>
          import('./features/admin/pages/admin-accounts.page').then((m) => m.AdminAccountsPage),
      },
      {
        path: 'transactions',
        loadComponent: () =>
          import('./features/admin/transactions').then((m) => m.AdminTransactions),
      },
      {
        path: 'support-tickets',
        loadComponent: () =>
          import('./features/admin/pages/support-tickets.page').then((m) => m.AdminSupportTicketsPage),
      },
      {
        path: 'audit',
        loadComponent: () =>
          import('./features/admin/pages/audit-logs.page').then((m) => m.AdminAuditLogsPage),
      },
      {
        path: 'loans',
        loadComponent: () =>
          import('./features/admin/pages/admin-loans.page').then((m) => m.AdminLoansPage),
      },
      {
        path: 'fixed-deposits',
        loadComponent: () =>
          import('./features/admin/pages/admin-fixed-deposits.page').then(
            (m) => m.AdminFixedDepositsPage,
          ),
      },
      {
        path: 'investments',
        loadComponent: () =>
          import('./features/admin/pages/admin-investments.page').then((m) => m.AdminInvestmentsPage),
      },
      {
        path: 'branches',
        loadComponent: () => import('./features/admin/pages/branches.page').then((m) => m.AdminBranchesPage),
      },
      {
        path: 'atms',
        loadComponent: () => import('./features/admin/pages/atms.page').then((m) => m.AdminAtmsPage),
      },
      {
        path: 'reports',
        loadComponent: () => import('./features/admin/pages/reports.page').then((m) => m.AdminReportsPage),
      },
      {
        path: 'roles',
        loadComponent: () => import('./features/admin/pages/roles.page').then((m) => m.AdminRolesPage),
      },
      {
        path: 'settings',
        loadComponent: () =>
          import('./features/admin/pages/admin-settings.page').then((m) => m.AdminSettingsPage),
      },
    ]
  },
  {
    path: 'customer',
    canActivate: [authGuard, roleGuard],
    data: { roles: ['customer'] },
    loadComponent: () => import('./features/customer/layout').then(m => m.CustomerLayout),
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      {
        path: 'dashboard',
        loadComponent: () => import('./features/customer/dashboard').then(m => m.CustomerDashboard)
      },
      {
        path: 'accounts',
        loadComponent: () => import('./features/customer/accounts').then(m => m.CustomerAccounts)
      },
      {
        path: 'history',
        loadComponent: () => import('./features/customer/history').then(m => m.CustomerHistory)
      },
      {
        path: 'transfer',
        loadComponent: () => import('./features/customer/transfer').then(m => m.CustomerTransfer)
      },
      {
        path: 'loans',
        loadComponent: () => import('./features/customer/loans').then(m => m.CustomerLoans)
      },
      {
        path: 'investments',
        loadComponent: () => import('./features/customer/investments').then(m => m.CustomerInvestments)
      },
      {
        path: 'fixed-deposits',
        loadComponent: () => import('./features/customer/fixed-deposits').then(m => m.CustomerFixedDeposits)
      },
      {
        path: 'cards',
        loadComponent: () => import('./features/customer/cards').then(m => m.CustomerCards)
      },
      {
        path: 'beneficiaries',
        loadComponent: () => import('./features/customer/beneficiaries').then(m => m.CustomerBeneficiaries)
      },
      {
        path: 'exchange',
        loadComponent: () => import('./features/customer/exchange').then(m => m.CustomerExchange)
      },
      {
        path: 'statements',
        loadComponent: () => import('./features/customer/statements').then(m => m.CustomerStatements)
      },
      {
        path: 'locator',
        loadComponent: () => import('./features/customer/locator').then(m => m.CustomerLocator)
      },
      {
        path: 'support',
        loadComponent: () => import('./features/customer/support').then(m => m.CustomerSupport)
      },
      {
        path: 'profile',
        loadComponent: () => import('./features/customer/profile').then(m => m.CustomerProfile)
      },
      {
        path: 'security',
        loadComponent: () => import('./features/customer/security').then(m => m.CustomerSecurity)
      },
      {
        path: 'kyc',
        loadComponent: () => import('./features/customer/kyc').then(m => m.CustomerKyc)
      },
      {
        path: 'notifications',
        loadComponent: () => import('./features/customer/notifications').then(m => m.CustomerNotifications)
      },
      {
        path: 'settings',
        loadComponent: () => import('./features/customer/settings').then(m => m.CustomerSettings)
      }
    ]
  },
  {
    path: 'employee',
    canActivate: [authGuard, roleGuard],
    data: { roles: ['employee'] },
    loadComponent: () => import('./features/employee/layout').then(m => m.EmployeeLayout),
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      {
        path: 'dashboard',
        loadComponent: () => import('./features/employee/dashboard').then(m => m.EmployeeDashboard)
      },
      {
        path: 'loans',
        loadComponent: () => import('./features/employee/loans').then(m => m.EmployeeLoans)
      },
      {
        path: 'compliance',
        loadComponent: () => import('./features/employee/compliance').then(m => m.EmployeeCompliance)
      }
    ]
  },
  {
    path: '**',
    redirectTo: ''
  }
];

