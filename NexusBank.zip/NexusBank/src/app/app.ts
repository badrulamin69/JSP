import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { NavigationEnd, Router, RouterOutlet } from '@angular/router';
import { toSignal } from '@angular/core/rxjs-interop';
import { filter, map, merge, of } from 'rxjs';
import { Navbar } from './shared/navbar';
import { Footer } from './shared/footer';
import { SpinnerComponent } from './shared/components/spinner';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [RouterOutlet, Navbar, Footer, SpinnerComponent],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  private router = inject(Router);

  /** Tracks URL after each navigation so dashboard routes can hide the marketing chrome. */
  private currentUrl = toSignal(
    merge(
      of(this.router.url),
      this.router.events.pipe(
        filter((e): e is NavigationEnd => e instanceof NavigationEnd),
        map(() => this.router.url),
      ),
    ),
    { initialValue: this.router.url },
  );

  /** Public marketing navbar/footer only on public routes — not inside admin/customer/employee shells. */
  showPublicChrome = computed(() => {
    const url = this.currentUrl();
    return (
      !url.startsWith('/admin') &&
      !url.startsWith('/customer') &&
      !url.startsWith('/employee')
    );
  });
}
