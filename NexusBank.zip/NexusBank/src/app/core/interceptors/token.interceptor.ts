import { inject } from '@angular/core';
import { HttpInterceptorFn } from '@angular/common/http';
import { SessionService } from '../services/session.service';

export const tokenInterceptor: HttpInterceptorFn = (req, next) => {
  const session = inject(SessionService);
  const userSession = session.session();

  if (userSession?.token) {
    req = req.clone({
      setHeaders: {
        Authorization: `Bearer ${userSession.token}`
      }
    });
  }

  return next(req);
};