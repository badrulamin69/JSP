export interface User {
  id: string;
  uuid: string;

  fullName: string;
  username: string;
  email: string;
  phone: string;

  password?: string;

  roleId: string;
  roleName: string;

  branchId?: string;

  avatar?: string;

  isActive: boolean;
  isVerified: boolean;

  lastLogin?: string;

  createdAt: string;
  updatedAt: string;
}

export interface Role {
  id: string;

  name: string;
  description?: string;

  permissions: string[];

  isActive: boolean;

  createdAt: string;
}

export interface Permission {
  id: string;

  module: string;

  canCreate: boolean;
  canRead: boolean;
  canUpdate: boolean;
  canDelete: boolean;

  createdAt: string;
}

export interface AuthSession {
  token: string;

  userId: string;

  role: string;

  loginTime: string;

  expiresAt: string;

  device?: string;

  ipAddress?: string;
}

export interface Branch {
  id: string;

  branchCode: string;
  branchName: string;

  branchType:
    | 'Head Office'
    | 'Main Branch'
    | 'Sub Branch'
    | 'Corporate Branch'
    | 'Islamic Branch'
    | 'Foreign Exchange Branch';

  parentBranchId?: string;

  address: string;
  city: string;
  district: string;

  postalCode?: string;

  phone: string;
  email?: string;

  managerId?: string;

  isActive: boolean;

  createdAt: string;
}

export interface ATM {
  id: string;

  atmCode: string;

  branchId: string;

  location: string;

  cashAvailable: number;

  status:
    | 'Online'
    | 'Offline'
    | 'Maintenance';

  lastRefillDate?: string;

  createdAt: string;
}

export interface Department {
  id: string;

  name: string;

  description?: string;

  createdAt: string;
}

export interface Designation {
  id: string;

  title: string;

  hierarchyLevel: number;

  description?: string;

  createdAt: string;
}

export interface Employee {
  id: string;

  employeeId: string;

  fullName: string;

  email: string;
  phone: string;

  designationId: string;
  departmentId: string;

  branchId: string;

  roleId: string;

  salary?: number;

  joiningDate: string;

  address?: string;

  avatar?: string;

  status:
    | 'Active'
    | 'Inactive'
    | 'Suspended';

  createdAt: string;
}

export interface CustomerType {
  id: string;

  name:
    | 'Regular Customer'
    | 'Student Customer'
    | 'Premium Customer'
    | 'VIP Customer'
    | 'Corporate Client'
    | 'NRB Customer'
    | 'Government Client';

  description?: string;

  createdAt: string;
}

export interface Customer {
  id: string;

  customerId: string;

  fullName: string;

  email: string;
  phone: string;

  dateOfBirth?: string;

  gender?: string;

  nidNumber?: string;
  passportNumber?: string;

  customerTypeId: string;

  branchId: string;

  address?: string;

  occupation?: string;

  monthlyIncome?: number;

  isKycVerified: boolean;

  status:
    | 'Active'
    | 'Inactive'
    | 'Blocked';

  createdAt: string;
}

export interface Beneficiary {
  id: string;

  customerId: string;

  beneficiaryName: string;

  accountNumber: string;

  bankName: string;

  branchName?: string;

  swiftCode?: string;

  isFavorite?: boolean;

  createdAt: string;
}

export interface Account {
  id: string;

  accountNumber: string;

  customerId: string;

  branchId: string;

  accountType:
    | 'Savings'
    | 'Current'
    | 'Fixed Deposit';

  currency: string;

  balance: number;

  interestRate?: number;

  status:
    | 'Active'
    | 'Frozen'
    | 'Closed';

  openedAt: string;

  createdAt: string;
}

export interface BankCard {
  id: string;

  customerId: string;

  accountId: string;

  cardType:
    | 'Debit'
    | 'Credit'
    | 'Prepaid';

  cardNumber: string;

  expiryDate: string;

  status:
    | 'Active'
    | 'Blocked'
    | 'Expired';

  createdAt: string;
}

export interface Transaction {
  id: string;

  referenceNumber: string;

  senderAccountId?: string;
  receiverAccountId?: string;

  transactionType:
    | 'Deposit'
    | 'Withdraw'
    | 'Transfer'
    | 'International Transfer';

  amount: number;

  currency: string;

  fee?: number;

  status:
    | 'Pending'
    | 'Completed'
    | 'Failed';

  description?: string;

  createdBy?: string;

  createdAt: string;
}

export interface Loan {
  id: string;

  loanNumber: string;

  customerId: string;

  loanType:
    | 'Personal'
    | 'Home'
    | 'Business'
    | 'Car';

  amount: number;

  interestRate: number;

  durationMonths: number;

  emiAmount?: number;

  paidAmount?: number;

  remainingAmount?: number;

  status:
    | 'Pending'
    | 'Approved'
    | 'Rejected'
    | 'Closed';

  approvedBy?: string;

  createdAt: string;
}

export interface LoanPayment {
  id: string;

  loanId: string;

  amount: number;

  paymentDate: string;

  paymentMethod: string;

  transactionId?: string;

  status:
    | 'Paid'
    | 'Pending';
}

export interface FixedDeposit {
  id: string;

  fdNumber: string;

  customerId: string;

  accountId: string;

  amount: number;

  interestRate: number;

  durationMonths: number;

  maturityAmount?: number;

  startDate: string;
  maturityDate: string;

  status:
    | 'Active'
    | 'Matured'
    | 'Closed';

  createdAt: string;
}

export interface Investment {
  id: string;

  customerId: string;

  investmentType:
    | 'Mutual Fund'
    | 'Stocks'
    | 'Bond'
    | 'Retirement';

  amount: number;

  expectedReturn?: number;

  riskLevel:
    | 'Low'
    | 'Medium'
    | 'High';

  startDate: string;

  maturityDate?: string;

  status:
    | 'Active'
    | 'Closed';

  createdAt: string;
}

export interface Currency {
  id: string;

  code: string;

  name: string;

  symbol: string;

  exchangeRate: number;

  updatedAt: string;
}

export interface ExchangeRate {
  id: string;

  fromCurrency: string;
  toCurrency: string;

  rate: number;

  updatedAt: string;
}

export interface CurrencyExchange {
  id: string;

  customerId: string;

  fromCurrency: string;

  toCurrency: string;

  amount: number;

  exchangeRate: number;

  convertedAmount: number;

  createdAt: string;
}

export interface Notification {
  id: string;

  userId: string;

  title: string;

  message: string;

  type:
    | 'Success'
    | 'Warning'
    | 'Error'
    | 'Info';

  isRead: boolean;

  createdAt: string;
}

export interface Report {
  id: string;

  title: string;

  reportType:
    | 'Transaction'
    | 'Customer'
    | 'Loan'
    | 'Revenue';

  generatedBy: string;

  generatedAt: string;

  fileUrl?: string;
}

export interface AuditLog {
  id: string;

  userId: string;

  action: string;

  module: string;

  description?: string;

  ipAddress?: string;

  createdAt: string;
}

export interface Setting {
  id: string;

  key: string;

  value: string;

  description?: string;

  updatedAt: string;
}

export interface SupportTicket {
  id: string;

  customerId?: string;

  employeeId?: string;

  subject: string;

  message: string;

  priority:
    | 'Low'
    | 'Medium'
    | 'High';

  status:
    | 'Open'
    | 'Pending'
    | 'Resolved';

  createdAt: string;
}
