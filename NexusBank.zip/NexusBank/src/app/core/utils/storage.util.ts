export const Storage = {
  helper: () => {}
};