export const Date = {
  helper: () => {}
};