import { Injectable } from '@angular/core';
import { AbstractControl, ValidatorFn, ValidationErrors } from '@angular/forms';
import { Customer } from '../models/models';
import { Validation } from '../constants/validation.constant';

@Injectable({
  providedIn: 'root'
})
export class ValidationService {
  isValidEmail(email: string): boolean {
    return Validation.EMAIL_PATTERN.test(email);
  }

  isStrongPassword(password: string): boolean {
    // At least 8 characters, one uppercase, one lowercase, one number, one special character
    const strongRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*])(?=.{8,})/;
    return strongRegex.test(password);
  }

  isPositiveAmount(amount: number): boolean {
    return amount > 0;
  }

  isValidAccountNumber(accountNumber: string): boolean {
    // Example: 10-18 digit numeric account number
    const accountRegex = /^\d{10,18}$/;
    return accountRegex.test(accountNumber);
  }

  // Example of a business-specific validation
  validateCustomerData(customer: Partial<Customer>): Record<string, string> | null {
    const errors: Record<string, string> = {};
    if (!customer.fullName || customer.fullName.trim().length < 3) {
      errors['fullName'] = 'Full name is required and must be at least 3 characters.';
    }
    if (customer.email && !this.isValidEmail(customer.email)) {
      errors['email'] = Validation.INVALID_EMAIL;
    }
    // Add more validation rules as needed
    return Object.keys(errors).length > 0 ? errors : null;
  }

  // Angular Reactive Forms Validator Function example
  static minLengthValidator(minLength: number): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      if (control.value && control.value.length < minLength) {
        return { 'minLength': { requiredLength: minLength, actualLength: control.value.length } };
      }
      return null;
    };
  }
}
