import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StorageService {

  constructor() { }

  setItem(key: string, value: unknown, storageType: 'local' | 'session' = 'local'): void {
    const storage = storageType === 'local' ? localStorage : sessionStorage;
    storage.setItem(key, JSON.stringify(value));
  }

  getItem<T>(key: string, storageType: 'local' | 'session' = 'local'): T | null {
    const storage = storageType === 'local' ? localStorage : sessionStorage;
    const item = storage.getItem(key);
    return item ? JSON.parse(item) as T : null;
  }

  removeItem(key: string, storageType: 'local' | 'session' = 'local'): void {
    const storage = storageType === 'local' ? localStorage : sessionStorage;
    storage.removeItem(key);
  }

  clear(storageType: 'local' | 'session' = 'local'): void {
    const storage = storageType === 'local' ? localStorage : sessionStorage;
    storage.clear();
  }
}
