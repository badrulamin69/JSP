export const Currency = {
  helper: () => {}
};