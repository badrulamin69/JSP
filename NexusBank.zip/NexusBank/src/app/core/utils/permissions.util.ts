export const Permissions = {
  helper: () => {}
};