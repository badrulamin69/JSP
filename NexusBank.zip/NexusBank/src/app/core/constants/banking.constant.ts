export const Banking = {
  KEY: 'VALUE'
};