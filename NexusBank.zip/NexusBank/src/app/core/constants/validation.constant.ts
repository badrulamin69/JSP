export const Validation = {
  EMAIL_PATTERN: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
  PHONE_PATTERN: /^\+?[0-9]{10,15}$/,
  REQUIRED: 'This field is required.',
  INVALID_EMAIL: 'Please enter a valid email address.',
  INVALID_PHONE: 'Please enter a valid phone number.',
  MIN_LENGTH: (min: number) => `Minimum length is ${min} characters.`,
  MAX_LENGTH: (max: number) => `Maximum length is ${max} characters.`,
};
