export const App = {
  KEY: 'VALUE'
};