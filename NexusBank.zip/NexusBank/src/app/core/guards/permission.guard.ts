import { CanActivateFn } from '@angular/router';

export const PermissionGuard: CanActivateFn = (route, state) => {
  return true;
};