import { inject } from '@angular/core';
import { Router, CanActivateFn } from '@angular/router';
import { SessionService } from '../services/session.service';

export const roleGuard: CanActivateFn = (route, state) => {
  const session = inject(SessionService);
  const router = inject(Router);
  const expectedRoles = route.data['roles'] as string[];

  const userRole = session.userRole();
  
  if (session.isAuthenticated() && userRole && expectedRoles.includes(userRole)) {
    return true;
  }

  router.navigate(['/']); // Or a forbidden page
  return false;
};
