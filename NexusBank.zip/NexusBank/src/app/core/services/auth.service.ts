import { Injectable, inject } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, map, of, catchError } from 'rxjs';
import { ApiService } from './api.service';
import { StorageService } from './storage.service';
import { SessionService, UserSession } from './session.service';

/** Shape of `users` entries in db.json — used only for demo login lookup. */
interface DbUserRecord {
  id: string;
  name: string;
  email: string;
  password: string;
  role: string;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private api = inject(ApiService);
  private storage = inject(StorageService);
  private session = inject(SessionService);
  private router = inject(Router);

  private readonly AUTH_KEY = 'sb_auth_session';

  constructor() {
    this.restoreSession();
  }

  login(email: string, password: string): Observable<boolean> {
    // Load all users instead of filtering by query string — avoids brittle URL-encoding
    // (e.g. `@` in emails) across proxies and simplifies matching against db.json.
    const normalizedEmail = email.trim().toLowerCase();

    return this.api.get<DbUserRecord[]>('users').pipe(
      map((raw) => {
        const users = Array.isArray(raw) ? raw : [];
        const user = users.find(
          (u) =>
            typeof u?.email === 'string' &&
            u.email.trim().toLowerCase() === normalizedEmail &&
            u.password === password,
        );
        if (user) {
          const userSession: UserSession = {
            id: user.id,
            name: user.name,
            email: user.email,
            role: user.role,
            token: `fake-jwt-token-${Math.random().toString(36).substring(7)}`
          };
          this.storage.setItem(this.AUTH_KEY, userSession);
          this.session.setSession(userSession);
          return true;
        }
        return false;
      }),
      catchError(() => of(false))
    );
  }

  register(userData: Omit<DbUserRecord, 'id' | 'role'>): Observable<boolean> {
    const newUser: DbUserRecord = {
      ...userData,
      id: Math.random().toString(36).substring(7),
      role: 'customer' // Default role for new registrations
    };

    return this.api.post<DbUserRecord>('users', newUser).pipe(
      map(() => true),
      catchError(() => of(false))
    );
  }

  logout(): void {
    this.storage.removeItem(this.AUTH_KEY);
    this.session.clearSession();
    this.router.navigate(['/login']);
  }

  private restoreSession(): void {
    const savedSession = this.storage.getItem<UserSession>(this.AUTH_KEY);
    if (savedSession) {
      this.session.setSession(savedSession);
    }
  }

  getRedirectUrl(role: string): string {
    switch (role) {
      case 'admin': return '/admin/dashboard';
      case 'employee': return '/employee/dashboard';
      case 'customer': return '/customer/dashboard';
      default: return '/';
    }
  }
}
