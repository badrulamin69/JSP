import { Injectable, signal, computed } from '@angular/core';

export interface UserSession {
  id: string;
  name: string;
  email: string;
  role: string;
  token: string;
}

@Injectable({
  providedIn: 'root'
})
export class SessionService {
  private _session = signal<UserSession | null>(null);

  session = computed(() => this._session());
  isAuthenticated = computed(() => !!this._session());
  userRole = computed(() => this._session()?.role);

  setSession(session: UserSession): void {
    this._session.set(session);
  }

  clearSession(): void {
    this._session.set(null);
  }
}
