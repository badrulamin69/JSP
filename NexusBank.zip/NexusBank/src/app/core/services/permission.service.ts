import { Injectable, inject, computed } from '@angular/core';
import { SessionService } from './session.service';

@Injectable({
  providedIn: 'root'
})
export class PermissionService {
  private sessionService = inject(SessionService);

  hasPermission(permission: string): boolean {
    const role = this.sessionService.userRole();
    if (role === 'admin') return true;
    
    // In a real app, we'd fetch permissions for the role
    // For now, we simulate based on role
    const rolePermissions: Record<string, string[]> = {
      'employee': ['view_customers', 'approve_loans'],
      'customer': ['view_accounts', 'transfer_funds']
    };

    return rolePermissions[role || '']?.includes(permission) || false;
  }

  hasRole(role: string): boolean {
    return this.sessionService.userRole() === role;
  }
}
