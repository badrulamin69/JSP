import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'dateFormat',
  standalone: true
})
export class DateFormatPipe implements PipeTransform {
  transform(value: string | Date | null | undefined, format: string = 'mediumDate'): string {
    if (!value) return '';
    const date = typeof value === 'string' ? new Date(value) : value;
    if (isNaN(date.getTime())) return '';

    // Simple format mapping or just use Intl
    const options: Intl.DateTimeFormatOptions = {};
    if (format === 'short') {
      options.dateStyle = 'short';
    } else if (format === 'full') {
      options.dateStyle = 'full';
      options.timeStyle = 'short';
    } else {
      options.dateStyle = 'medium';
    }

    return new Intl.DateTimeFormat('en-US', options).format(date);
  }
}