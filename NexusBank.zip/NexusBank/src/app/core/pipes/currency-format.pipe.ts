import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'currencyFormat',
  standalone: true
})
export class CurrencyFormatPipe implements PipeTransform {
  transform(value: number | string | null | undefined, currencyCode: string = 'USD', locale: string = 'en-US'): string {
    if (value === null || value === undefined) return '';
    const amount = typeof value === 'string' ? parseFloat(value) : value;
    if (isNaN(amount)) return '';

    return new Intl.NumberFormat(locale, {
      style: 'currency',
      currency: currencyCode,
    }).format(amount);
  }
}