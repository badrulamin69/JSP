import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'statusColor',
  standalone: true
})
export class StatusColorPipe implements PipeTransform {
  transform(status: string | null | undefined): string {
    if (!status) return 'text-slate-500 bg-slate-100';
    
    const s = status.toLowerCase();
    switch (s) {
      case 'active':
      case 'completed':
      case 'verified':
      case 'online':
      case 'approved':
      case 'success':
        return 'text-emerald-700 bg-emerald-50 border-emerald-100';
      case 'pending':
      case 'in-progress':
      case 'maintenance':
      case 'warning':
        return 'text-amber-700 bg-amber-50 border-amber-100';
      case 'suspended':
      case 'failed':
      case 'blocked':
      case 'offline':
      case 'rejected':
      case 'error':
        return 'text-red-700 bg-red-50 border-red-100';
      default:
        return 'text-slate-700 bg-slate-50 border-slate-100';
    }
  }
}